
graph:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000498640 <velri_slang_dot_linear_w8a8_f32_packed>:
  498640:	endbr64
  498644:	push   %rbp
  498645:	mov    %rsp,%rbp
  498648:	push   %r15
  49864a:	push   %r14
  49864c:	push   %r13
  49864e:	push   %r12
  498650:	push   %rbx
  498651:	and    $0xffffffffffffffc0,%rsp
  498655:	sub    $0x300,%rsp
  49865c:	mov    0x18(%rbp),%rax
  498660:	mov    0x28(%rbp),%r13d
  498664:	mov    %r8,0x1e8(%rsp)
  49866c:	mov    0x40(%rbp),%r14d
  498670:	mov    %rdi,0x170(%rsp)
  498678:	mov    0x38(%rbp),%r8d
  49867c:	mov    %rdx,0xf0(%rsp)
  498684:	mov    %rax,0x1e0(%rsp)
  49868c:	mov    %fs:0x28,%rbx
  498695:	mov    %rbx,0x2f8(%rsp)
  49869d:	mov    0x48(%rbp),%ebx
  4986a0:	cmp    0x30(%rbp),%r13d
  4986a4:	jae    499ff7 <velri_slang_dot_linear_w8a8_f32_packed+0x19b7>
  4986aa:	cmp    %r14d,%r8d
  4986ad:	jae    499ff7 <velri_slang_dot_linear_w8a8_f32_packed+0x19b7>
  4986b3:	mov    %esi,%eax
  4986b5:	vmovq  %rcx,%xmm1
  4986ba:	mov    %r14d,%ecx
  4986bd:	mov    %r9,0x40(%rsp)
  4986c2:	mov    %rax,0xe8(%rsp)
  4986ca:	lea    -0x1(%rbx),%eax
  4986cd:	sub    %r8d,%ecx
  4986d0:	mov    %ebx,%edi
  4986d2:	mov    %eax,0xe4(%rsp)
  4986d9:	vmovd  %ebx,%xmm3
  4986dd:	vxorps %xmm0,%xmm0,%xmm0
  4986e1:	mov    %r8d,%r10d
  4986e4:	lea    0x1f0(%rsp),%rax
  4986ec:	mov    %ecx,0x38(%rsp)
  4986f0:	mov    %rax,0xd8(%rsp)
  4986f8:	mov    0x20(%rbp),%eax
  4986fb:	vmovq  %xmm3,0x70(%rsp)
  498701:	mov    %rax,0x1d8(%rsp)
  498709:	mov    %ebx,%eax
  49870b:	mov    %r13d,%ebx
  49870e:	shr    $0x6,%eax
  498711:	vmovq  %xmm1,0x30(%rsp)
  498717:	shl    $0x6,%rax
  49871b:	mov    %rax,0xa0(%rsp)
  498723:	mov    0x30(%rbp),%edx
  498726:	mov    $0x40,%eax
  49872b:	mov    %ebx,%esi
  49872d:	mov    %ebx,0xb4(%rsp)
  498734:	mov    0xd8(%rsp),%r8
  49873c:	movl   $0x0,0x1f0(%rsp)
  498747:	sub    %ebx,%edx
  498749:	cmp    %eax,%edx
  49874b:	mov    %edx,0x7c(%rsp)
  49874f:	cmovbe %edx,%eax
  498752:	mov    %esi,%edx
  498754:	mov    %eax,0xf8(%rsp)
  49875b:	add    %eax,%ebx
  49875d:	mov    %r8,%rax
  498760:	test   %edi,%edi
  498762:	je     49a01d <velri_slang_dot_linear_w8a8_f32_packed+0x19dd>
  498768:	mov    %r10d,%r12d
  49876b:	mov    0xe8(%rsp),%r11
  498773:	mov    0xe4(%rsp),%r13d
  49877b:	mov    0xa0(%rsp),%r10
  498783:	mov    0x170(%rsp),%r14
  49878b:	nopl   0x0(%rax,%rax,1)
  498790:	mov    %esi,%edx
  498792:	imul   %r11,%rdx
  498796:	cmp    $0x3e,%r13d
  49879a:	jbe    49b429 <velri_slang_dot_linear_w8a8_f32_packed+0x2de9>
  4987a0:	add    %r14,%rdx
  4987a3:	vpxor  %xmm4,%xmm4,%xmm4
  4987a7:	mov    %rdx,%rax
  4987aa:	lea    (%r10,%rdx,1),%rcx
  4987ae:	xchg   %ax,%ax
  4987b0:	vmovdqu8 (%rax),%zmm1
  4987b6:	add    $0x40,%rax
  4987ba:	vpmovsxbw %ymm1,%zmm2
  4987c0:	vextracti64x4 $0x1,%zmm1,%ymm1
  4987c7:	vpmovsxbw %ymm1,%zmm1
  4987cd:	vpmovsxwd %ymm1,%zmm3
  4987d3:	vextracti64x4 $0x1,%zmm1,%ymm1
  4987da:	vpmovsxwd %ymm1,%zmm1
  4987e0:	vpaddd %zmm1,%zmm3,%zmm1
  4987e6:	vpmovsxwd %ymm2,%zmm3
  4987ec:	vextracti64x4 $0x1,%zmm2,%ymm2
  4987f3:	vpmovsxwd %ymm2,%zmm2
  4987f9:	vpaddd %zmm2,%zmm3,%zmm2
  4987ff:	vpaddd %zmm2,%zmm1,%zmm1
  498805:	vpaddd %zmm1,%zmm4,%zmm4
  49880b:	cmp    %rcx,%rax
  49880e:	jne    4987b0 <velri_slang_dot_linear_w8a8_f32_packed+0x170>
  498810:	vextracti32x8 $0x1,%zmm4,%ymm2
  498817:	vpaddd %ymm4,%ymm2,%ymm2
  49881b:	vextracti32x4 $0x1,%ymm2,%xmm1
  498822:	vpaddd %xmm2,%xmm1,%xmm1
  498826:	vpsrldq $0x8,%xmm1,%xmm3
  49882b:	vpaddd %xmm3,%xmm1,%xmm1
  49882f:	vpsrldq $0x4,%xmm1,%xmm3
  498834:	vpaddd %xmm3,%xmm1,%xmm1
  498838:	test   $0x3f,%dil
  49883c:	je     49b43b <velri_slang_dot_linear_w8a8_f32_packed+0x2dfb>
  498842:	mov    %edi,%eax
  498844:	vmovdqa %ymm2,%ymm4
  498848:	and    $0xffffffc0,%eax
  49884b:	mov    %edi,%ecx
  49884d:	sub    %eax,%ecx
  49884f:	lea    -0x1(%rcx),%r9d
  498853:	cmp    $0x1e,%r9d
  498857:	jbe    4988cd <velri_slang_dot_linear_w8a8_f32_packed+0x28d>
  498859:	mov    %eax,%r9d
  49885c:	vmovdqu8 (%rdx,%r9,1),%ymm1
  498863:	vpmovsxbw %xmm1,%ymm3
  498868:	vextracti32x4 $0x1,%ymm1,%xmm1
  49886f:	vpmovsxwd %xmm3,%ymm2
  498874:	vextracti32x4 $0x1,%ymm3,%xmm3
  49887b:	vpmovsxbw %xmm1,%ymm1
  498880:	vpmovsxwd %xmm3,%ymm3
  498885:	vpaddd %ymm3,%ymm2,%ymm2
  498889:	vpmovsxwd %xmm1,%ymm3
  49888e:	vextracti32x4 $0x1,%ymm1,%xmm1
  498895:	vpmovsxwd %xmm1,%ymm1
  49889a:	vpaddd %ymm4,%ymm2,%ymm2
  49889e:	vpaddd %ymm1,%ymm3,%ymm1
  4988a2:	vpaddd %ymm1,%ymm2,%ymm2
  4988a6:	vextracti32x4 $0x1,%ymm2,%xmm1
  4988ad:	vpaddd %xmm2,%xmm1,%xmm1
  4988b1:	vpsrldq $0x8,%xmm1,%xmm2
  4988b6:	vpaddd %xmm2,%xmm1,%xmm1
  4988ba:	vpsrldq $0x4,%xmm1,%xmm2
  4988bf:	vpaddd %xmm2,%xmm1,%xmm1
  4988c3:	test   $0x1f,%cl
  4988c6:	je     4988f6 <velri_slang_dot_linear_w8a8_f32_packed+0x2b6>
  4988c8:	and    $0xffffffe0,%ecx
  4988cb:	add    %ecx,%eax
  4988cd:	mov    %eax,%ecx
  4988cf:	add    %rcx,%rdx
  4988d2:	sub    %edx,%eax
  4988d4:	nop
  4988d5:	data16 cs nopw 0x0(%rax,%rax,1)
  4988e0:	movsbl (%rdx),%ecx
  4988e3:	add    $0x1,%rdx
  4988e7:	vmovd  %ecx,%xmm2
  4988eb:	lea    (%rax,%rdx,1),%ecx
  4988ee:	vpaddd %xmm2,%xmm1,%xmm1
  4988f2:	cmp    %edi,%ecx
  4988f4:	jb     4988e0 <velri_slang_dot_linear_w8a8_f32_packed+0x2a0>
  4988f6:	vpslld $0x7,%xmm1,%xmm1
  4988fb:	add    $0x1,%esi
  4988fe:	add    $0x4,%r8
  498902:	vmovd  %xmm1,-0x4(%r8)
  498908:	cmp    %esi,%ebx
  49890a:	jne    498790 <velri_slang_dot_linear_w8a8_f32_packed+0x150>
  498910:	mov    %r12d,%r10d
  498913:	cmpl   $0x4,0x38(%rsp)
  498918:	jbe    49a04b <velri_slang_dot_linear_w8a8_f32_packed+0x1a0b>
  49891e:	mov    0xf8(%rsp),%eax
  498925:	mov    %r10d,0xb0(%rsp)
  49892d:	mov    %ebx,0x28(%rbp)
  498930:	mov    0x30(%rsp),%r14
  498935:	lea    -0x4(%rax),%r11d
  498939:	mov    %r10d,0x38(%rbp)
  49893d:	mov    %r11d,%eax
  498940:	mov    %edi,0x48(%rbp)
  498943:	and    $0xfffffffc,%eax
  498946:	mov    %r11d,0x2c(%rsp)
  49894b:	lea    0x4(%rax),%edx
  49894e:	xor    %eax,%eax
  498950:	cmpl   $0x3,0x7c(%rsp)
  498955:	cmova  %edx,%eax
  498958:	mov    %edx,0x78(%rsp)
  49895c:	mov    0xb4(%rsp),%edx
  498963:	mov    %eax,0x3c(%rsp)
  498967:	mov    %r11d,%eax
  49896a:	and    $0xfffffffc,%eax
  49896d:	lea    0x4(%rdx,%rax,1),%eax
  498971:	mov    %eax,0xe0(%rsp)
  498978:	nopl   0x0(%rax,%rax,1)
  498980:	mov    0x70(%rsp),%rbx
  498985:	mov    0xb0(%rsp),%r11d
  49898d:	mov    %rbx,%rax
  498990:	mov    %rbx,%rdx
  498993:	mov    %rbx,%rcx
  498996:	mov    %r11,%rsi
  498999:	imul   %r11,%rax
  49899d:	add    $0x4,%esi
  4989a0:	mov    %rbx,%rdi
  4989a3:	mov    %r11,0x178(%rsp)
  4989ab:	imul   %rsi,%rbx
  4989af:	shl    $0x2,%rsi
  4989b3:	mov    %rax,0x168(%rsp)
  4989bb:	lea    0x1(%r11),%eax
  4989bf:	imul   %rax,%rdx
  4989c3:	mov    %rbx,0x148(%rsp)
  4989cb:	shl    $0x2,%rax
  4989cf:	mov    0x40(%rsp),%rbx
  4989d4:	mov    %rdx,0x160(%rsp)
  4989dc:	lea    0x2(%r11),%edx
  4989e0:	imul   %rdx,%rcx
  4989e4:	shl    $0x2,%rdx
  4989e8:	mov    %rcx,0x158(%rsp)
  4989f0:	lea    0x3(%r11),%ecx
  4989f4:	imul   %rcx,%rdi
  4989f8:	shl    $0x2,%rcx
  4989fc:	mov    %rdi,0x150(%rsp)
  498a04:	lea    (%rbx,%rsi,1),%rdi
  498a08:	mov    %rdi,0x1c8(%rsp)
  498a10:	lea    (%r14,%rsi,1),%rdi
  498a14:	mov    %rdi,0x1c0(%rsp)
  498a1c:	lea    (%rbx,%rcx,1),%rdi
  498a20:	add    %r14,%rcx
  498a23:	mov    %rcx,0x1b0(%rsp)
  498a2b:	mov    %rbx,%rcx
  498a2e:	lea    (%rbx,%rdx,1),%rbx
  498a32:	add    %r14,%rdx
  498a35:	mov    %rdx,0x1a0(%rsp)
  498a3d:	mov    %rcx,%rdx
  498a40:	lea    (%rcx,%rax,1),%rcx
  498a44:	add    %r14,%rax
  498a47:	mov    %rax,0x190(%rsp)
  498a4f:	lea    0x0(,%r11,4),%rax
  498a57:	add    %rax,%rdx
  498a5a:	add    %r14,%rax
  498a5d:	mov    %rdi,0x1b8(%rsp)
  498a65:	mov    %rbx,0x1a8(%rsp)
  498a6d:	mov    %rcx,0x198(%rsp)
  498a75:	mov    %rdx,0x188(%rsp)
  498a7d:	mov    %rax,0x180(%rsp)
  498a85:	cmpl   $0x3,0x7c(%rsp)
  498a8a:	jbe    49a1cc <velri_slang_dot_linear_w8a8_f32_packed+0x1b8c>
  498a90:	mov    0xd8(%rsp),%rax
  498a98:	mov    0x160(%rsp),%rdx
  498aa0:	mov    %r14,0x68(%rsp)
  498aa5:	mov    0xb4(%rsp),%r15d
  498aad:	mov    0x1e0(%rsp),%rcx
  498ab5:	mov    %rax,0x1d0(%rsp)
  498abd:	mov    0xf0(%rsp),%rax
  498ac5:	add    %rax,%rdx
  498ac8:	mov    %rdx,0xa8(%rsp)
  498ad0:	mov    0x148(%rsp),%rdx
  498ad8:	add    %rax,%rdx
  498adb:	mov    %rdx,0x60(%rsp)
  498ae0:	mov    0x150(%rsp),%rdx
  498ae8:	add    %rax,%rdx
  498aeb:	mov    %rdx,0x58(%rsp)
  498af0:	mov    0x158(%rsp),%rdx
  498af8:	add    %rax,%rdx
  498afb:	add    0x168(%rsp),%rax
  498b03:	mov    %rdx,0x50(%rsp)
  498b08:	mov    0x1e8(%rsp),%rdx
  498b10:	mov    %rax,0x48(%rsp)
  498b15:	mov    0x10(%rbp),%eax
  498b18:	nopl   0x0(%rax,%rax,1)
  498b20:	mov    0x48(%rbp),%esi
  498b23:	mov    %r15d,%r12d
  498b26:	lea    0x1(%r15),%r11d
  498b2a:	lea    0x2(%r15),%r10d
  498b2e:	lea    0x3(%r15),%r9d
  498b32:	test   %esi,%esi
  498b34:	je     49b180 <velri_slang_dot_linear_w8a8_f32_packed+0x2b40>
  498b3a:	mov    0xe8(%rsp),%r14
  498b42:	mov    %r14,%rdi
  498b45:	mov    %r14,%rbx
  498b48:	mov    %r14,%rsi
  498b4b:	imul   %r12,%rdi
  498b4f:	imul   %r11,%rbx
  498b53:	imul   %r10,%rsi
  498b57:	imul   %r9,%r14
  498b5b:	mov    %rdi,0xd0(%rsp)
  498b63:	mov    %rbx,0xb8(%rsp)
  498b6b:	mov    %rsi,0xc8(%rsp)
  498b73:	mov    %r14,0xc0(%rsp)
  498b7b:	cmpl   $0x3e,0xe4(%rsp)
  498b83:	jbe    49b28c <velri_slang_dot_linear_w8a8_f32_packed+0x2c4c>
  498b89:	mov    0x170(%rsp),%r8
  498b91:	vpxord %xmm18,%xmm18,%xmm18
  498b97:	vmovdqa32 %zmm18,%zmm24
  498b9d:	vmovdqa32 %zmm18,%zmm23
  498ba3:	vmovdqa32 %zmm18,%zmm22
  498ba9:	lea    (%r8,%r14,1),%r13
  498bad:	mov    %r8,%r14
  498bb0:	lea    (%r8,%rsi,1),%r8
  498bb4:	xor    %esi,%esi
  498bb6:	add    %r14,%rbx
  498bb9:	add    %r14,%rdi
  498bbc:	vmovdqa32 %zmm18,%zmm21
  498bc2:	vmovdqa32 %zmm18,%zmm20
  498bc8:	vmovdqa32 %zmm18,%zmm19
  498bce:	vmovdqa32 %zmm18,%zmm6
  498bd4:	vmovdqa32 %zmm18,%zmm7
  498bda:	vmovdqa32 %zmm18,%zmm8
  498be0:	vmovdqa32 %zmm18,%zmm9
  498be6:	vmovdqa32 %zmm18,%zmm10
  498bec:	vmovdqa32 %zmm18,%zmm11
  498bf2:	vmovdqa32 %zmm18,%zmm12
  498bf8:	vmovdqa32 %zmm18,%zmm13
  498bfe:	vmovdqa32 %zmm18,%zmm14
  498c04:	vmovdqa32 %zmm18,%zmm26
  498c0a:	vmovdqa32 %zmm18,%zmm27
  498c10:	vmovdqa32 %zmm18,%zmm28
  498c16:	vmovdqa32 %zmm18,%zmm29
  498c1c:	nopl   0x0(%rax)
  498c20:	mov    0x48(%rsp),%r14
  498c25:	vmovdqu8 (%rdi,%rsi,1),%zmm1
  498c2c:	vmovdqu8 (%rbx,%rsi,1),%zmm3
  498c33:	vmovdqu8 (%r8,%rsi,1),%zmm4
  498c3a:	vmovdqu8 (%r14,%rsi,1),%zmm2
  498c41:	vpmovsxbw %ymm1,%zmm25
  498c47:	mov    0xa8(%rsp),%r14
  498c4f:	vmovdqu8 0x0(%r13,%rsi,1),%zmm5
  498c57:	vpdpbusd %zmm3,%zmm2,%zmm20
  498c5d:	vpmovzxbw %ymm2,%zmm15
  498c63:	vpdpwssd %zmm25,%zmm15,%zmm18
  498c69:	vextracti64x4 $0x1,%zmm2,%ymm25
  498c70:	vpdpbusd %zmm4,%zmm2,%zmm9
  498c76:	vpmovzxbw %ymm25,%zmm15
  498c7c:	vextracti64x4 $0x1,%zmm1,%ymm25
  498c83:	vpdpbusd %zmm5,%zmm2,%zmm14
  498c89:	vpmovsxbw %ymm25,%zmm25
  498c8f:	vpdpwssd %zmm25,%zmm15,%zmm18
  498c95:	vmovdqu8 (%r14,%rsi,1),%zmm25
  498c9c:	mov    0x50(%rsp),%r14
  498ca1:	vpdpbusd %zmm1,%zmm25,%zmm24
  498ca7:	vpdpbusd %zmm3,%zmm25,%zmm19
  498cad:	vpdpbusd %zmm4,%zmm25,%zmm10
  498cb3:	vpdpbusd %zmm5,%zmm25,%zmm26
  498cb9:	vmovdqu8 (%r14,%rsi,1),%zmm25
  498cc0:	mov    0x58(%rsp),%r14
  498cc5:	vpdpbusd %zmm1,%zmm25,%zmm23
  498ccb:	vpdpbusd %zmm3,%zmm25,%zmm6
  498cd1:	vpdpbusd %zmm4,%zmm25,%zmm11
  498cd7:	vpdpbusd %zmm5,%zmm25,%zmm27
  498cdd:	vmovdqu8 (%r14,%rsi,1),%zmm25
  498ce4:	mov    0x60(%rsp),%r14
  498ce9:	vpdpbusd %zmm1,%zmm25,%zmm22
  498cef:	vpdpbusd %zmm3,%zmm25,%zmm7
  498cf5:	vpdpbusd %zmm4,%zmm25,%zmm12
  498cfb:	vpdpbusd %zmm5,%zmm25,%zmm28
  498d01:	vmovdqu8 (%r14,%rsi,1),%zmm25
  498d08:	add    $0x40,%rsi
  498d0c:	vpdpbusd %zmm1,%zmm25,%zmm21
  498d12:	vpdpbusd %zmm3,%zmm25,%zmm8
  498d18:	vpdpbusd %zmm4,%zmm25,%zmm13
  498d1e:	vpdpbusd %zmm5,%zmm25,%zmm29
  498d24:	cmp    %rsi,0xa0(%rsp)
  498d2c:	jne    498c20 <velri_slang_dot_linear_w8a8_f32_packed+0x5e0>
  498d32:	vextracti32x8 $0x1,%zmm18,%ymm25
  498d39:	vpaddd %ymm18,%ymm25,%ymm3
  498d3f:	vextracti32x4 $0x1,%ymm3,%xmm18
  498d46:	vpaddd %xmm3,%xmm18,%xmm25
  498d4c:	vpsrldq $0x8,%xmm25,%xmm18
  498d53:	vpaddd %xmm18,%xmm25,%xmm18
  498d59:	vpsrldq $0x4,%xmm18,%xmm25
  498d60:	vpaddd %xmm25,%xmm18,%xmm18
  498d66:	vmovd  %xmm18,%r8d
  498d6c:	vextracti32x8 $0x1,%zmm24,%ymm18
  498d73:	vpaddd %ymm24,%ymm18,%ymm25
  498d79:	vextracti32x4 $0x1,%ymm25,%xmm18
  498d80:	vpaddd %xmm25,%xmm18,%xmm24
  498d86:	vpsrldq $0x8,%xmm24,%xmm18
  498d8d:	vpaddd %xmm18,%xmm24,%xmm18
  498d93:	vpsrldq $0x4,%xmm18,%xmm24
  498d9a:	vpaddd %xmm24,%xmm18,%xmm18
  498da0:	vmovd  %xmm18,0x10c(%rsp)
  498da8:	vextracti32x8 $0x1,%zmm23,%ymm18
  498daf:	vpaddd %ymm23,%ymm18,%ymm24
  498db5:	vextracti32x4 $0x1,%ymm24,%xmm18
  498dbc:	vpaddd %xmm24,%xmm18,%xmm23
  498dc2:	vpsrldq $0x8,%xmm23,%xmm18
  498dc9:	vpaddd %xmm18,%xmm23,%xmm18
  498dcf:	vpsrldq $0x4,%xmm18,%xmm23
  498dd6:	vpaddd %xmm23,%xmm18,%xmm18
  498ddc:	vmovd  %xmm18,0x110(%rsp)
  498de4:	vextracti32x8 $0x1,%zmm22,%ymm18
  498deb:	vpaddd %ymm22,%ymm18,%ymm23
  498df1:	vextracti32x4 $0x1,%ymm23,%xmm18
  498df8:	vpaddd %xmm23,%xmm18,%xmm22
  498dfe:	vpsrldq $0x8,%xmm22,%xmm18
  498e05:	vpaddd %xmm18,%xmm22,%xmm18
  498e0b:	vpsrldq $0x4,%xmm18,%xmm22
  498e12:	vpaddd %xmm22,%xmm18,%xmm18
  498e18:	vmovd  %xmm18,0x108(%rsp)
  498e20:	vextracti32x8 $0x1,%zmm21,%ymm18
  498e27:	vpaddd %ymm21,%ymm18,%ymm22
  498e2d:	vextracti32x4 $0x1,%ymm22,%xmm18
  498e34:	vpaddd %xmm22,%xmm18,%xmm21
  498e3a:	vpsrldq $0x8,%xmm21,%xmm18
  498e41:	vpaddd %xmm18,%xmm21,%xmm18
  498e47:	vpsrldq $0x4,%xmm18,%xmm21
  498e4e:	vpaddd %xmm21,%xmm18,%xmm18
  498e54:	vmovd  %xmm18,0x114(%rsp)
  498e5c:	vextracti32x8 $0x1,%zmm20,%ymm18
  498e63:	vpaddd %ymm20,%ymm18,%ymm21
  498e69:	vextracti32x4 $0x1,%ymm21,%xmm18
  498e70:	vpaddd %xmm21,%xmm18,%xmm20
  498e76:	vpsrldq $0x8,%xmm20,%xmm18
  498e7d:	vpaddd %xmm18,%xmm20,%xmm18
  498e83:	vpsrldq $0x4,%xmm18,%xmm20
  498e8a:	vpaddd %xmm20,%xmm18,%xmm18
  498e90:	vmovd  %xmm18,0x118(%rsp)
  498e98:	vextracti32x8 $0x1,%zmm19,%ymm18
  498e9f:	vpaddd %ymm19,%ymm18,%ymm20
  498ea5:	vextracti32x4 $0x1,%ymm20,%xmm18
  498eac:	vpaddd %xmm20,%xmm18,%xmm19
  498eb2:	vpsrldq $0x8,%xmm19,%xmm18
  498eb9:	vpaddd %xmm18,%xmm19,%xmm18
  498ebf:	vpsrldq $0x4,%xmm18,%xmm19
  498ec6:	vpaddd %xmm19,%xmm18,%xmm18
  498ecc:	vmovd  %xmm18,0x11c(%rsp)
  498ed4:	vextracti32x8 $0x1,%zmm6,%ymm18
  498edb:	vpaddd %ymm6,%ymm18,%ymm6
  498ee1:	vextracti32x4 $0x1,%ymm6,%xmm18
  498ee8:	vpaddd %xmm6,%xmm18,%xmm19
  498eee:	vpsrldq $0x8,%xmm19,%xmm18
  498ef5:	vpaddd %xmm18,%xmm19,%xmm18
  498efb:	vpsrldq $0x4,%xmm18,%xmm19
  498f02:	vpaddd %xmm19,%xmm18,%xmm18
  498f08:	vmovd  %xmm18,0x120(%rsp)
  498f10:	vextracti32x8 $0x1,%zmm7,%ymm18
  498f17:	vpaddd %ymm7,%ymm18,%ymm7
  498f1d:	vextracti32x4 $0x1,%ymm7,%xmm18
  498f24:	vpaddd %xmm7,%xmm18,%xmm19
  498f2a:	vpsrldq $0x8,%xmm19,%xmm18
  498f31:	vpaddd %xmm18,%xmm19,%xmm18
  498f37:	vpsrldq $0x4,%xmm18,%xmm19
  498f3e:	vpaddd %xmm19,%xmm18,%xmm18
  498f44:	vmovd  %xmm18,0x124(%rsp)
  498f4c:	vextracti32x8 $0x1,%zmm8,%ymm18
  498f53:	vpaddd %ymm8,%ymm18,%ymm8
  498f59:	vextracti32x4 $0x1,%ymm8,%xmm18
  498f60:	vpaddd %xmm8,%xmm18,%xmm19
  498f66:	vpsrldq $0x8,%xmm19,%xmm18
  498f6d:	vpaddd %xmm18,%xmm19,%xmm18
  498f73:	vpsrldq $0x4,%xmm18,%xmm19
  498f7a:	vpaddd %xmm19,%xmm18,%xmm18
  498f80:	vmovd  %xmm18,0x128(%rsp)
  498f88:	vextracti32x8 $0x1,%zmm9,%ymm18
  498f8f:	vpaddd %ymm9,%ymm18,%ymm9
  498f95:	vextracti32x4 $0x1,%ymm9,%xmm18
  498f9c:	vpaddd %xmm9,%xmm18,%xmm19
  498fa2:	vpsrldq $0x8,%xmm19,%xmm18
  498fa9:	vpaddd %xmm18,%xmm19,%xmm18
  498faf:	vpsrldq $0x4,%xmm18,%xmm19
  498fb6:	vpaddd %xmm19,%xmm18,%xmm18
  498fbc:	vmovd  %xmm18,0x12c(%rsp)
  498fc4:	vextracti32x8 $0x1,%zmm10,%ymm18
  498fcb:	vpaddd %ymm10,%ymm18,%ymm10
  498fd1:	vextracti32x4 $0x1,%ymm10,%xmm18
  498fd8:	vpaddd %xmm10,%xmm18,%xmm19
  498fde:	vpsrldq $0x8,%xmm19,%xmm18
  498fe5:	vpaddd %xmm18,%xmm19,%xmm18
  498feb:	vpsrldq $0x4,%xmm18,%xmm19
  498ff2:	vpaddd %xmm19,%xmm18,%xmm18
  498ff8:	vmovd  %xmm18,0x130(%rsp)
  499000:	vextracti32x8 $0x1,%zmm11,%ymm18
  499007:	vpaddd %ymm11,%ymm18,%ymm11
  49900d:	vextracti32x4 $0x1,%ymm11,%xmm18
  499014:	vpaddd %xmm11,%xmm18,%xmm19
  49901a:	vpsrldq $0x8,%xmm19,%xmm18
  499021:	vpaddd %xmm18,%xmm19,%xmm18
  499027:	vpsrldq $0x4,%xmm18,%xmm19
  49902e:	vpaddd %xmm19,%xmm18,%xmm18
  499034:	vmovd  %xmm18,0x134(%rsp)
  49903c:	vextracti32x8 $0x1,%zmm12,%ymm18
  499043:	vpaddd %ymm12,%ymm18,%ymm12
  499049:	vextracti32x4 $0x1,%ymm12,%xmm18
  499050:	vpaddd %xmm12,%xmm18,%xmm19
  499056:	vpsrldq $0x8,%xmm19,%xmm18
  49905d:	vpaddd %xmm18,%xmm19,%xmm18
  499063:	vpsrldq $0x4,%xmm18,%xmm19
  49906a:	vpaddd %xmm19,%xmm18,%xmm18
  499070:	vmovd  %xmm18,0x138(%rsp)
  499078:	vextracti32x8 $0x1,%zmm13,%ymm18
  49907f:	vpaddd %ymm13,%ymm18,%ymm13
  499085:	vextracti32x4 $0x1,%ymm13,%xmm18
  49908c:	vpaddd %xmm13,%xmm18,%xmm19
  499092:	vpsrldq $0x8,%xmm19,%xmm18
  499099:	vpaddd %xmm18,%xmm19,%xmm18
  49909f:	vpsrldq $0x4,%xmm18,%xmm19
  4990a6:	vpaddd %xmm19,%xmm18,%xmm18
  4990ac:	vmovd  %xmm18,0x13c(%rsp)
  4990b4:	vextracti32x8 $0x1,%zmm14,%ymm18
  4990bb:	vpaddd %ymm14,%ymm18,%ymm14
  4990c1:	vextracti32x4 $0x1,%ymm14,%xmm18
  4990c8:	vpaddd %xmm14,%xmm18,%xmm19
  4990ce:	vpsrldq $0x8,%xmm19,%xmm18
  4990d5:	vpaddd %xmm18,%xmm19,%xmm18
  4990db:	vpsrldq $0x4,%xmm18,%xmm19
  4990e2:	vpaddd %xmm19,%xmm18,%xmm18
  4990e8:	vmovd  %xmm18,0x140(%rsp)
  4990f0:	vextracti32x8 $0x1,%zmm26,%ymm18
  4990f7:	vpaddd %ymm26,%ymm18,%ymm26
  4990fd:	vextracti32x4 $0x1,%ymm26,%xmm18
  499104:	vpaddd %xmm26,%xmm18,%xmm19
  49910a:	vpsrldq $0x8,%xmm19,%xmm18
  499111:	vpaddd %xmm18,%xmm19,%xmm18
  499117:	vpsrldq $0x4,%xmm18,%xmm19
  49911e:	vpaddd %xmm19,%xmm18,%xmm18
  499124:	vmovd  %xmm18,0x144(%rsp)
  49912c:	vextracti32x8 $0x1,%zmm27,%ymm18
  499133:	vpaddd %ymm27,%ymm18,%ymm27
  499139:	vextracti32x4 $0x1,%ymm27,%xmm18
  499140:	vpaddd %xmm27,%xmm18,%xmm19
  499146:	vpsrldq $0x8,%xmm19,%xmm18
  49914d:	vpaddd %xmm18,%xmm19,%xmm18
  499153:	vpsrldq $0x4,%xmm18,%xmm19
  49915a:	vpaddd %xmm19,%xmm18,%xmm18
  499160:	vmovd  %xmm18,0x100(%rsp)
  499168:	vextracti32x8 $0x1,%zmm28,%ymm18
  49916f:	vpaddd %ymm28,%ymm18,%ymm28
  499175:	vextracti32x4 $0x1,%ymm28,%xmm18
  49917c:	vpaddd %xmm28,%xmm18,%xmm19
  499182:	vpsrldq $0x8,%xmm19,%xmm18
  499189:	vpaddd %xmm18,%xmm19,%xmm18
  49918f:	vpsrldq $0x4,%xmm18,%xmm19
  499196:	vpaddd %xmm19,%xmm18,%xmm18
  49919c:	vmovd  %xmm18,0xfc(%rsp)
  4991a4:	vextracti32x8 $0x1,%zmm29,%ymm18
  4991ab:	vpaddd %ymm29,%ymm18,%ymm29
  4991b1:	vextracti32x4 $0x1,%ymm29,%xmm18
  4991b8:	vpaddd %xmm29,%xmm18,%xmm19
  4991be:	vpsrldq $0x8,%xmm19,%xmm18
  4991c5:	vpaddd %xmm18,%xmm19,%xmm18
  4991cb:	vpsrldq $0x4,%xmm18,%xmm19
  4991d2:	vpaddd %xmm19,%xmm18,%xmm18
  4991d8:	vmovd  %xmm18,0x104(%rsp)
  4991e0:	testb  $0x3f,0x48(%rbp)
  4991e4:	je     49992d <velri_slang_dot_linear_w8a8_f32_packed+0x12ed>
  4991ea:	mov    0x48(%rbp),%r14d
  4991ee:	vmovdqa32 %ymm27,%ymm2
  4991f4:	vmovdqa32 %ymm7,%ymm30
  4991fa:	vmovdqa32 %ymm26,%ymm27
  499200:	vmovdqa32 %ymm20,%ymm19
  499206:	vmovdqa32 %ymm22,%ymm16
  49920c:	vmovdqa %ymm6,0x80(%rsp)
  499215:	vmovdqa32 %ymm29,%ymm4
  49921b:	and    $0xffffffc0,%r14d
  49921f:	vmovdqa32 %ymm28,%ymm1
  499225:	vmovdqa32 %ymm14,%ymm18
  49922b:	vmovdqa %ymm13,%ymm5
  49922f:	vmovdqa32 %ymm12,%ymm17
  499235:	vmovdqa32 %ymm11,%ymm31
  49923b:	vmovdqa32 %ymm10,%ymm26
  499241:	vmovdqa %ymm8,%ymm15
  499246:	vmovdqa32 %ymm23,%ymm22
  49924c:	vmovdqa32 %ymm24,%ymm20
  499252:	vmovdqa32 %ymm25,%ymm7
  499258:	vmovdqa %ymm3,%ymm6
  49925c:	mov    0x48(%rbp),%r13d
  499260:	sub    %r14d,%r13d
  499263:	lea    -0x1(%r13),%esi
  499267:	cmp    $0x1e,%esi
  49926a:	jbe    49973b <velri_slang_dot_linear_w8a8_f32_packed+0x10fb>
  499270:	mov    %r14d,%esi
  499273:	mov    0x170(%rsp),%r8
  49927b:	mov    0xd0(%rsp),%rdi
  499283:	vmovdqa %ymm6,%ymm3
  499287:	vmovdqu8 (%rbx,%rsi,1),%ymm14
  49928e:	vmovdqa32 %ymm27,%ymm29
  499294:	vmovdqa32 %ymm18,%ymm28
  49929a:	add    %r8,%rdi
  49929d:	vmovdqu8 (%rdi,%rsi,1),%ymm10
  4992a4:	mov    0xc8(%rsp),%rdi
  4992ac:	add    %r8,%rdi
  4992af:	vpmovsxbw %xmm10,%ymm23
  4992b5:	vmovdqu8 (%rdi,%rsi,1),%ymm13
  4992bc:	mov    0xc0(%rsp),%rdi
  4992c4:	add    %r8,%rdi
  4992c7:	vmovdqu8 (%rdi,%rsi,1),%ymm12
  4992ce:	mov    0x168(%rsp),%rdi
  4992d6:	add    0xf0(%rsp),%rsi
  4992de:	vmovdqu8 (%rsi,%rdi,1),%ymm11
  4992e5:	mov    0x160(%rsp),%rdi
  4992ed:	vpdpbusd %ymm13,%ymm11,%ymm9
  4992f3:	vmovdqu8 (%rsi,%rdi,1),%ymm6
  4992fa:	vpmovzxbw %xmm11,%ymm8
  4992ff:	mov    0x158(%rsp),%rdi
  499307:	vpdpwssd %ymm8,%ymm23,%ymm3
  49930d:	vmovdqa32 %ymm20,%ymm8
  499313:	vmovdqa32 0x80(%rsp),%ymm20
  49931b:	vpdpbusd %ymm10,%ymm6,%ymm7
  499321:	vpdpbusd %ymm13,%ymm6,%ymm26
  499327:	vpdpbusd %ymm14,%ymm6,%ymm19
  49932d:	vpdpbusd %ymm12,%ymm6,%ymm29
  499333:	vmovdqu8 (%rsi,%rdi,1),%ymm6
  49933a:	mov    0x150(%rsp),%rdi
  499342:	vpdpbusd %ymm14,%ymm11,%ymm21
  499348:	vmovdqa32 %ymm9,%ymm24
  49934e:	vpdpbusd %ymm10,%ymm6,%ymm8
  499354:	vpdpbusd %ymm14,%ymm6,%ymm20
  49935a:	vmovdqa %ymm7,%ymm9
  49935e:	vmovdqa32 %ymm22,%ymm7
  499364:	vpdpbusd %ymm13,%ymm6,%ymm31
  49936a:	vpdpbusd %ymm12,%ymm6,%ymm2
  499370:	vmovdqu8 (%rsi,%rdi,1),%ymm6
  499377:	mov    0x148(%rsp),%rdi
  49937f:	vpdpbusd %ymm12,%ymm11,%ymm28
  499385:	vextracti32x4 $0x1,%ymm11,%xmm11
  49938c:	vpdpbusd %ymm10,%ymm6,%ymm7
  499392:	vmovdqu8 (%rsi,%rdi,1),%ymm18
  499399:	vpmovzxbw %xmm11,%ymm11
  49939e:	vpdpbusd %ymm14,%ymm6,%ymm30
  4993a4:	vpdpbusd %ymm13,%ymm6,%ymm17
  4993aa:	vpdpbusd %ymm12,%ymm6,%ymm1
  4993b0:	vmovdqa32 %ymm16,%ymm6
  4993b6:	vpdpbusd %ymm10,%ymm18,%ymm6
  4993bc:	vextracti32x4 $0x1,%ymm10,%xmm10
  4993c3:	vpdpbusd %ymm12,%ymm18,%ymm4
  4993c9:	vpmovsxbw %xmm10,%ymm12
  4993ce:	vpdpwssd %ymm11,%ymm12,%ymm3
  4993d4:	vpdpbusd %ymm14,%ymm18,%ymm15
  4993da:	vpdpbusd %ymm13,%ymm18,%ymm5
  4993e0:	vextracti32x4 $0x1,%ymm3,%xmm11
  4993e7:	vpaddd %xmm3,%xmm11,%xmm10
  4993eb:	vpsrldq $0x8,%xmm10,%xmm11
  4993f1:	vpaddd %xmm11,%xmm10,%xmm10
  4993f6:	vpsrldq $0x4,%xmm10,%xmm11
  4993fc:	vpaddd %xmm11,%xmm10,%xmm10
  499401:	vmovd  %xmm10,%r8d
  499406:	vextracti32x4 $0x1,%ymm9,%xmm10
  49940d:	vpaddd %xmm9,%xmm10,%xmm9
  499412:	vpsrldq $0x8,%xmm9,%xmm10
  499418:	vpaddd %xmm10,%xmm9,%xmm9
  49941d:	vpsrldq $0x4,%xmm9,%xmm10
  499423:	vpaddd %xmm10,%xmm9,%xmm9
  499428:	vmovd  %xmm9,0x10c(%rsp)
  499431:	vextracti32x4 $0x1,%ymm8,%xmm9
  499438:	vpaddd %xmm8,%xmm9,%xmm8
  49943d:	vpsrldq $0x8,%xmm8,%xmm9
  499443:	vpaddd %xmm9,%xmm8,%xmm8
  499448:	vpsrldq $0x4,%xmm8,%xmm9
  49944e:	vpaddd %xmm9,%xmm8,%xmm8
  499453:	vmovd  %xmm8,0x110(%rsp)
  49945c:	vextracti32x4 $0x1,%ymm7,%xmm8
  499463:	vpaddd %xmm7,%xmm8,%xmm7
  499467:	vpsrldq $0x8,%xmm7,%xmm8
  49946c:	vpaddd %xmm8,%xmm7,%xmm7
  499471:	vpsrldq $0x4,%xmm7,%xmm8
  499476:	vpaddd %xmm8,%xmm7,%xmm7
  49947b:	vmovd  %xmm7,0x108(%rsp)
  499484:	vextracti32x4 $0x1,%ymm6,%xmm7
  49948b:	vpaddd %xmm6,%xmm7,%xmm6
  49948f:	vpsrldq $0x8,%xmm6,%xmm7
  499494:	vpaddd %xmm7,%xmm6,%xmm6
  499498:	vpsrldq $0x4,%xmm6,%xmm7
  49949d:	vpaddd %xmm7,%xmm6,%xmm6
  4994a1:	vmovd  %xmm6,0x114(%rsp)
  4994aa:	vextracti32x4 $0x1,%ymm21,%xmm6
  4994b1:	vpaddd %xmm21,%xmm6,%xmm21
  4994b7:	vpsrldq $0x8,%xmm21,%xmm6
  4994be:	vpaddd %xmm6,%xmm21,%xmm6
  4994c4:	vpsrldq $0x4,%xmm6,%xmm7
  4994c9:	vpaddd %xmm7,%xmm6,%xmm6
  4994cd:	vmovd  %xmm6,0x118(%rsp)
  4994d6:	vextracti32x4 $0x1,%ymm19,%xmm6
  4994dd:	vpaddd %xmm19,%xmm6,%xmm19
  4994e3:	vpsrldq $0x8,%xmm19,%xmm6
  4994ea:	vpaddd %xmm6,%xmm19,%xmm6
  4994f0:	vpsrldq $0x4,%xmm6,%xmm7
  4994f5:	vpaddd %xmm7,%xmm6,%xmm6
  4994f9:	vmovd  %xmm6,0x11c(%rsp)
  499502:	vextracti32x4 $0x1,%ymm20,%xmm6
  499509:	vpaddd %xmm20,%xmm6,%xmm20
  49950f:	vpsrldq $0x8,%xmm20,%xmm6
  499516:	vpaddd %xmm6,%xmm20,%xmm6
  49951c:	vpsrldq $0x4,%xmm6,%xmm7
  499521:	vpaddd %xmm7,%xmm6,%xmm6
  499525:	vmovd  %xmm6,0x120(%rsp)
  49952e:	vextracti32x4 $0x1,%ymm30,%xmm6
  499535:	vpaddd %xmm30,%xmm6,%xmm22
  49953b:	vpsrldq $0x8,%xmm22,%xmm6
  499542:	vpaddd %xmm6,%xmm22,%xmm6
  499548:	vpsrldq $0x4,%xmm6,%xmm7
  49954d:	vpaddd %xmm7,%xmm6,%xmm6
  499551:	vmovd  %xmm6,0x124(%rsp)
  49955a:	vextracti32x4 $0x1,%ymm15,%xmm6
  499561:	vpaddd %xmm15,%xmm6,%xmm23
  499567:	vpsrldq $0x8,%xmm23,%xmm6
  49956e:	vpaddd %xmm6,%xmm23,%xmm6
  499574:	vpsrldq $0x4,%xmm6,%xmm7
  499579:	vpaddd %xmm7,%xmm6,%xmm6
  49957d:	vmovd  %xmm6,0x128(%rsp)
  499586:	vextracti32x4 $0x1,%ymm24,%xmm6
  49958d:	vpaddd %xmm24,%xmm6,%xmm24
  499593:	vpsrldq $0x8,%xmm24,%xmm6
  49959a:	vpaddd %xmm6,%xmm24,%xmm6
  4995a0:	vpsrldq $0x4,%xmm6,%xmm7
  4995a5:	vpaddd %xmm7,%xmm6,%xmm6
  4995a9:	vmovd  %xmm6,0x12c(%rsp)
  4995b2:	vextracti32x4 $0x1,%ymm26,%xmm6
  4995b9:	vpaddd %xmm26,%xmm6,%xmm25
  4995bf:	vpsrldq $0x8,%xmm25,%xmm6
  4995c6:	vpaddd %xmm6,%xmm25,%xmm6
  4995cc:	vpsrldq $0x4,%xmm6,%xmm7
  4995d1:	vpaddd %xmm7,%xmm6,%xmm6
  4995d5:	vmovd  %xmm6,0x130(%rsp)
  4995de:	vextracti32x4 $0x1,%ymm31,%xmm6
  4995e5:	vpaddd %xmm31,%xmm6,%xmm26
  4995eb:	vpsrldq $0x8,%xmm26,%xmm6
  4995f2:	vpaddd %xmm6,%xmm26,%xmm6
  4995f8:	vpsrldq $0x4,%xmm6,%xmm7
  4995fd:	vpaddd %xmm7,%xmm6,%xmm6
  499601:	vmovd  %xmm6,0x134(%rsp)
  49960a:	vextracti32x4 $0x1,%ymm17,%xmm6
  499611:	vpaddd %xmm17,%xmm6,%xmm27
  499617:	vpsrldq $0x8,%xmm27,%xmm6
  49961e:	vpaddd %xmm6,%xmm27,%xmm6
  499624:	vpsrldq $0x4,%xmm6,%xmm7
  499629:	vpaddd %xmm7,%xmm6,%xmm6
  49962d:	vmovd  %xmm6,0x138(%rsp)
  499636:	vextracti32x4 $0x1,%ymm5,%xmm6
  49963d:	vpaddd %xmm5,%xmm6,%xmm14
  499641:	vpsrldq $0x8,%xmm14,%xmm6
  499647:	vpaddd %xmm6,%xmm14,%xmm6
  49964b:	vpsrldq $0x4,%xmm6,%xmm7
  499650:	vpaddd %xmm7,%xmm6,%xmm6
  499654:	vmovd  %xmm6,0x13c(%rsp)
  49965d:	vextracti32x4 $0x1,%ymm28,%xmm6
  499664:	vpaddd %xmm28,%xmm6,%xmm28
  49966a:	vpsrldq $0x8,%xmm28,%xmm6
  499671:	vpaddd %xmm6,%xmm28,%xmm6
  499677:	vpsrldq $0x4,%xmm6,%xmm7
  49967c:	vpaddd %xmm7,%xmm6,%xmm6
  499680:	vmovd  %xmm6,0x140(%rsp)
  499689:	vextracti32x4 $0x1,%ymm29,%xmm6
  499690:	vpaddd %xmm29,%xmm6,%xmm29
  499696:	vpsrldq $0x8,%xmm29,%xmm6
  49969d:	vpaddd %xmm6,%xmm29,%xmm6
  4996a3:	vpsrldq $0x4,%xmm6,%xmm7
  4996a8:	vpaddd %xmm7,%xmm6,%xmm6
  4996ac:	vextracti32x4 $0x1,%ymm2,%xmm7
  4996b3:	vmovd  %xmm6,0x144(%rsp)
  4996bc:	vpaddd %xmm2,%xmm7,%xmm6
  4996c0:	vpsrldq $0x8,%xmm6,%xmm7
  4996c5:	vpaddd %xmm7,%xmm6,%xmm6
  4996c9:	vpsrldq $0x4,%xmm6,%xmm7
  4996ce:	vpaddd %xmm7,%xmm6,%xmm6
  4996d2:	vextracti32x4 $0x1,%ymm1,%xmm7
  4996d9:	vmovd  %xmm6,0x100(%rsp)
  4996e2:	vpaddd %xmm1,%xmm7,%xmm6
  4996e6:	vpsrldq $0x8,%xmm6,%xmm7
  4996eb:	vpaddd %xmm7,%xmm6,%xmm6
  4996ef:	vpsrldq $0x4,%xmm6,%xmm7
  4996f4:	vpaddd %xmm7,%xmm6,%xmm6
  4996f8:	vmovd  %xmm6,0xfc(%rsp)
  499701:	vextracti32x4 $0x1,%ymm4,%xmm6
  499708:	vpaddd %xmm4,%xmm6,%xmm13
  49970c:	vpsrldq $0x8,%xmm13,%xmm6
  499712:	vpaddd %xmm6,%xmm13,%xmm6
  499716:	vpsrldq $0x4,%xmm6,%xmm7
  49971b:	vpaddd %xmm7,%xmm6,%xmm6
  49971f:	vmovd  %xmm6,0x104(%rsp)
  499728:	test   $0x1f,%r13b
  49972c:	je     49992d <velri_slang_dot_linear_w8a8_f32_packed+0x12ed>
  499732:	mov    %r13d,%esi
  499735:	and    $0xffffffe0,%esi
  499738:	add    %esi,%r14d
  49973b:	mov    %eax,0x10(%rbp)
  49973e:	mov    %r14d,%r13d
  499741:	vmovq  %r12,%xmm5
  499746:	vmovq  %r11,%xmm2
  49974b:	lea    (%rbx,%r13,1),%rdi
  49974f:	mov    %r15d,0x80(%rsp)
  499757:	add    0xa8(%rsp),%r13
  49975f:	vmovq  %r10,%xmm4
  499764:	vmovq  %r9,%xmm3
  499769:	vmovq  %rcx,%xmm7
  49976e:	vmovq  %rdx,%xmm1
  499773:	xchg   %ax,%ax
  499775:	data16 cs nopw 0x0(%rax,%rax,1)
  499780:	mov    0xd0(%rsp),%rax
  499788:	mov    %rdi,%rsi
  49978b:	movsbl (%rdi),%r9d
  49978f:	sub    0xb8(%rsp),%rsi
  499797:	mov    0x150(%rsp),%r11
  49979f:	movsbl (%rsi,%rax,1),%r10d
  4997a4:	mov    0xc8(%rsp),%rax
  4997ac:	mov    0x158(%rsp),%r15
  4997b4:	movsbl (%rsi,%rax,1),%ecx
  4997b8:	mov    0xc0(%rsp),%rax
  4997c0:	movsbl (%rsi,%rax,1),%edx
  4997c4:	mov    0x168(%rsp),%rax
  4997cc:	mov    %r13,%rsi
  4997cf:	sub    0x160(%rsp),%rsi
  4997d7:	movzbl (%rsi,%r11,1),%r12d
  4997dc:	mov    0x148(%rsp),%r11
  4997e4:	movzbl (%rsi,%rax,1),%ebx
  4997e8:	movzbl (%rsi,%r15,1),%r15d
  4997ed:	movzbl (%rsi,%r11,1),%r11d
  4997f2:	mov    %r10d,%esi
  4997f5:	movzbl 0x0(%r13),%eax
  4997fa:	imul   %ebx,%esi
  4997fd:	add    %esi,%r8d
  499800:	mov    %r10d,%esi
  499803:	imul   %eax,%esi
  499806:	add    %esi,0x10c(%rsp)
  49980d:	mov    %r15d,%esi
  499810:	imul   %r10d,%esi
  499814:	add    %esi,0x110(%rsp)
  49981b:	mov    %r12d,%esi
  49981e:	imul   %r10d,%esi
  499822:	add    %esi,0x108(%rsp)
  499829:	mov    %r9d,%esi
  49982c:	imul   %ebx,%esi
  49982f:	add    %esi,0x118(%rsp)
  499836:	mov    %r9d,%esi
  499839:	imul   %eax,%esi
  49983c:	add    %esi,0x11c(%rsp)
  499843:	mov    %r15d,%esi
  499846:	imul   %r9d,%esi
  49984a:	add    %esi,0x120(%rsp)
  499851:	mov    %r12d,%esi
  499854:	imul   %r9d,%esi
  499858:	imul   %r11d,%r10d
  49985c:	add    %r10d,0x114(%rsp)
  499864:	add    %esi,0x124(%rsp)
  49986b:	imul   %r11d,%r9d
  49986f:	mov    %ecx,%esi
  499871:	imul   %ebx,%esi
  499874:	add    %esi,0x12c(%rsp)
  49987b:	mov    %ecx,%esi
  49987d:	imul   %eax,%esi
  499880:	add    %esi,0x130(%rsp)
  499887:	mov    %r15d,%esi
  49988a:	imul   %ecx,%esi
  49988d:	add    %esi,0x134(%rsp)
  499894:	mov    %r12d,%esi
  499897:	imul   %ecx,%esi
  49989a:	add    %esi,0x138(%rsp)
  4998a1:	mov    %r11d,%esi
  4998a4:	imul   %r11d,%ecx
  4998a8:	add    %ecx,0x13c(%rsp)
  4998af:	mov    %r15d,%ecx
  4998b2:	add    %r9d,0x128(%rsp)
  4998ba:	imul   %edx,%ebx
  4998bd:	add    $0x1,%r14d
  4998c1:	add    $0x1,%rdi
  4998c5:	imul   %edx,%eax
  4998c8:	add    %ebx,0x140(%rsp)
  4998cf:	add    $0x1,%r13
  4998d3:	imul   %edx,%ecx
  4998d6:	add    %eax,0x144(%rsp)
  4998dd:	imul   %edx,%r12d
  4998e1:	add    %ecx,0x100(%rsp)
  4998e8:	imul   %edx,%esi
  4998eb:	add    %r12d,0xfc(%rsp)
  4998f3:	add    %esi,0x104(%rsp)
  4998fa:	cmp    0x48(%rbp),%r14d
  4998fe:	jb     499780 <velri_slang_dot_linear_w8a8_f32_packed+0x1140>
  499904:	mov    0x10(%rbp),%eax
  499907:	mov    0x80(%rsp),%r15d
  49990f:	vmovq  %xmm5,%r12
  499914:	vmovq  %xmm2,%r11
  499919:	vmovq  %xmm4,%r10
  49991e:	vmovq  %xmm3,%r9
  499923:	vmovq  %xmm7,%rcx
  499928:	vmovq  %xmm1,%rdx
  49992d:	mov    0x1d0(%rsp),%rbx
  499935:	mov    0x1d8(%rsp),%rsi
  49993d:	mov    (%rbx),%r13d
  499940:	imul   %r12,%rsi
  499944:	add    0x178(%rsp),%rsi
  49994c:	shl    $0x2,%rsi
  499950:	sub    %r13d,%r8d
  499953:	lea    (%rcx,%rsi,1),%r14
  499957:	vcvtsi2ss %r8d,%xmm0,%xmm6
  49995c:	test   $0x4,%al
  49995e:	je     49a190 <velri_slang_dot_linear_w8a8_f32_packed+0x1b50>
  499964:	mov    0x188(%rsp),%rbx
  49996c:	vmovss (%rbx),%xmm8
  499970:	test   $0x2,%al
  499972:	je     49997a <velri_slang_dot_linear_w8a8_f32_packed+0x133a>
  499974:	vmulss (%rdx,%r12,4),%xmm8,%xmm8
  49997a:	vmulss %xmm8,%xmm6,%xmm6
  49997f:	test   $0x1,%al
  499981:	je     49998f <velri_slang_dot_linear_w8a8_f32_packed+0x134f>
  499983:	mov    0x180(%rsp),%rbx
  49998b:	vaddss (%rbx),%xmm6,%xmm6
  49998f:	mov    0x10c(%rsp),%edi
  499996:	vmovss %xmm6,(%r14)
  49999b:	lea    0x4(%rcx,%rsi,1),%r8
  4999a0:	sub    %r13d,%edi
  4999a3:	vcvtsi2ss %edi,%xmm0,%xmm6
  4999a7:	test   $0x4,%al
  4999a9:	je     49a180 <velri_slang_dot_linear_w8a8_f32_packed+0x1b40>
  4999af:	mov    0x198(%rsp),%rbx
  4999b7:	vmovss (%rbx),%xmm8
  4999bb:	test   $0x2,%al
  4999bd:	je     4999c5 <velri_slang_dot_linear_w8a8_f32_packed+0x1385>
  4999bf:	vmulss (%rdx,%r12,4),%xmm8,%xmm8
  4999c5:	vmulss %xmm8,%xmm6,%xmm6
  4999ca:	test   $0x1,%al
  4999cc:	je     4999da <velri_slang_dot_linear_w8a8_f32_packed+0x139a>
  4999ce:	mov    0x190(%rsp),%rbx
  4999d6:	vaddss (%rbx),%xmm6,%xmm6
  4999da:	mov    0x110(%rsp),%edi
  4999e1:	vmovss %xmm6,(%r8)
  4999e6:	lea    0x8(%rcx,%rsi,1),%r8
  4999eb:	sub    %r13d,%edi
  4999ee:	vcvtsi2ss %edi,%xmm0,%xmm6
  4999f2:	test   $0x4,%al
  4999f4:	je     49a170 <velri_slang_dot_linear_w8a8_f32_packed+0x1b30>
  4999fa:	mov    0x1a8(%rsp),%rbx
  499a02:	vmovss (%rbx),%xmm8
  499a06:	test   $0x2,%al
  499a08:	je     499a10 <velri_slang_dot_linear_w8a8_f32_packed+0x13d0>
  499a0a:	vmulss (%rdx,%r12,4),%xmm8,%xmm8
  499a10:	vmulss %xmm8,%xmm6,%xmm6
  499a15:	test   $0x1,%al
  499a17:	je     499a25 <velri_slang_dot_linear_w8a8_f32_packed+0x13e5>
  499a19:	mov    0x1a0(%rsp),%rbx
  499a21:	vaddss (%rbx),%xmm6,%xmm6
  499a25:	mov    0x108(%rsp),%edi
  499a2c:	vmovss %xmm6,(%r8)
  499a31:	lea    0xc(%rcx,%rsi,1),%r8
  499a36:	sub    %r13d,%edi
  499a39:	vcvtsi2ss %edi,%xmm0,%xmm6
  499a3d:	test   $0x4,%al
  499a3f:	je     49a160 <velri_slang_dot_linear_w8a8_f32_packed+0x1b20>
  499a45:	mov    0x1b8(%rsp),%rbx
  499a4d:	vmovss (%rbx),%xmm8
  499a51:	test   $0x2,%al
  499a53:	je     499a5b <velri_slang_dot_linear_w8a8_f32_packed+0x141b>
  499a55:	vmulss (%rdx,%r12,4),%xmm8,%xmm8
  499a5b:	vmulss %xmm8,%xmm6,%xmm6
  499a60:	test   $0x1,%al
  499a62:	je     499a70 <velri_slang_dot_linear_w8a8_f32_packed+0x1430>
  499a64:	mov    0x1b0(%rsp),%rbx
  499a6c:	vaddss (%rbx),%xmm6,%xmm6
  499a70:	lea    0x10(%rcx,%rsi,1),%rdi
  499a75:	mov    0x114(%rsp),%esi
  499a7c:	vmovss %xmm6,(%r8)
  499a81:	sub    %r13d,%esi
  499a84:	vcvtsi2ss %esi,%xmm0,%xmm6
  499a88:	test   $0x4,%al
  499a8a:	je     49a150 <velri_slang_dot_linear_w8a8_f32_packed+0x1b10>
  499a90:	mov    0x1c8(%rsp),%rbx
  499a98:	vmovss (%rbx),%xmm7
  499a9c:	test   $0x2,%al
  499a9e:	je     499aa6 <velri_slang_dot_linear_w8a8_f32_packed+0x1466>
  499aa0:	vmulss (%rdx,%r12,4),%xmm7,%xmm7
  499aa6:	vmulss %xmm7,%xmm6,%xmm6
  499aaa:	test   $0x1,%al
  499aac:	je     499aba <velri_slang_dot_linear_w8a8_f32_packed+0x147a>
  499aae:	mov    0x1c0(%rsp),%rbx
  499ab6:	vaddss (%rbx),%xmm6,%xmm6
  499aba:	mov    0x1d0(%rsp),%rbx
  499ac2:	mov    0x1d8(%rsp),%rsi
  499aca:	vmovss %xmm6,(%rdi)
  499ace:	mov    0x118(%rsp),%edi
  499ad5:	mov    0x4(%rbx),%r8d
  499ad9:	imul   %r11,%rsi
  499add:	add    0x178(%rsp),%rsi
  499ae5:	shl    $0x2,%rsi
  499ae9:	sub    %r8d,%edi
  499aec:	lea    (%rcx,%rsi,1),%r12
  499af0:	vcvtsi2ss %edi,%xmm0,%xmm6
  499af4:	test   $0x4,%al
  499af6:	je     49a140 <velri_slang_dot_linear_w8a8_f32_packed+0x1b00>
  499afc:	mov    0x188(%rsp),%rbx
  499b04:	vmovss (%rbx),%xmm7
  499b08:	test   $0x2,%al
  499b0a:	je     499b12 <velri_slang_dot_linear_w8a8_f32_packed+0x14d2>
  499b0c:	vmulss (%rdx,%r11,4),%xmm7,%xmm7
  499b12:	vmulss %xmm7,%xmm6,%xmm6
  499b16:	test   $0x1,%al
  499b18:	je     499b26 <velri_slang_dot_linear_w8a8_f32_packed+0x14e6>
  499b1a:	mov    0x180(%rsp),%rbx
  499b22:	vaddss (%rbx),%xmm6,%xmm6
  499b26:	mov    0x11c(%rsp),%edi
  499b2d:	vmovss %xmm6,(%r12)
  499b33:	lea    0x4(%rcx,%rsi,1),%r12
  499b38:	sub    %r8d,%edi
  499b3b:	vcvtsi2ss %edi,%xmm0,%xmm6
  499b3f:	test   $0x4,%al
  499b41:	je     49a130 <velri_slang_dot_linear_w8a8_f32_packed+0x1af0>
  499b47:	mov    0x198(%rsp),%rbx
  499b4f:	vmovss (%rbx),%xmm7
  499b53:	test   $0x2,%al
  499b55:	je     499b5d <velri_slang_dot_linear_w8a8_f32_packed+0x151d>
  499b57:	vmulss (%rdx,%r11,4),%xmm7,%xmm7
  499b5d:	vmulss %xmm7,%xmm6,%xmm6
  499b61:	test   $0x1,%al
  499b63:	je     499b71 <velri_slang_dot_linear_w8a8_f32_packed+0x1531>
  499b65:	mov    0x190(%rsp),%rbx
  499b6d:	vaddss (%rbx),%xmm6,%xmm6
  499b71:	mov    0x120(%rsp),%edi
  499b78:	vmovss %xmm6,(%r12)
  499b7e:	lea    0x8(%rcx,%rsi,1),%r12
  499b83:	sub    %r8d,%edi
  499b86:	vcvtsi2ss %edi,%xmm0,%xmm6
  499b8a:	test   $0x4,%al
  499b8c:	je     49a120 <velri_slang_dot_linear_w8a8_f32_packed+0x1ae0>
  499b92:	mov    0x1a8(%rsp),%rbx
  499b9a:	vmovss (%rbx),%xmm7
  499b9e:	test   $0x2,%al
  499ba0:	je     499ba8 <velri_slang_dot_linear_w8a8_f32_packed+0x1568>
  499ba2:	vmulss (%rdx,%r11,4),%xmm7,%xmm7
  499ba8:	vmulss %xmm7,%xmm6,%xmm6
  499bac:	test   $0x1,%al
  499bae:	je     499bbc <velri_slang_dot_linear_w8a8_f32_packed+0x157c>
  499bb0:	mov    0x1a0(%rsp),%rbx
  499bb8:	vaddss (%rbx),%xmm6,%xmm6
  499bbc:	mov    0x124(%rsp),%edi
  499bc3:	vmovss %xmm6,(%r12)
  499bc9:	lea    0xc(%rcx,%rsi,1),%r12
  499bce:	sub    %r8d,%edi
  499bd1:	vcvtsi2ss %edi,%xmm0,%xmm6
  499bd5:	test   $0x4,%al
  499bd7:	je     49a110 <velri_slang_dot_linear_w8a8_f32_packed+0x1ad0>
  499bdd:	mov    0x1b8(%rsp),%rbx
  499be5:	vmovss (%rbx),%xmm7
  499be9:	test   $0x2,%al
  499beb:	je     499bf3 <velri_slang_dot_linear_w8a8_f32_packed+0x15b3>
  499bed:	vmulss (%rdx,%r11,4),%xmm7,%xmm7
  499bf3:	vmulss %xmm7,%xmm6,%xmm6
  499bf7:	test   $0x1,%al
  499bf9:	je     499c07 <velri_slang_dot_linear_w8a8_f32_packed+0x15c7>
  499bfb:	mov    0x1b0(%rsp),%rbx
  499c03:	vaddss (%rbx),%xmm6,%xmm6
  499c07:	lea    0x10(%rcx,%rsi,1),%rdi
  499c0c:	mov    0x128(%rsp),%esi
  499c13:	vmovss %xmm6,(%r12)
  499c19:	sub    %r8d,%esi
  499c1c:	vcvtsi2ss %esi,%xmm0,%xmm6
  499c20:	test   $0x4,%al
  499c22:	je     49a100 <velri_slang_dot_linear_w8a8_f32_packed+0x1ac0>
  499c28:	mov    0x1c8(%rsp),%rbx
  499c30:	vmovss (%rbx),%xmm7
  499c34:	test   $0x2,%al
  499c36:	je     499c3e <velri_slang_dot_linear_w8a8_f32_packed+0x15fe>
  499c38:	vmulss (%rdx,%r11,4),%xmm7,%xmm7
  499c3e:	vmulss %xmm7,%xmm6,%xmm6
  499c42:	test   $0x1,%al
  499c44:	je     499c52 <velri_slang_dot_linear_w8a8_f32_packed+0x1612>
  499c46:	mov    0x1c0(%rsp),%rbx
  499c4e:	vaddss (%rbx),%xmm6,%xmm6
  499c52:	mov    0x1d0(%rsp),%rbx
  499c5a:	mov    0x1d8(%rsp),%rsi
  499c62:	vmovss %xmm6,(%rdi)
  499c66:	mov    0x12c(%rsp),%edi
  499c6d:	mov    0x8(%rbx),%r8d
  499c71:	imul   %r10,%rsi
  499c75:	add    0x178(%rsp),%rsi
  499c7d:	shl    $0x2,%rsi
  499c81:	sub    %r8d,%edi
  499c84:	lea    (%rcx,%rsi,1),%r11
  499c88:	vcvtsi2ss %edi,%xmm0,%xmm6
  499c8c:	test   $0x4,%al
  499c8e:	je     49a0f0 <velri_slang_dot_linear_w8a8_f32_packed+0x1ab0>
  499c94:	mov    0x188(%rsp),%rbx
  499c9c:	vmovss (%rbx),%xmm7
  499ca0:	test   $0x2,%al
  499ca2:	je     499caa <velri_slang_dot_linear_w8a8_f32_packed+0x166a>
  499ca4:	vmulss (%rdx,%r10,4),%xmm7,%xmm7
  499caa:	vmulss %xmm7,%xmm6,%xmm6
  499cae:	test   $0x1,%al
  499cb0:	je     499cbe <velri_slang_dot_linear_w8a8_f32_packed+0x167e>
  499cb2:	mov    0x180(%rsp),%rbx
  499cba:	vaddss (%rbx),%xmm6,%xmm6
  499cbe:	mov    0x130(%rsp),%edi
  499cc5:	vmovss %xmm6,(%r11)
  499cca:	lea    0x4(%rcx,%rsi,1),%r11
  499ccf:	sub    %r8d,%edi
  499cd2:	vcvtsi2ss %edi,%xmm0,%xmm6
  499cd6:	test   $0x4,%al
  499cd8:	je     49a0e0 <velri_slang_dot_linear_w8a8_f32_packed+0x1aa0>
  499cde:	mov    0x198(%rsp),%rbx
  499ce6:	vmovss (%rbx),%xmm7
  499cea:	test   $0x2,%al
  499cec:	je     499cf4 <velri_slang_dot_linear_w8a8_f32_packed+0x16b4>
  499cee:	vmulss (%rdx,%r10,4),%xmm7,%xmm7
  499cf4:	vmulss %xmm7,%xmm6,%xmm6
  499cf8:	test   $0x1,%al
  499cfa:	je     499d08 <velri_slang_dot_linear_w8a8_f32_packed+0x16c8>
  499cfc:	mov    0x190(%rsp),%rbx
  499d04:	vaddss (%rbx),%xmm6,%xmm6
  499d08:	mov    0x134(%rsp),%edi
  499d0f:	vmovss %xmm6,(%r11)
  499d14:	lea    0x8(%rcx,%rsi,1),%r11
  499d19:	sub    %r8d,%edi
  499d1c:	vcvtsi2ss %edi,%xmm0,%xmm6
  499d20:	test   $0x4,%al
  499d22:	je     49a0d0 <velri_slang_dot_linear_w8a8_f32_packed+0x1a90>
  499d28:	mov    0x1a8(%rsp),%rbx
  499d30:	vmovss (%rbx),%xmm7
  499d34:	test   $0x2,%al
  499d36:	je     499d3e <velri_slang_dot_linear_w8a8_f32_packed+0x16fe>
  499d38:	vmulss (%rdx,%r10,4),%xmm7,%xmm7
  499d3e:	vmulss %xmm7,%xmm6,%xmm6
  499d42:	test   $0x1,%al
  499d44:	je     499d52 <velri_slang_dot_linear_w8a8_f32_packed+0x1712>
  499d46:	mov    0x1a0(%rsp),%rbx
  499d4e:	vaddss (%rbx),%xmm6,%xmm6
  499d52:	mov    0x138(%rsp),%edi
  499d59:	vmovss %xmm6,(%r11)
  499d5e:	lea    0xc(%rcx,%rsi,1),%r11
  499d63:	sub    %r8d,%edi
  499d66:	vcvtsi2ss %edi,%xmm0,%xmm6
  499d6a:	test   $0x4,%al
  499d6c:	je     49a0c0 <velri_slang_dot_linear_w8a8_f32_packed+0x1a80>
  499d72:	mov    0x1b8(%rsp),%rbx
  499d7a:	vmovss (%rbx),%xmm7
  499d7e:	test   $0x2,%al
  499d80:	je     499d88 <velri_slang_dot_linear_w8a8_f32_packed+0x1748>
  499d82:	vmulss (%rdx,%r10,4),%xmm7,%xmm7
  499d88:	vmulss %xmm7,%xmm6,%xmm6
  499d8c:	test   $0x1,%al
  499d8e:	je     499d9c <velri_slang_dot_linear_w8a8_f32_packed+0x175c>
  499d90:	mov    0x1b0(%rsp),%rbx
  499d98:	vaddss (%rbx),%xmm6,%xmm6
  499d9c:	lea    0x10(%rcx,%rsi,1),%rdi
  499da1:	mov    0x13c(%rsp),%esi
  499da8:	vmovss %xmm6,(%r11)
  499dad:	sub    %r8d,%esi
  499db0:	vcvtsi2ss %esi,%xmm0,%xmm6
  499db4:	test   $0x4,%al
  499db6:	je     49a0b0 <velri_slang_dot_linear_w8a8_f32_packed+0x1a70>
  499dbc:	mov    0x1c8(%rsp),%rbx
  499dc4:	vmovss (%rbx),%xmm9
  499dc8:	test   $0x2,%al
  499dca:	je     499dd2 <velri_slang_dot_linear_w8a8_f32_packed+0x1792>
  499dcc:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  499dd2:	vmulss %xmm9,%xmm6,%xmm6
  499dd7:	test   $0x1,%al
  499dd9:	je     499de7 <velri_slang_dot_linear_w8a8_f32_packed+0x17a7>
  499ddb:	mov    0x1c0(%rsp),%rbx
  499de3:	vaddss (%rbx),%xmm6,%xmm6
  499de7:	vmovss %xmm6,(%rdi)
  499deb:	mov    0x1d0(%rsp),%rdi
  499df3:	mov    0x1d8(%rsp),%rsi
  499dfb:	mov    0xc(%rdi),%r8d
  499dff:	mov    0x140(%rsp),%edi
  499e06:	imul   %r9,%rsi
  499e0a:	add    0x178(%rsp),%rsi
  499e12:	shl    $0x2,%rsi
  499e16:	sub    %r8d,%edi
  499e19:	vcvtsi2ss %edi,%xmm0,%xmm6
  499e1d:	lea    (%rcx,%rsi,1),%r10
  499e21:	test   $0x4,%al
  499e23:	je     49a0a0 <velri_slang_dot_linear_w8a8_f32_packed+0x1a60>
  499e29:	mov    0x188(%rsp),%rbx
  499e31:	vmovss (%rbx),%xmm9
  499e35:	test   $0x2,%al
  499e37:	je     499e3f <velri_slang_dot_linear_w8a8_f32_packed+0x17ff>
  499e39:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  499e3f:	vmulss %xmm9,%xmm6,%xmm6
  499e44:	test   $0x1,%al
  499e46:	je     499e54 <velri_slang_dot_linear_w8a8_f32_packed+0x1814>
  499e48:	mov    0x180(%rsp),%rbx
  499e50:	vaddss (%rbx),%xmm6,%xmm6
  499e54:	mov    0x144(%rsp),%edi
  499e5b:	vmovss %xmm6,(%r10)
  499e60:	lea    0x4(%rcx,%rsi,1),%r10
  499e65:	sub    %r8d,%edi
  499e68:	vcvtsi2ss %edi,%xmm0,%xmm6
  499e6c:	test   $0x4,%al
  499e6e:	je     49a090 <velri_slang_dot_linear_w8a8_f32_packed+0x1a50>
  499e74:	mov    0x198(%rsp),%rbx
  499e7c:	vmovss (%rbx),%xmm9
  499e80:	test   $0x2,%al
  499e82:	je     499e8a <velri_slang_dot_linear_w8a8_f32_packed+0x184a>
  499e84:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  499e8a:	vmulss %xmm9,%xmm6,%xmm6
  499e8f:	test   $0x1,%al
  499e91:	je     499e9f <velri_slang_dot_linear_w8a8_f32_packed+0x185f>
  499e93:	mov    0x190(%rsp),%rbx
  499e9b:	vaddss (%rbx),%xmm6,%xmm6
  499e9f:	mov    0x100(%rsp),%edi
  499ea6:	vmovss %xmm6,(%r10)
  499eab:	lea    0x8(%rcx,%rsi,1),%r10
  499eb0:	sub    %r8d,%edi
  499eb3:	vcvtsi2ss %edi,%xmm0,%xmm6
  499eb7:	test   $0x4,%al
  499eb9:	je     49a080 <velri_slang_dot_linear_w8a8_f32_packed+0x1a40>
  499ebf:	mov    0x1a8(%rsp),%rbx
  499ec7:	vmovss (%rbx),%xmm9
  499ecb:	test   $0x2,%al
  499ecd:	je     499ed5 <velri_slang_dot_linear_w8a8_f32_packed+0x1895>
  499ecf:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  499ed5:	vmulss %xmm9,%xmm6,%xmm6
  499eda:	test   $0x1,%al
  499edc:	je     499eea <velri_slang_dot_linear_w8a8_f32_packed+0x18aa>
  499ede:	mov    0x1a0(%rsp),%rdi
  499ee6:	vaddss (%rdi),%xmm6,%xmm6
  499eea:	mov    0xfc(%rsp),%edi
  499ef1:	vmovss %xmm6,(%r10)
  499ef6:	lea    0xc(%rcx,%rsi,1),%r10
  499efb:	sub    %r8d,%edi
  499efe:	vcvtsi2ss %edi,%xmm0,%xmm6
  499f02:	test   $0x4,%al
  499f04:	je     49a070 <velri_slang_dot_linear_w8a8_f32_packed+0x1a30>
  499f0a:	mov    0x1b8(%rsp),%rbx
  499f12:	vmovss (%rbx),%xmm9
  499f16:	test   $0x2,%al
  499f18:	je     499f20 <velri_slang_dot_linear_w8a8_f32_packed+0x18e0>
  499f1a:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  499f20:	vmulss %xmm9,%xmm6,%xmm6
  499f25:	test   $0x1,%al
  499f27:	je     499f35 <velri_slang_dot_linear_w8a8_f32_packed+0x18f5>
  499f29:	mov    0x1b0(%rsp),%rdi
  499f31:	vaddss (%rdi),%xmm6,%xmm6
  499f35:	lea    0x10(%rcx,%rsi,1),%rdi
  499f3a:	mov    0x104(%rsp),%esi
  499f41:	vmovss %xmm6,(%r10)
  499f46:	sub    %r8d,%esi
  499f49:	vcvtsi2ss %esi,%xmm0,%xmm6
  499f4d:	test   $0x4,%al
  499f4f:	je     49a060 <velri_slang_dot_linear_w8a8_f32_packed+0x1a20>
  499f55:	mov    0x1c8(%rsp),%rbx
  499f5d:	vmovss (%rbx),%xmm9
  499f61:	test   $0x2,%al
  499f63:	je     499f6b <velri_slang_dot_linear_w8a8_f32_packed+0x192b>
  499f65:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  499f6b:	vmulss %xmm9,%xmm6,%xmm6
  499f70:	test   $0x1,%al
  499f72:	je     49a1a0 <velri_slang_dot_linear_w8a8_f32_packed+0x1b60>
  499f78:	mov    0x1c0(%rsp),%rbx
  499f80:	add    $0x4,%r15d
  499f84:	vaddss (%rbx),%xmm6,%xmm6
  499f88:	vmovss %xmm6,(%rdi)
  499f8c:	cmp    0xe0(%rsp),%r15d
  499f94:	je     49a1b6 <velri_slang_dot_linear_w8a8_f32_packed+0x1b76>
  499f9a:	addq   $0x10,0x1d0(%rsp)
  499fa3:	jmp    498b20 <velri_slang_dot_linear_w8a8_f32_packed+0x4e0>
  499fa8:	nopl   0x0(%rax,%rax,1)
  499fb0:	add    $0x1,%r9
  499fb4:	vmovss %xmm1,(%rax)
  499fb8:	cmp    %ebx,%r9d
  499fbb:	jb     49af80 <velri_slang_dot_linear_w8a8_f32_packed+0x2940>
  499fc1:	mov    0x70(%rsp),%rdx
  499fc6:	add    $0x4,%r13
  499fca:	add    $0x1,%r8
  499fce:	add    $0x4,%r14
  499fd2:	add    %rdx,0x1c0(%rsp)
  499fda:	cmp    0x40(%rbp),%r8d
  499fde:	jb     49a8e0 <velri_slang_dot_linear_w8a8_f32_packed+0x22a0>
  499fe4:	mov    0x28(%rbp),%ebx
  499fe7:	mov    0x38(%rbp),%r10d
  499feb:	cmp    0x30(%rbp),%ebx
  499fee:	jb     498723 <velri_slang_dot_linear_w8a8_f32_packed+0xe3>
  499ff4:	vzeroupper
  499ff7:	mov    0x2f8(%rsp),%rax
  499fff:	sub    %fs:0x28,%rax
  49a008:	jne    49b45f <velri_slang_dot_linear_w8a8_f32_packed+0x2e1f>
  49a00e:	lea    -0x28(%rbp),%rsp
  49a012:	pop    %rbx
  49a013:	pop    %r12
  49a015:	pop    %r13
  49a017:	pop    %r14
  49a019:	pop    %r15
  49a01b:	pop    %rbp
  49a01c:	ret
  49a01d:	lea    0x1(%rdx),%ecx
  49a020:	movl   $0x0,(%rax)
  49a026:	cmp    %ecx,%ebx
  49a028:	je     498913 <velri_slang_dot_linear_w8a8_f32_packed+0x2d3>
  49a02e:	add    $0x2,%edx
  49a031:	movl   $0x0,0x4(%rax)
  49a038:	add    $0x8,%rax
  49a03c:	cmp    %ebx,%edx
  49a03e:	jne    49a01d <velri_slang_dot_linear_w8a8_f32_packed+0x19dd>
  49a040:	cmpl   $0x4,0x38(%rsp)
  49a045:	ja     49891e <velri_slang_dot_linear_w8a8_f32_packed+0x2de>
  49a04b:	mov    0xf8(%rsp),%eax
  49a052:	mov    %r10d,%r13d
  49a055:	lea    -0x4(%rax),%r11d
  49a059:	jmp    49a859 <velri_slang_dot_linear_w8a8_f32_packed+0x2219>
  49a05e:	xchg   %ax,%ax
  49a060:	vmovss 0x3fa4(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a068:	jmp    499f61 <velri_slang_dot_linear_w8a8_f32_packed+0x1921>
  49a06d:	nopl   (%rax)
  49a070:	vmovss 0x3f94(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a078:	jmp    499f16 <velri_slang_dot_linear_w8a8_f32_packed+0x18d6>
  49a07d:	nopl   (%rax)
  49a080:	vmovss 0x3f84(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a088:	jmp    499ecb <velri_slang_dot_linear_w8a8_f32_packed+0x188b>
  49a08d:	nopl   (%rax)
  49a090:	vmovss 0x3f74(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a098:	jmp    499e80 <velri_slang_dot_linear_w8a8_f32_packed+0x1840>
  49a09d:	nopl   (%rax)
  49a0a0:	vmovss 0x3f64(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a0a8:	jmp    499e35 <velri_slang_dot_linear_w8a8_f32_packed+0x17f5>
  49a0ad:	nopl   (%rax)
  49a0b0:	vmovss 0x3f54(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49a0b8:	jmp    499dc8 <velri_slang_dot_linear_w8a8_f32_packed+0x1788>
  49a0bd:	nopl   (%rax)
  49a0c0:	vmovss 0x3f44(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a0c8:	jmp    499d7e <velri_slang_dot_linear_w8a8_f32_packed+0x173e>
  49a0cd:	nopl   (%rax)
  49a0d0:	vmovss 0x3f34(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a0d8:	jmp    499d34 <velri_slang_dot_linear_w8a8_f32_packed+0x16f4>
  49a0dd:	nopl   (%rax)
  49a0e0:	vmovss 0x3f24(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a0e8:	jmp    499cea <velri_slang_dot_linear_w8a8_f32_packed+0x16aa>
  49a0ed:	nopl   (%rax)
  49a0f0:	vmovss 0x3f14(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a0f8:	jmp    499ca0 <velri_slang_dot_linear_w8a8_f32_packed+0x1660>
  49a0fd:	nopl   (%rax)
  49a100:	vmovss 0x3f04(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a108:	jmp    499c34 <velri_slang_dot_linear_w8a8_f32_packed+0x15f4>
  49a10d:	nopl   (%rax)
  49a110:	vmovss 0x3ef4(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a118:	jmp    499be9 <velri_slang_dot_linear_w8a8_f32_packed+0x15a9>
  49a11d:	nopl   (%rax)
  49a120:	vmovss 0x3ee4(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a128:	jmp    499b9e <velri_slang_dot_linear_w8a8_f32_packed+0x155e>
  49a12d:	nopl   (%rax)
  49a130:	vmovss 0x3ed4(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a138:	jmp    499b53 <velri_slang_dot_linear_w8a8_f32_packed+0x1513>
  49a13d:	nopl   (%rax)
  49a140:	vmovss 0x3ec4(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a148:	jmp    499b08 <velri_slang_dot_linear_w8a8_f32_packed+0x14c8>
  49a14d:	nopl   (%rax)
  49a150:	vmovss 0x3eb4(%rip),%xmm7        # 49e00c <_IO_stdin_used+0xc>
  49a158:	jmp    499a9c <velri_slang_dot_linear_w8a8_f32_packed+0x145c>
  49a15d:	nopl   (%rax)
  49a160:	vmovss 0x3ea4(%rip),%xmm8        # 49e00c <_IO_stdin_used+0xc>
  49a168:	jmp    499a51 <velri_slang_dot_linear_w8a8_f32_packed+0x1411>
  49a16d:	nopl   (%rax)
  49a170:	vmovss 0x3e94(%rip),%xmm8        # 49e00c <_IO_stdin_used+0xc>
  49a178:	jmp    499a06 <velri_slang_dot_linear_w8a8_f32_packed+0x13c6>
  49a17d:	nopl   (%rax)
  49a180:	vmovss 0x3e84(%rip),%xmm8        # 49e00c <_IO_stdin_used+0xc>
  49a188:	jmp    4999bb <velri_slang_dot_linear_w8a8_f32_packed+0x137b>
  49a18d:	nopl   (%rax)
  49a190:	vmovss 0x3e74(%rip),%xmm8        # 49e00c <_IO_stdin_used+0xc>
  49a198:	jmp    499970 <velri_slang_dot_linear_w8a8_f32_packed+0x1330>
  49a19d:	nopl   (%rax)
  49a1a0:	vmovss %xmm6,(%rdi)
  49a1a4:	add    $0x4,%r15d
  49a1a8:	cmp    %r15d,0xe0(%rsp)
  49a1b0:	jne    499f9a <velri_slang_dot_linear_w8a8_f32_packed+0x195a>
  49a1b6:	mov    0x68(%rsp),%r14
  49a1bb:	mov    0xf8(%rsp),%edx
  49a1c2:	cmp    %edx,0x78(%rsp)
  49a1c6:	jae    49a81d <velri_slang_dot_linear_w8a8_f32_packed+0x21dd>
  49a1cc:	mov    0xf0(%rsp),%rax
  49a1d4:	mov    0x160(%rsp),%rdx
  49a1dc:	mov    0x3c(%rsp),%ebx
  49a1e0:	mov    0xb4(%rsp),%r11d
  49a1e8:	add    %rax,%rdx
  49a1eb:	mov    0x48(%rbp),%r10d
  49a1ef:	vmovq  %rdx,%xmm1
  49a1f4:	mov    0x148(%rsp),%rdx
  49a1fc:	add    %rax,%rdx
  49a1ff:	vmovq  %rdx,%xmm5
  49a204:	mov    0x150(%rsp),%rdx
  49a20c:	add    %rax,%rdx
  49a20f:	vmovq  %rdx,%xmm4
  49a214:	mov    0x158(%rsp),%rdx
  49a21c:	add    %rax,%rdx
  49a21f:	add    0x168(%rsp),%rax
  49a227:	vmovq  %rax,%xmm2
  49a22c:	mov    0x10(%rbp),%eax
  49a22f:	vmovq  %rdx,%xmm3
  49a234:	nop
  49a235:	data16 cs nopw 0x0(%rax,%rax,1)
  49a240:	lea    (%r11,%rbx,1),%edx
  49a244:	vmovq  %rdx,%xmm15
  49a249:	test   %r10d,%r10d
  49a24c:	je     49af17 <velri_slang_dot_linear_w8a8_f32_packed+0x28d7>
  49a252:	mov    0xe8(%rsp),%r9
  49a25a:	imul   %rdx,%r9
  49a25e:	cmpl   $0x3e,0xe4(%rsp)
  49a266:	jbe    49b259 <velri_slang_dot_linear_w8a8_f32_packed+0x2c19>
  49a26c:	mov    0x170(%rsp),%rdx
  49a274:	vpxor  %xmm6,%xmm6,%xmm6
  49a278:	vmovq  %xmm1,%rdi
  49a27d:	vmovq  %xmm5,%rsi
  49a282:	vmovdqa32 %zmm6,%zmm9
  49a288:	vmovdqa32 %zmm6,%zmm10
  49a28e:	vmovdqa32 %zmm6,%zmm14
  49a294:	lea    (%rdx,%r9,1),%r13
  49a298:	vmovdqa32 %zmm6,%zmm12
  49a29e:	vmovq  %xmm4,%r15
  49a2a3:	xor    %edx,%edx
  49a2a5:	vmovq  %xmm3,%r9
  49a2aa:	vmovq  %xmm2,%r8
  49a2af:	nop
  49a2b0:	vmovdqu8 0x0(%r13,%rdx,1),%zmm7
  49a2b8:	vmovdqu8 (%r8,%rdx,1),%zmm11
  49a2bf:	vpdpbusd %zmm7,%zmm11,%zmm6
  49a2c5:	vmovdqu8 (%rdi,%rdx,1),%zmm11
  49a2cc:	vpdpbusd %zmm7,%zmm11,%zmm9
  49a2d2:	vmovdqu8 (%r9,%rdx,1),%zmm11
  49a2d9:	vpdpbusd %zmm7,%zmm11,%zmm10
  49a2df:	vmovdqu8 (%r15,%rdx,1),%zmm11
  49a2e6:	vpdpbusd %zmm7,%zmm11,%zmm14
  49a2ec:	vmovdqu8 (%rsi,%rdx,1),%zmm11
  49a2f3:	add    $0x40,%rdx
  49a2f7:	vpdpbusd %zmm7,%zmm11,%zmm12
  49a2fd:	cmp    0xa0(%rsp),%rdx
  49a305:	jne    49a2b0 <velri_slang_dot_linear_w8a8_f32_packed+0x1c70>
  49a307:	vextracti32x8 $0x1,%zmm6,%ymm7
  49a30e:	vmovq  %r8,%xmm2
  49a313:	vmovq  %rdi,%xmm1
  49a318:	vpaddd %ymm6,%ymm7,%ymm7
  49a31c:	vmovq  %rsi,%xmm5
  49a321:	vmovq  %r15,%xmm4
  49a326:	vextracti32x4 $0x1,%ymm7,%xmm6
  49a32d:	vmovq  %r9,%xmm3
  49a332:	vpaddd %xmm7,%xmm6,%xmm11
  49a336:	vpsrldq $0x8,%xmm11,%xmm6
  49a33c:	vpaddd %xmm6,%xmm11,%xmm6
  49a340:	vpsrldq $0x4,%xmm6,%xmm11
  49a345:	vpaddd %xmm11,%xmm6,%xmm6
  49a34a:	vmovd  %xmm6,%r8d
  49a34f:	vextracti32x8 $0x1,%zmm9,%ymm6
  49a356:	vpaddd %ymm9,%ymm6,%ymm6
  49a35b:	vextracti32x4 $0x1,%ymm6,%xmm9
  49a362:	vpaddd %xmm6,%xmm9,%xmm11
  49a366:	vpsrldq $0x8,%xmm11,%xmm9
  49a36c:	vpaddd %xmm9,%xmm11,%xmm9
  49a371:	vpsrldq $0x4,%xmm9,%xmm11
  49a377:	vpaddd %xmm11,%xmm9,%xmm9
  49a37c:	vextracti32x8 $0x1,%zmm10,%ymm11
  49a383:	vpaddd %ymm10,%ymm11,%ymm11
  49a388:	vmovd  %xmm9,%edi
  49a38c:	vextracti32x4 $0x1,%ymm11,%xmm9
  49a393:	vpaddd %xmm11,%xmm9,%xmm10
  49a398:	vpsrldq $0x8,%xmm10,%xmm9
  49a39e:	vpaddd %xmm9,%xmm10,%xmm9
  49a3a3:	vpsrldq $0x4,%xmm9,%xmm10
  49a3a9:	vpaddd %xmm10,%xmm9,%xmm9
  49a3ae:	vextracti32x8 $0x1,%zmm14,%ymm10
  49a3b5:	vpaddd %ymm14,%ymm10,%ymm10
  49a3ba:	vmovd  %xmm9,%esi
  49a3be:	vextracti32x4 $0x1,%ymm10,%xmm9
  49a3c5:	vpaddd %xmm10,%xmm9,%xmm14
  49a3ca:	vpsrldq $0x8,%xmm14,%xmm9
  49a3d0:	vpaddd %xmm9,%xmm14,%xmm9
  49a3d5:	vpsrldq $0x4,%xmm9,%xmm14
  49a3db:	vpaddd %xmm14,%xmm9,%xmm9
  49a3e0:	vmovd  %xmm9,%ecx
  49a3e4:	vextracti32x8 $0x1,%zmm12,%ymm9
  49a3eb:	vpaddd %ymm12,%ymm9,%ymm9
  49a3f0:	vextracti32x4 $0x1,%ymm9,%xmm12
  49a3f7:	vpaddd %xmm9,%xmm12,%xmm14
  49a3fc:	vpsrldq $0x8,%xmm14,%xmm12
  49a402:	vpaddd %xmm12,%xmm14,%xmm12
  49a407:	vpsrldq $0x4,%xmm12,%xmm14
  49a40d:	vpaddd %xmm14,%xmm12,%xmm12
  49a412:	vmovd  %xmm12,%edx
  49a416:	test   $0x3f,%r10b
  49a41a:	je     49a624 <velri_slang_dot_linear_w8a8_f32_packed+0x1fe4>
  49a420:	mov    %r10d,%r15d
  49a423:	and    $0xffffffc0,%r15d
  49a427:	mov    %r10d,%r9d
  49a42a:	sub    %r15d,%r9d
  49a42d:	lea    -0x1(%r9),%r12d
  49a431:	cmp    $0x1e,%r12d
  49a435:	jbe    49a579 <velri_slang_dot_linear_w8a8_f32_packed+0x1f39>
  49a43b:	mov    0x160(%rsp),%rcx
  49a443:	mov    %r15d,%edx
  49a446:	vmovdqu8 0x0(%r13,%rdx,1),%ymm12
  49a44e:	add    0xf0(%rsp),%rdx
  49a456:	vmovdqu8 (%rdx,%rcx,1),%ymm14
  49a45d:	mov    0x158(%rsp),%rcx
  49a465:	vpdpbusd %ymm12,%ymm14,%ymm6
  49a46b:	vmovdqu8 (%rdx,%rcx,1),%ymm14
  49a472:	mov    0x150(%rsp),%rcx
  49a47a:	vpdpbusd %ymm12,%ymm14,%ymm11
  49a480:	vmovdqu8 (%rdx,%rcx,1),%ymm14
  49a487:	mov    0x148(%rsp),%rcx
  49a48f:	vpdpbusd %ymm12,%ymm14,%ymm10
  49a495:	vmovdqu8 (%rdx,%rcx,1),%ymm14
  49a49c:	mov    0x168(%rsp),%rcx
  49a4a4:	vpdpbusd %ymm12,%ymm14,%ymm9
  49a4aa:	vmovdqu8 (%rdx,%rcx,1),%ymm14
  49a4b1:	vpdpbusd %ymm12,%ymm14,%ymm7
  49a4b7:	vextracti32x4 $0x1,%ymm7,%xmm12
  49a4be:	vpaddd %xmm7,%xmm12,%xmm7
  49a4c2:	vpsrldq $0x8,%xmm7,%xmm12
  49a4c7:	vpaddd %xmm12,%xmm7,%xmm7
  49a4cc:	vpsrldq $0x4,%xmm7,%xmm12
  49a4d1:	vpaddd %xmm12,%xmm7,%xmm7
  49a4d6:	vmovd  %xmm7,%r8d
  49a4db:	vextracti32x4 $0x1,%ymm6,%xmm7
  49a4e2:	vpaddd %xmm6,%xmm7,%xmm6
  49a4e6:	vpsrldq $0x8,%xmm6,%xmm7
  49a4eb:	vpaddd %xmm7,%xmm6,%xmm6
  49a4ef:	vpsrldq $0x4,%xmm6,%xmm7
  49a4f4:	vpaddd %xmm7,%xmm6,%xmm6
  49a4f8:	vmovd  %xmm6,%edi
  49a4fc:	vextracti32x4 $0x1,%ymm11,%xmm6
  49a503:	vpaddd %xmm11,%xmm6,%xmm6
  49a508:	vpsrldq $0x8,%xmm6,%xmm11
  49a50d:	vpaddd %xmm11,%xmm6,%xmm6
  49a512:	vpsrldq $0x4,%xmm6,%xmm11
  49a517:	vpaddd %xmm11,%xmm6,%xmm6
  49a51c:	vmovd  %xmm6,%esi
  49a520:	vextracti32x4 $0x1,%ymm10,%xmm6
  49a527:	vpaddd %xmm10,%xmm6,%xmm6
  49a52c:	vpsrldq $0x8,%xmm6,%xmm10
  49a531:	vpaddd %xmm10,%xmm6,%xmm6
  49a536:	vpsrldq $0x4,%xmm6,%xmm10
  49a53b:	vpaddd %xmm10,%xmm6,%xmm6
  49a540:	vmovd  %xmm6,%ecx
  49a544:	vextracti32x4 $0x1,%ymm9,%xmm6
  49a54b:	vpaddd %xmm9,%xmm6,%xmm6
  49a550:	vpsrldq $0x8,%xmm6,%xmm9
  49a555:	vpaddd %xmm9,%xmm6,%xmm6
  49a55a:	vpsrldq $0x4,%xmm6,%xmm9
  49a55f:	vpaddd %xmm9,%xmm6,%xmm6
  49a564:	vmovd  %xmm6,%edx
  49a568:	test   $0x1f,%r9b
  49a56c:	je     49a624 <velri_slang_dot_linear_w8a8_f32_packed+0x1fe4>
  49a572:	and    $0xffffffe0,%r9d
  49a576:	add    %r9d,%r15d
  49a579:	mov    %r15d,%r9d
  49a57c:	vmovq  %xmm1,%r12
  49a581:	mov    %eax,0x10(%rbp)
  49a584:	vmovq  %r14,%xmm7
  49a589:	add    %r9,%r13
  49a58c:	add    %r12,%r9
  49a58f:	mov    %r13,%rax
  49a592:	nopl   (%rax)
  49a595:	data16 cs nopw 0x0(%rax,%rax,1)
  49a5a0:	mov    %r9,%r12
  49a5a3:	movsbl (%rax),%r14d
  49a5a7:	add    $0x1,%r15d
  49a5ab:	add    $0x1,%rax
  49a5af:	mov    0x168(%rsp),%r13
  49a5b7:	sub    0x160(%rsp),%r12
  49a5bf:	add    $0x1,%r9
  49a5c3:	movzbl (%r12,%r13,1),%r13d
  49a5c8:	imul   %r14d,%r13d
  49a5cc:	add    %r13d,%r8d
  49a5cf:	movzbl -0x1(%r9),%r13d
  49a5d4:	imul   %r14d,%r13d
  49a5d8:	add    %r13d,%edi
  49a5db:	mov    0x158(%rsp),%r13
  49a5e3:	movzbl (%r12,%r13,1),%r13d
  49a5e8:	imul   %r14d,%r13d
  49a5ec:	add    %r13d,%esi
  49a5ef:	mov    0x150(%rsp),%r13
  49a5f7:	movzbl (%r12,%r13,1),%r13d
  49a5fc:	imul   %r14d,%r13d
  49a600:	add    %r13d,%ecx
  49a603:	mov    0x148(%rsp),%r13
  49a60b:	movzbl (%r12,%r13,1),%r12d
  49a610:	imul   %r14d,%r12d
  49a614:	add    %r12d,%edx
  49a617:	cmp    %r10d,%r15d
  49a61a:	jb     49a5a0 <velri_slang_dot_linear_w8a8_f32_packed+0x1f60>
  49a61c:	mov    0x10(%rbp),%eax
  49a61f:	vmovq  %xmm7,%r14
  49a624:	mov    0x1d8(%rsp),%r9
  49a62c:	vmovq  %xmm15,%r15
  49a631:	imul   %r15,%r9
  49a635:	mov    0x1e0(%rsp),%r15
  49a63d:	add    0x178(%rsp),%r9
  49a645:	shl    $0x2,%r9
  49a649:	lea    (%r15,%r9,1),%r13
  49a64d:	mov    0xd8(%rsp),%r15
  49a655:	mov    (%r15,%rbx,4),%r12d
  49a659:	sub    %r12d,%r8d
  49a65c:	vcvtsi2ss %r8d,%xmm0,%xmm6
  49a661:	test   $0x4,%al
  49a663:	je     49aee0 <velri_slang_dot_linear_w8a8_f32_packed+0x28a0>
  49a669:	mov    0x188(%rsp),%r15
  49a671:	vmovss (%r15),%xmm9
  49a676:	test   $0x2,%al
  49a678:	je     49a68d <velri_slang_dot_linear_w8a8_f32_packed+0x204d>
  49a67a:	mov    0x1e8(%rsp),%r15
  49a682:	vmovq  %xmm15,%r8
  49a687:	vmulss (%r15,%r8,4),%xmm9,%xmm9
  49a68d:	vmulss %xmm9,%xmm6,%xmm6
  49a692:	test   $0x1,%al
  49a694:	je     49a6a3 <velri_slang_dot_linear_w8a8_f32_packed+0x2063>
  49a696:	mov    0x180(%rsp),%r15
  49a69e:	vaddss (%r15),%xmm6,%xmm6
  49a6a3:	mov    0x1e0(%rsp),%r15
  49a6ab:	sub    %r12d,%edi
  49a6ae:	vmovss %xmm6,0x0(%r13)
  49a6b4:	vcvtsi2ss %edi,%xmm0,%xmm6
  49a6b8:	lea    0x4(%r15,%r9,1),%r8
  49a6bd:	test   $0x4,%al
  49a6bf:	je     49aed0 <velri_slang_dot_linear_w8a8_f32_packed+0x2890>
  49a6c5:	mov    0x198(%rsp),%rdi
  49a6cd:	vmovss (%rdi),%xmm9
  49a6d1:	test   $0x2,%al
  49a6d3:	je     49a6e8 <velri_slang_dot_linear_w8a8_f32_packed+0x20a8>
  49a6d5:	mov    0x1e8(%rsp),%rdi
  49a6dd:	vmovq  %xmm15,%r15
  49a6e2:	vmulss (%rdi,%r15,4),%xmm9,%xmm9
  49a6e8:	vmulss %xmm9,%xmm6,%xmm6
  49a6ed:	test   $0x1,%al
  49a6ef:	je     49a6fd <velri_slang_dot_linear_w8a8_f32_packed+0x20bd>
  49a6f1:	mov    0x190(%rsp),%rdi
  49a6f9:	vaddss (%rdi),%xmm6,%xmm6
  49a6fd:	mov    0x1e0(%rsp),%rdi
  49a705:	sub    %r12d,%esi
  49a708:	vmovss %xmm6,(%r8)
  49a70d:	vcvtsi2ss %esi,%xmm0,%xmm6
  49a711:	lea    0x8(%rdi,%r9,1),%rdi
  49a716:	test   $0x4,%al
  49a718:	je     49aec0 <velri_slang_dot_linear_w8a8_f32_packed+0x2880>
  49a71e:	mov    0x1a8(%rsp),%rsi
  49a726:	vmovss (%rsi),%xmm9
  49a72a:	test   $0x2,%al
  49a72c:	je     49a741 <velri_slang_dot_linear_w8a8_f32_packed+0x2101>
  49a72e:	mov    0x1e8(%rsp),%rsi
  49a736:	vmovq  %xmm15,%r15
  49a73b:	vmulss (%rsi,%r15,4),%xmm9,%xmm9
  49a741:	vmulss %xmm9,%xmm6,%xmm6
  49a746:	test   $0x1,%al
  49a748:	je     49a756 <velri_slang_dot_linear_w8a8_f32_packed+0x2116>
  49a74a:	mov    0x1a0(%rsp),%rsi
  49a752:	vaddss (%rsi),%xmm6,%xmm6
  49a756:	vmovss %xmm6,(%rdi)
  49a75a:	mov    0x1e0(%rsp),%rdi
  49a762:	sub    %r12d,%ecx
  49a765:	vcvtsi2ss %ecx,%xmm0,%xmm6
  49a769:	lea    0xc(%rdi,%r9,1),%rsi
  49a76e:	test   $0x4,%al
  49a770:	je     49aeb0 <velri_slang_dot_linear_w8a8_f32_packed+0x2870>
  49a776:	mov    0x1b8(%rsp),%rcx
  49a77e:	vmovss (%rcx),%xmm9
  49a782:	test   $0x2,%al
  49a784:	je     49a798 <velri_slang_dot_linear_w8a8_f32_packed+0x2158>
  49a786:	mov    0x1e8(%rsp),%rcx
  49a78e:	vmovq  %xmm15,%rdi
  49a793:	vmulss (%rcx,%rdi,4),%xmm9,%xmm9
  49a798:	vmulss %xmm9,%xmm6,%xmm6
  49a79d:	test   $0x1,%al
  49a79f:	je     49a7ad <velri_slang_dot_linear_w8a8_f32_packed+0x216d>
  49a7a1:	mov    0x1b0(%rsp),%rcx
  49a7a9:	vaddss (%rcx),%xmm6,%xmm6
  49a7ad:	mov    0x1e0(%rsp),%rcx
  49a7b5:	sub    %r12d,%edx
  49a7b8:	vmovss %xmm6,(%rsi)
  49a7bc:	vcvtsi2ss %edx,%xmm0,%xmm6
  49a7c0:	lea    0x10(%rcx,%r9,1),%rcx
  49a7c5:	test   $0x4,%al
  49a7c7:	je     49aea0 <velri_slang_dot_linear_w8a8_f32_packed+0x2860>
  49a7cd:	mov    0x1c8(%rsp),%rdx
  49a7d5:	vmovss (%rdx),%xmm9
  49a7d9:	test   $0x2,%al
  49a7db:	je     49a7ef <velri_slang_dot_linear_w8a8_f32_packed+0x21af>
  49a7dd:	mov    0x1e8(%rsp),%rdx
  49a7e5:	vmovq  %xmm15,%rdi
  49a7ea:	vmulss (%rdx,%rdi,4),%xmm9,%xmm9
  49a7ef:	vmulss %xmm9,%xmm6,%xmm6
  49a7f4:	test   $0x1,%al
  49a7f6:	je     49aef0 <velri_slang_dot_linear_w8a8_f32_packed+0x28b0>
  49a7fc:	mov    0x1c0(%rsp),%rdx
  49a804:	add    $0x1,%rbx
  49a808:	vaddss (%rdx),%xmm6,%xmm6
  49a80c:	vmovss %xmm6,(%rcx)
  49a810:	cmp    0xf8(%rsp),%ebx
  49a817:	jb     49a240 <velri_slang_dot_linear_w8a8_f32_packed+0x1c00>
  49a81d:	addl   $0x5,0xb0(%rsp)
  49a825:	mov    0x40(%rbp),%eax
  49a828:	sub    0xb0(%rsp),%eax
  49a82f:	cmp    $0x4,%eax
  49a832:	ja     498980 <velri_slang_dot_linear_w8a8_f32_packed+0x340>
  49a838:	mov    0xb0(%rsp),%r13d
  49a840:	mov    0x28(%rbp),%ebx
  49a843:	mov    0x38(%rbp),%r10d
  49a847:	mov    0x48(%rbp),%edi
  49a84a:	mov    0x2c(%rsp),%r11d
  49a84f:	cmp    0x40(%rbp),%r13d
  49a853:	jae    499feb <velri_slang_dot_linear_w8a8_f32_packed+0x19ab>
  49a859:	mov    %r13d,%r8d
  49a85c:	mov    0x30(%rsp),%rdx
  49a861:	mov    %ebx,0x28(%rbp)
  49a864:	lea    0x0(,%r8,4),%rax
  49a86c:	mov    %r10d,0x38(%rbp)
  49a870:	lea    (%rdx,%rax,1),%r13
  49a874:	mov    0x40(%rsp),%rdx
  49a879:	lea    (%rdx,%rax,1),%r14
  49a87d:	mov    0x70(%rsp),%rax
  49a882:	mov    0xf0(%rsp),%rdx
  49a88a:	imul   %r8,%rax
  49a88e:	add    %rdx,%rax
  49a891:	mov    0xb4(%rsp),%edx
  49a898:	mov    %rax,0x1c0(%rsp)
  49a8a0:	mov    %r11d,%eax
  49a8a3:	and    $0xfffffffc,%eax
  49a8a6:	lea    0x4(%rax),%ecx
  49a8a9:	xor    %eax,%eax
  49a8ab:	cmpl   $0x3,0x7c(%rsp)
  49a8b0:	cmova  %ecx,%eax
  49a8b3:	mov    %ecx,0x1a8(%rsp)
  49a8ba:	mov    %eax,%esi
  49a8bc:	mov    %r11d,%eax
  49a8bf:	and    $0xfffffffc,%eax
  49a8c2:	mov    %esi,0x1a0(%rsp)
  49a8c9:	lea    0x4(%rdx,%rax,1),%eax
  49a8cd:	vmovd  %eax,%xmm14
  49a8d1:	nopl   0x0(%rax)
  49a8d5:	data16 cs nopw 0x0(%rax,%rax,1)
  49a8e0:	mov    0x1c0(%rsp),%rax
  49a8e8:	sub    0xf0(%rsp),%rax
  49a8f0:	mov    %rax,0x1c8(%rsp)
  49a8f8:	mov    0xd8(%rsp),%r10
  49a900:	cmpl   $0x3,0x7c(%rsp)
  49a905:	jbe    49af69 <velri_slang_dot_linear_w8a8_f32_packed+0x2929>
  49a90b:	mov    0xb4(%rsp),%r9d
  49a913:	mov    0x10(%rbp),%r15d
  49a917:	mov    %edi,%ebx
  49a919:	mov    %r8,%rdi
  49a91c:	nopl   0x0(%rax)
  49a920:	lea    0x1(%r9),%eax
  49a924:	vmovd  %r9d,%xmm10
  49a929:	vmovq  %rax,%xmm9
  49a92e:	lea    0x2(%r9),%eax
  49a932:	vmovq  %rax,%xmm8
  49a937:	lea    0x3(%r9),%eax
  49a93b:	vmovq  %rax,%xmm7
  49a940:	test   %ebx,%ebx
  49a942:	je     49af30 <velri_slang_dot_linear_w8a8_f32_packed+0x28f0>
  49a948:	mov    0xe8(%rsp),%rax
  49a950:	vmovq  %xmm10,%rdx
  49a955:	mov    %rax,%rcx
  49a958:	imul   %rdx,%rcx
  49a95c:	vmovq  %xmm9,%rdx
  49a961:	vmovq  %rcx,%xmm11
  49a966:	mov    %rax,%rcx
  49a969:	imul   %rdx,%rcx
  49a96d:	vmovq  %xmm8,%rdx
  49a972:	vmovq  %rcx,%xmm15
  49a977:	mov    %rax,%rcx
  49a97a:	imul   %rdx,%rcx
  49a97e:	vmovq  %xmm7,%rdx
  49a983:	imul   %rdx,%rax
  49a987:	vmovq  %rcx,%xmm12
  49a98c:	vmovq  %rax,%xmm13
  49a991:	cmpl   $0x3e,0xe4(%rsp)
  49a999:	jbe    49b3e3 <velri_slang_dot_linear_w8a8_f32_packed+0x2da3>
  49a99f:	mov    0x170(%rsp),%rax
  49a9a7:	vmovq  %xmm13,%rdx
  49a9ac:	vpxor  %xmm1,%xmm1,%xmm1
  49a9b0:	vmovdqa32 %zmm1,%zmm3
  49a9b6:	vmovdqa32 %zmm1,%zmm18
  49a9bc:	vmovdqa32 %zmm1,%zmm6
  49a9c2:	lea    (%rax,%rdx,1),%rsi
  49a9c6:	vmovq  %xmm15,%rdx
  49a9cb:	lea    (%rax,%rcx,1),%rcx
  49a9cf:	lea    (%rax,%rdx,1),%r12
  49a9d3:	vmovq  %xmm11,%rdx
  49a9d8:	add    %rax,%rdx
  49a9db:	xor    %eax,%eax
  49a9dd:	xchg   %ax,%ax
  49a9df:	data16 cs nopw 0x0(%rax,%rax,1)
  49a9ea:	data16 cs nopw 0x0(%rax,%rax,1)
  49a9f5:	data16 cs nopw 0x0(%rax,%rax,1)
  49aa00:	mov    0x1c0(%rsp),%r11
  49aa08:	vmovdqu8 (%r11,%rax,1),%zmm4
  49aa0f:	vpdpbusd (%rdx,%rax,1),%zmm4,%zmm1
  49aa16:	vpdpbusd (%r12,%rax,1),%zmm4,%zmm3
  49aa1d:	vpdpbusd (%rcx,%rax,1),%zmm4,%zmm18
  49aa24:	vpdpbusd (%rsi,%rax,1),%zmm4,%zmm6
  49aa2b:	add    $0x40,%rax
  49aa2f:	cmp    0xa0(%rsp),%rax
  49aa37:	jne    49aa00 <velri_slang_dot_linear_w8a8_f32_packed+0x23c0>
  49aa39:	vextracti32x8 $0x1,%zmm1,%ymm5
  49aa40:	vpaddd %ymm1,%ymm5,%ymm5
  49aa44:	vextracti32x4 $0x1,%ymm5,%xmm1
  49aa4b:	vpaddd %xmm5,%xmm1,%xmm1
  49aa4f:	vpsrldq $0x8,%xmm1,%xmm4
  49aa54:	vpaddd %xmm4,%xmm1,%xmm1
  49aa58:	vpsrldq $0x4,%xmm1,%xmm4
  49aa5d:	vpaddd %xmm4,%xmm1,%xmm1
  49aa61:	vextracti32x8 $0x1,%zmm3,%ymm4
  49aa68:	vpaddd %ymm3,%ymm4,%ymm4
  49aa6c:	vmovd  %xmm1,%esi
  49aa70:	vextracti32x4 $0x1,%ymm4,%xmm1
  49aa77:	vpaddd %xmm4,%xmm1,%xmm1
  49aa7b:	vpsrldq $0x8,%xmm1,%xmm3
  49aa80:	vpaddd %xmm3,%xmm1,%xmm1
  49aa84:	vpsrldq $0x4,%xmm1,%xmm3
  49aa89:	vpaddd %xmm3,%xmm1,%xmm1
  49aa8d:	vextracti32x8 $0x1,%zmm18,%ymm3
  49aa94:	vpaddd %ymm18,%ymm3,%ymm3
  49aa9a:	vmovd  %xmm1,0x1d0(%rsp)
  49aaa3:	vextracti32x4 $0x1,%ymm3,%xmm1
  49aaaa:	vpaddd %xmm3,%xmm1,%xmm1
  49aaae:	vpsrldq $0x8,%xmm1,%xmm18
  49aab5:	vpaddd %xmm18,%xmm1,%xmm1
  49aabb:	vpsrldq $0x4,%xmm1,%xmm18
  49aac2:	vpaddd %xmm18,%xmm1,%xmm1
  49aac8:	vmovd  %xmm1,%edx
  49aacc:	vextracti32x8 $0x1,%zmm6,%ymm1
  49aad3:	vpaddd %ymm6,%ymm1,%ymm1
  49aad7:	vextracti32x4 $0x1,%ymm1,%xmm6
  49aade:	vpaddd %xmm1,%xmm6,%xmm6
  49aae2:	vpsrldq $0x8,%xmm6,%xmm18
  49aae9:	vpaddd %xmm18,%xmm6,%xmm6
  49aaef:	vpsrldq $0x4,%xmm6,%xmm18
  49aaf6:	vpaddd %xmm18,%xmm6,%xmm6
  49aafc:	vmovd  %xmm6,%eax
  49ab00:	test   $0x3f,%bl
  49ab03:	je     49acb3 <velri_slang_dot_linear_w8a8_f32_packed+0x2673>
  49ab09:	mov    %ebx,%ecx
  49ab0b:	and    $0xffffffc0,%ecx
  49ab0e:	mov    %ebx,%r8d
  49ab11:	sub    %ecx,%r8d
  49ab14:	lea    -0x1(%r8),%r11d
  49ab18:	cmp    $0x1e,%r11d
  49ab1c:	jbe    49ac14 <velri_slang_dot_linear_w8a8_f32_packed+0x25d4>
  49ab22:	mov    0xf0(%rsp),%rdx
  49ab2a:	mov    %ecx,%eax
  49ab2c:	mov    0x1c8(%rsp),%rsi
  49ab34:	add    %rax,%rdx
  49ab37:	vmovdqu8 (%rdx,%rsi,1),%ymm6
  49ab3e:	mov    0x170(%rsp),%rsi
  49ab46:	vmovq  %xmm12,%rdx
  49ab4b:	vpdpbusd (%r12,%rax,1),%ymm6,%ymm4
  49ab52:	add    %rsi,%rdx
  49ab55:	vpdpbusd (%rdx,%rax,1),%ymm6,%ymm3
  49ab5c:	vmovq  %xmm13,%rdx
  49ab61:	add    %rsi,%rdx
  49ab64:	vpdpbusd (%rdx,%rax,1),%ymm6,%ymm1
  49ab6b:	vmovq  %xmm11,%rdx
  49ab70:	add    %rsi,%rdx
  49ab73:	vpdpbusd (%rdx,%rax,1),%ymm6,%ymm5
  49ab7a:	vextracti32x4 $0x1,%ymm5,%xmm6
  49ab81:	vpaddd %xmm5,%xmm6,%xmm5
  49ab85:	vpsrldq $0x8,%xmm5,%xmm6
  49ab8a:	vpaddd %xmm6,%xmm5,%xmm5
  49ab8e:	vpsrldq $0x4,%xmm5,%xmm6
  49ab93:	vpaddd %xmm6,%xmm5,%xmm5
  49ab97:	vmovd  %xmm5,%esi
  49ab9b:	vextracti32x4 $0x1,%ymm4,%xmm5
  49aba2:	vpaddd %xmm4,%xmm5,%xmm4
  49aba6:	vpsrldq $0x8,%xmm4,%xmm5
  49abab:	vpaddd %xmm5,%xmm4,%xmm4
  49abaf:	vpsrldq $0x4,%xmm4,%xmm5
  49abb4:	vpaddd %xmm5,%xmm4,%xmm4
  49abb8:	vmovd  %xmm4,0x1d0(%rsp)
  49abc1:	vextracti32x4 $0x1,%ymm3,%xmm4
  49abc8:	vpaddd %xmm3,%xmm4,%xmm3
  49abcc:	vpsrldq $0x8,%xmm3,%xmm4
  49abd1:	vpaddd %xmm4,%xmm3,%xmm3
  49abd5:	vpsrldq $0x4,%xmm3,%xmm4
  49abda:	vpaddd %xmm4,%xmm3,%xmm3
  49abde:	vmovd  %xmm3,%edx
  49abe2:	vextracti32x4 $0x1,%ymm1,%xmm3
  49abe9:	vpaddd %xmm1,%xmm3,%xmm1
  49abed:	vpsrldq $0x8,%xmm1,%xmm3
  49abf2:	vpaddd %xmm3,%xmm1,%xmm1
  49abf6:	vpsrldq $0x4,%xmm1,%xmm3
  49abfb:	vpaddd %xmm3,%xmm1,%xmm1
  49abff:	vmovd  %xmm1,%eax
  49ac03:	test   $0x1f,%r8b
  49ac07:	je     49acb3 <velri_slang_dot_linear_w8a8_f32_packed+0x2673>
  49ac0d:	and    $0xffffffe0,%r8d
  49ac11:	add    %r8d,%ecx
  49ac14:	mov    %r10,0x1b8(%rsp)
  49ac1c:	mov    %ecx,%r11d
  49ac1f:	mov    %rdi,0x1b0(%rsp)
  49ac27:	add    %r11,%r12
  49ac2a:	add    0x1c0(%rsp),%r11
  49ac32:	nopl   (%rax)
  49ac35:	data16 cs nopw 0x0(%rax,%rax,1)
  49ac40:	mov    %r12,%r8
  49ac43:	vmovq  %xmm15,%rdi
  49ac48:	add    $0x1,%ecx
  49ac4b:	add    $0x1,%r12
  49ac4f:	sub    %rdi,%r8
  49ac52:	vmovq  %xmm11,%r10
  49ac57:	movzbl (%r11),%edi
  49ac5b:	add    $0x1,%r11
  49ac5f:	movsbl (%r8,%r10,1),%r10d
  49ac64:	imul   %edi,%r10d
  49ac68:	add    %r10d,%esi
  49ac6b:	movsbl -0x1(%r12),%r10d
  49ac71:	imul   %edi,%r10d
  49ac75:	add    %r10d,0x1d0(%rsp)
  49ac7d:	vmovq  %xmm12,%r10
  49ac82:	movsbl (%r8,%r10,1),%r10d
  49ac87:	imul   %edi,%r10d
  49ac8b:	add    %r10d,%edx
  49ac8e:	vmovq  %xmm13,%r10
  49ac93:	movsbl (%r8,%r10,1),%r8d
  49ac98:	imul   %edi,%r8d
  49ac9c:	add    %r8d,%eax
  49ac9f:	cmp    %ebx,%ecx
  49aca1:	jb     49ac40 <velri_slang_dot_linear_w8a8_f32_packed+0x2600>
  49aca3:	mov    0x1b8(%rsp),%r10
  49acab:	mov    0x1b0(%rsp),%rdi
  49acb3:	mov    0x1d8(%rsp),%r8
  49acbb:	vmovq  %xmm10,%rcx
  49acc0:	sub    (%r10),%esi
  49acc3:	vcvtsi2ss %esi,%xmm0,%xmm1
  49acc7:	imul   %rcx,%r8
  49accb:	mov    0x1e0(%rsp),%rcx
  49acd3:	add    %rdi,%r8
  49acd6:	lea    (%rcx,%r8,4),%r8
  49acda:	test   $0x4,%r15b
  49acde:	je     49ae90 <velri_slang_dot_linear_w8a8_f32_packed+0x2850>
  49ace4:	vmovss (%r14),%xmm3
  49ace9:	test   $0x2,%r15b
  49aced:	je     49ad01 <velri_slang_dot_linear_w8a8_f32_packed+0x26c1>
  49acef:	mov    0x1e8(%rsp),%rcx
  49acf7:	vmovq  %xmm10,%rsi
  49acfc:	vmulss (%rcx,%rsi,4),%xmm3,%xmm3
  49ad01:	vmulss %xmm3,%xmm1,%xmm1
  49ad05:	test   $0x1,%r15b
  49ad09:	je     49ad11 <velri_slang_dot_linear_w8a8_f32_packed+0x26d1>
  49ad0b:	vaddss 0x0(%r13),%xmm1,%xmm1
  49ad11:	mov    0x1d8(%rsp),%rsi
  49ad19:	vmovq  %xmm9,%rcx
  49ad1e:	vmovss %xmm1,(%r8)
  49ad23:	imul   %rcx,%rsi
  49ad27:	mov    0x1e0(%rsp),%rcx
  49ad2f:	add    %rdi,%rsi
  49ad32:	lea    (%rcx,%rsi,4),%rsi
  49ad36:	mov    0x1d0(%rsp),%ecx
  49ad3d:	sub    0x4(%r10),%ecx
  49ad41:	vcvtsi2ss %ecx,%xmm0,%xmm1
  49ad45:	test   $0x4,%r15b
  49ad49:	je     49ae80 <velri_slang_dot_linear_w8a8_f32_packed+0x2840>
  49ad4f:	vmovss (%r14),%xmm3
  49ad54:	test   $0x2,%r15b
  49ad58:	je     49ad6d <velri_slang_dot_linear_w8a8_f32_packed+0x272d>
  49ad5a:	mov    0x1e8(%rsp),%rcx
  49ad62:	vmovq  %xmm9,%r11
  49ad67:	vmulss (%rcx,%r11,4),%xmm3,%xmm3
  49ad6d:	vmulss %xmm3,%xmm1,%xmm1
  49ad71:	test   $0x1,%r15b
  49ad75:	je     49ad7d <velri_slang_dot_linear_w8a8_f32_packed+0x273d>
  49ad77:	vaddss 0x0(%r13),%xmm1,%xmm1
  49ad7d:	mov    0x1d8(%rsp),%rcx
  49ad85:	vmovss %xmm1,(%rsi)
  49ad89:	vmovq  %xmm8,%rsi
  49ad8e:	sub    0x8(%r10),%edx
  49ad92:	vcvtsi2ss %edx,%xmm0,%xmm1
  49ad96:	imul   %rsi,%rcx
  49ad9a:	mov    0x1e0(%rsp),%rsi
  49ada2:	add    %rdi,%rcx
  49ada5:	lea    (%rsi,%rcx,4),%rcx
  49ada9:	test   $0x4,%r15b
  49adad:	je     49ae70 <velri_slang_dot_linear_w8a8_f32_packed+0x2830>
  49adb3:	vmovss (%r14),%xmm3
  49adb8:	test   $0x2,%r15b
  49adbc:	je     49add0 <velri_slang_dot_linear_w8a8_f32_packed+0x2790>
  49adbe:	mov    0x1e8(%rsp),%rdx
  49adc6:	vmovq  %xmm8,%rsi
  49adcb:	vmulss (%rdx,%rsi,4),%xmm3,%xmm3
  49add0:	vmulss %xmm3,%xmm1,%xmm1
  49add4:	test   $0x1,%r15b
  49add8:	je     49ade0 <velri_slang_dot_linear_w8a8_f32_packed+0x27a0>
  49adda:	vaddss 0x0(%r13),%xmm1,%xmm1
  49ade0:	mov    0x1d8(%rsp),%rdx
  49ade8:	vmovss %xmm1,(%rcx)
  49adec:	vmovq  %xmm7,%rcx
  49adf1:	sub    0xc(%r10),%eax
  49adf5:	vcvtsi2ss %eax,%xmm0,%xmm1
  49adf9:	imul   %rcx,%rdx
  49adfd:	mov    0x1e0(%rsp),%rcx
  49ae05:	add    %rdi,%rdx
  49ae08:	lea    (%rcx,%rdx,4),%rdx
  49ae0c:	test   $0x4,%r15b
  49ae10:	je     49ae60 <velri_slang_dot_linear_w8a8_f32_packed+0x2820>
  49ae12:	vmovss (%r14),%xmm3
  49ae17:	test   $0x2,%r15b
  49ae1b:	je     49ae2f <velri_slang_dot_linear_w8a8_f32_packed+0x27ef>
  49ae1d:	mov    0x1e8(%rsp),%rax
  49ae25:	vmovq  %xmm7,%rcx
  49ae2a:	vmulss (%rax,%rcx,4),%xmm3,%xmm3
  49ae2f:	vmulss %xmm3,%xmm1,%xmm1
  49ae33:	test   $0x1,%r15b
  49ae37:	je     49ae3f <velri_slang_dot_linear_w8a8_f32_packed+0x27ff>
  49ae39:	vaddss 0x0(%r13),%xmm1,%xmm1
  49ae3f:	add    $0x4,%r9d
  49ae43:	vmovd  %xmm14,%eax
  49ae47:	vmovss %xmm1,(%rdx)
  49ae4b:	cmp    %eax,%r9d
  49ae4e:	je     49af50 <velri_slang_dot_linear_w8a8_f32_packed+0x2910>
  49ae54:	add    $0x10,%r10
  49ae58:	jmp    49a920 <velri_slang_dot_linear_w8a8_f32_packed+0x22e0>
  49ae5d:	nopl   (%rax)
  49ae60:	vmovss 0x31a4(%rip),%xmm3        # 49e00c <_IO_stdin_used+0xc>
  49ae68:	jmp    49ae17 <velri_slang_dot_linear_w8a8_f32_packed+0x27d7>
  49ae6a:	nopw   0x0(%rax,%rax,1)
  49ae70:	vmovss 0x3194(%rip),%xmm3        # 49e00c <_IO_stdin_used+0xc>
  49ae78:	jmp    49adb8 <velri_slang_dot_linear_w8a8_f32_packed+0x2778>
  49ae7d:	nopl   (%rax)
  49ae80:	vmovss 0x3184(%rip),%xmm3        # 49e00c <_IO_stdin_used+0xc>
  49ae88:	jmp    49ad54 <velri_slang_dot_linear_w8a8_f32_packed+0x2714>
  49ae8d:	nopl   (%rax)
  49ae90:	vmovss 0x3174(%rip),%xmm3        # 49e00c <_IO_stdin_used+0xc>
  49ae98:	jmp    49ace9 <velri_slang_dot_linear_w8a8_f32_packed+0x26a9>
  49ae9d:	nopl   (%rax)
  49aea0:	vmovss 0x3164(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49aea8:	jmp    49a7d9 <velri_slang_dot_linear_w8a8_f32_packed+0x2199>
  49aead:	nopl   (%rax)
  49aeb0:	vmovss 0x3154(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49aeb8:	jmp    49a782 <velri_slang_dot_linear_w8a8_f32_packed+0x2142>
  49aebd:	nopl   (%rax)
  49aec0:	vmovss 0x3144(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49aec8:	jmp    49a72a <velri_slang_dot_linear_w8a8_f32_packed+0x20ea>
  49aecd:	nopl   (%rax)
  49aed0:	vmovss 0x3134(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49aed8:	jmp    49a6d1 <velri_slang_dot_linear_w8a8_f32_packed+0x2091>
  49aedd:	nopl   (%rax)
  49aee0:	vmovss 0x3124(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  49aee8:	jmp    49a676 <velri_slang_dot_linear_w8a8_f32_packed+0x2036>
  49aeed:	nopl   (%rax)
  49aef0:	vmovss %xmm6,(%rcx)
  49aef4:	add    $0x1,%rbx
  49aef8:	cmp    0xf8(%rsp),%ebx
  49aeff:	jae    49a81d <velri_slang_dot_linear_w8a8_f32_packed+0x21dd>
  49af05:	lea    (%r11,%rbx,1),%edx
  49af09:	vmovq  %rdx,%xmm15
  49af0e:	test   %r10d,%r10d
  49af11:	jne    49a252 <velri_slang_dot_linear_w8a8_f32_packed+0x1c12>
  49af17:	xor    %edx,%edx
  49af19:	xor    %ecx,%ecx
  49af1b:	xor    %esi,%esi
  49af1d:	xor    %edi,%edi
  49af1f:	xor    %r8d,%r8d
  49af22:	jmp    49a624 <velri_slang_dot_linear_w8a8_f32_packed+0x1fe4>
  49af27:	nopw   0x0(%rax,%rax,1)
  49af30:	movl   $0x0,0x1d0(%rsp)
  49af3b:	xor    %eax,%eax
  49af3d:	xor    %edx,%edx
  49af3f:	xor    %esi,%esi
  49af41:	jmp    49acb3 <velri_slang_dot_linear_w8a8_f32_packed+0x2673>
  49af46:	cs nopw 0x0(%rax,%rax,1)
  49af50:	mov    %rdi,%r8
  49af53:	mov    0xf8(%rsp),%edx
  49af5a:	mov    %ebx,%edi
  49af5c:	cmp    %edx,0x1a8(%rsp)
  49af63:	jae    499fc1 <velri_slang_dot_linear_w8a8_f32_packed+0x1981>
  49af69:	mov    0xf8(%rsp),%ebx
  49af70:	mov    0x1a0(%rsp),%r9d
  49af78:	mov    0x1e8(%rsp),%r15
  49af80:	mov    0xb4(%rsp),%eax
  49af87:	lea    (%rax,%r9,1),%r11d
  49af8b:	test   %edi,%edi
  49af8d:	je     49b163 <velri_slang_dot_linear_w8a8_f32_packed+0x2b23>
  49af93:	mov    0xe8(%rsp),%r12
  49af9b:	imul   %r11,%r12
  49af9f:	cmpl   $0x3e,0xe4(%rsp)
  49afa7:	jbe    49b41c <velri_slang_dot_linear_w8a8_f32_packed+0x2ddc>
  49afad:	mov    0x170(%rsp),%rax
  49afb5:	vpxor  %xmm3,%xmm3,%xmm3
  49afb9:	lea    (%rax,%r12,1),%rdx
  49afbd:	xor    %eax,%eax
  49afbf:	nop
  49afc0:	mov    0x1c0(%rsp),%rcx
  49afc8:	vmovdqu8 (%rcx,%rax,1),%zmm1
  49afcf:	vpdpbusd (%rdx,%rax,1),%zmm1,%zmm3
  49afd6:	add    $0x40,%rax
  49afda:	cmp    %rax,0xa0(%rsp)
  49afe2:	jne    49afc0 <velri_slang_dot_linear_w8a8_f32_packed+0x2980>
  49afe4:	vextracti32x8 $0x1,%zmm3,%ymm1
  49afeb:	vpaddd %ymm3,%ymm1,%ymm1
  49afef:	vextracti32x4 $0x1,%ymm1,%xmm3
  49aff6:	vpaddd %xmm1,%xmm3,%xmm3
  49affa:	vpsrldq $0x8,%xmm3,%xmm4
  49afff:	vpaddd %xmm4,%xmm3,%xmm3
  49b003:	vpsrldq $0x4,%xmm3,%xmm4
  49b008:	vpaddd %xmm4,%xmm3,%xmm3
  49b00c:	vmovd  %xmm3,%edx
  49b010:	test   $0x3f,%dil
  49b014:	je     49b0e9 <velri_slang_dot_linear_w8a8_f32_packed+0x2aa9>
  49b01a:	mov    %edi,%eax
  49b01c:	and    $0xffffffc0,%eax
  49b01f:	mov    %edi,%ecx
  49b021:	sub    %eax,%ecx
  49b023:	lea    -0x1(%rcx),%esi
  49b026:	cmp    $0x1e,%esi
  49b029:	jbe    49b084 <velri_slang_dot_linear_w8a8_f32_packed+0x2a44>
  49b02b:	mov    0xf0(%rsp),%rsi
  49b033:	mov    %eax,%edx
  49b035:	mov    0x1c8(%rsp),%r10
  49b03d:	add    %rdx,%rsi
  49b040:	vmovdqu8 (%rsi,%r10,1),%ymm3
  49b047:	mov    0x170(%rsp),%rsi
  49b04f:	add    %r12,%rsi
  49b052:	vpdpbusd (%rsi,%rdx,1),%ymm3,%ymm1
  49b059:	vextracti32x4 $0x1,%ymm1,%xmm3
  49b060:	vpaddd %xmm1,%xmm3,%xmm1
  49b064:	vpsrldq $0x8,%xmm1,%xmm3
  49b069:	vpaddd %xmm3,%xmm1,%xmm1
  49b06d:	vpsrldq $0x4,%xmm1,%xmm3
  49b072:	vpaddd %xmm3,%xmm1,%xmm1
  49b076:	vmovd  %xmm1,%edx
  49b07a:	test   $0x1f,%cl
  49b07d:	je     49b0e9 <velri_slang_dot_linear_w8a8_f32_packed+0x2aa9>
  49b07f:	and    $0xffffffe0,%ecx
  49b082:	add    %ecx,%eax
  49b084:	mov    0x1c8(%rsp),%rsi
  49b08c:	mov    %eax,%r10d
  49b08f:	mov    %r14,0x1d0(%rsp)
  49b097:	xor    %ecx,%ecx
  49b099:	mov    %r8,%r14
  49b09c:	add    %r10,%rsi
  49b09f:	add    %r12,%r10
  49b0a2:	add    0xf0(%rsp),%rsi
  49b0aa:	add    0x170(%rsp),%r10
  49b0b2:	mov    %r10,%r8
  49b0b5:	mov    %rsi,%r10
  49b0b8:	mov    %eax,%esi
  49b0ba:	nopw   0x0(%rax,%rax,1)
  49b0c0:	movzbl (%r10,%rcx,1),%r12d
  49b0c5:	movsbl (%r8,%rcx,1),%eax
  49b0ca:	add    $0x1,%rcx
  49b0ce:	imul   %eax,%r12d
  49b0d2:	add    %r12d,%edx
  49b0d5:	lea    (%rsi,%rcx,1),%r12d
  49b0d9:	cmp    %edi,%r12d
  49b0dc:	jb     49b0c0 <velri_slang_dot_linear_w8a8_f32_packed+0x2a80>
  49b0de:	mov    %r14,%r8
  49b0e1:	mov    0x1d0(%rsp),%r14
  49b0e9:	mov    0x1d8(%rsp),%rax
  49b0f1:	mov    0x1e0(%rsp),%rcx
  49b0f9:	imul   %r11,%rax
  49b0fd:	add    %r8,%rax
  49b100:	lea    (%rcx,%rax,4),%rax
  49b104:	mov    0xd8(%rsp),%rcx
  49b10c:	sub    (%rcx,%r9,4),%edx
  49b110:	vcvtsi2ss %edx,%xmm0,%xmm1
  49b114:	testb  $0x4,0x10(%rbp)
  49b118:	je     49b170 <velri_slang_dot_linear_w8a8_f32_packed+0x2b30>
  49b11a:	vmovss (%r14),%xmm3
  49b11f:	testb  $0x2,0x10(%rbp)
  49b123:	je     49b12b <velri_slang_dot_linear_w8a8_f32_packed+0x2aeb>
  49b125:	vmulss (%r15,%r11,4),%xmm3,%xmm3
  49b12b:	vmulss %xmm3,%xmm1,%xmm1
  49b12f:	testb  $0x1,0x10(%rbp)
  49b133:	je     499fb0 <velri_slang_dot_linear_w8a8_f32_packed+0x1970>
  49b139:	vaddss 0x0(%r13),%xmm1,%xmm1
  49b13f:	add    $0x1,%r9
  49b143:	vmovss %xmm1,(%rax)
  49b147:	cmp    %ebx,%r9d
  49b14a:	jae    499fc1 <velri_slang_dot_linear_w8a8_f32_packed+0x1981>
  49b150:	mov    0xb4(%rsp),%eax
  49b157:	lea    (%rax,%r9,1),%r11d
  49b15b:	test   %edi,%edi
  49b15d:	jne    49af93 <velri_slang_dot_linear_w8a8_f32_packed+0x2953>
  49b163:	xor    %edx,%edx
  49b165:	jmp    49b0e9 <velri_slang_dot_linear_w8a8_f32_packed+0x2aa9>
  49b167:	nopw   0x0(%rax,%rax,1)
  49b170:	vmovss 0x2e94(%rip),%xmm3        # 49e00c <_IO_stdin_used+0xc>
  49b178:	jmp    49b11f <velri_slang_dot_linear_w8a8_f32_packed+0x2adf>
  49b17a:	nopw   0x0(%rax,%rax,1)
  49b180:	movl   $0x0,0x104(%rsp)
  49b18b:	xor    %r8d,%r8d
  49b18e:	movl   $0x0,0xfc(%rsp)
  49b199:	movl   $0x0,0x100(%rsp)
  49b1a4:	movl   $0x0,0x144(%rsp)
  49b1af:	movl   $0x0,0x140(%rsp)
  49b1ba:	movl   $0x0,0x13c(%rsp)
  49b1c5:	movl   $0x0,0x138(%rsp)
  49b1d0:	movl   $0x0,0x134(%rsp)
  49b1db:	movl   $0x0,0x130(%rsp)
  49b1e6:	movl   $0x0,0x12c(%rsp)
  49b1f1:	movl   $0x0,0x128(%rsp)
  49b1fc:	movl   $0x0,0x124(%rsp)
  49b207:	movl   $0x0,0x120(%rsp)
  49b212:	movl   $0x0,0x11c(%rsp)
  49b21d:	movl   $0x0,0x118(%rsp)
  49b228:	movl   $0x0,0x114(%rsp)
  49b233:	movl   $0x0,0x108(%rsp)
  49b23e:	movl   $0x0,0x110(%rsp)
  49b249:	movl   $0x0,0x10c(%rsp)
  49b254:	jmp    49992d <velri_slang_dot_linear_w8a8_f32_packed+0x12ed>
  49b259:	mov    0x170(%rsp),%r12
  49b261:	xor    %edx,%edx
  49b263:	xor    %ecx,%ecx
  49b265:	xor    %esi,%esi
  49b267:	vpxor  %xmm7,%xmm7,%xmm7
  49b26b:	xor    %edi,%edi
  49b26d:	xor    %r8d,%r8d
  49b270:	xor    %r15d,%r15d
  49b273:	vmovdqa %ymm7,%ymm6
  49b277:	vmovdqa %ymm7,%ymm11
  49b27b:	vmovdqa %ymm7,%ymm10
  49b27f:	vmovdqa %ymm7,%ymm9
  49b283:	lea    (%r12,%r9,1),%r13
  49b287:	jmp    49a427 <velri_slang_dot_linear_w8a8_f32_packed+0x1de7>
  49b28c:	vpxor  %xmm6,%xmm6,%xmm6
  49b290:	xor    %r8d,%r8d
  49b293:	mov    0x170(%rsp),%rbx
  49b29b:	movl   $0x0,0x104(%rsp)
  49b2a6:	movl   $0x0,0xfc(%rsp)
  49b2b1:	xor    %r14d,%r14d
  49b2b4:	vmovdqa %ymm6,%ymm7
  49b2b8:	vmovdqa32 %ymm6,%ymm20
  49b2be:	movl   $0x0,0x100(%rsp)
  49b2c9:	vmovdqa32 %ymm6,%ymm22
  49b2cf:	vmovdqa32 %ymm6,%ymm16
  49b2d5:	vmovdqa32 %ymm6,%ymm21
  49b2db:	movl   $0x0,0x144(%rsp)
  49b2e6:	vmovdqa32 %ymm6,%ymm19
  49b2ec:	vmovdqa %ymm6,%ymm5
  49b2f0:	vmovdqa32 %ymm6,%ymm30
  49b2f6:	movl   $0x0,0x140(%rsp)
  49b301:	vmovdqa %ymm6,%ymm15
  49b305:	vmovdqa %ymm6,%ymm9
  49b309:	vmovdqa32 %ymm6,%ymm26
  49b30f:	movl   $0x0,0x13c(%rsp)
  49b31a:	vmovdqa32 %ymm6,%ymm31
  49b320:	vmovdqa32 %ymm6,%ymm17
  49b326:	vmovdqa32 %ymm6,%ymm18
  49b32c:	movl   $0x0,0x138(%rsp)
  49b337:	vmovdqa32 %ymm6,%ymm27
  49b33d:	vmovdqa %ymm6,%ymm2
  49b341:	vmovdqa %ymm6,%ymm1
  49b345:	movl   $0x0,0x134(%rsp)
  49b350:	vmovdqa %ymm6,%ymm4
  49b354:	add    0xb8(%rsp),%rbx
  49b35c:	movl   $0x0,0x130(%rsp)
  49b367:	movl   $0x0,0x12c(%rsp)
  49b372:	movl   $0x0,0x128(%rsp)
  49b37d:	movl   $0x0,0x124(%rsp)
  49b388:	movl   $0x0,0x120(%rsp)
  49b393:	movl   $0x0,0x11c(%rsp)
  49b39e:	movl   $0x0,0x118(%rsp)
  49b3a9:	movl   $0x0,0x114(%rsp)
  49b3b4:	movl   $0x0,0x108(%rsp)
  49b3bf:	movl   $0x0,0x110(%rsp)
  49b3ca:	movl   $0x0,0x10c(%rsp)
  49b3d5:	vmovdqa %ymm6,0x80(%rsp)
  49b3de:	jmp    49925c <velri_slang_dot_linear_w8a8_f32_packed+0xc1c>
  49b3e3:	mov    0x170(%rsp),%r11
  49b3eb:	xor    %eax,%eax
  49b3ed:	xor    %edx,%edx
  49b3ef:	xor    %esi,%esi
  49b3f1:	vpxor  %xmm5,%xmm5,%xmm5
  49b3f5:	vmovq  %xmm15,%r8
  49b3fa:	xor    %ecx,%ecx
  49b3fc:	movl   $0x0,0x1d0(%rsp)
  49b407:	vmovdqa %ymm5,%ymm4
  49b40b:	vmovdqa %ymm5,%ymm3
  49b40f:	vmovdqa %ymm5,%ymm1
  49b413:	lea    (%r11,%r8,1),%r12
  49b417:	jmp    49ab0e <velri_slang_dot_linear_w8a8_f32_packed+0x24ce>
  49b41c:	vpxor  %xmm1,%xmm1,%xmm1
  49b420:	xor    %edx,%edx
  49b422:	xor    %eax,%eax
  49b424:	jmp    49b01f <velri_slang_dot_linear_w8a8_f32_packed+0x29df>
  49b429:	vpxor  %xmm4,%xmm4,%xmm4
  49b42d:	vpxor  %xmm1,%xmm1,%xmm1
  49b431:	xor    %eax,%eax
  49b433:	add    %r14,%rdx
  49b436:	jmp    49884b <velri_slang_dot_linear_w8a8_f32_packed+0x20b>
  49b43b:	vpslld $0x7,%xmm1,%xmm1
  49b440:	add    $0x1,%esi
  49b443:	vmovd  %xmm1,(%r8)
  49b448:	cmp    %ebx,%esi
  49b44a:	je     498910 <velri_slang_dot_linear_w8a8_f32_packed+0x2d0>
  49b450:	mov    %esi,%edx
  49b452:	add    $0x4,%r8
  49b456:	imul   %r11,%rdx
  49b45a:	jmp    4987a0 <velri_slang_dot_linear_w8a8_f32_packed+0x160>
  49b45f:	call   402220 <__stack_chk_fail@plt>

Disassembly of section .fini:
