
graph:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004956b0 <velri_slang_dot_linear_w8a8_f32>:
  4956b0:	endbr64
  4956b4:	push   %rbp
  4956b5:	vmovq  %r8,%xmm4
  4956ba:	mov    %rsp,%rbp
  4956bd:	push   %r15
  4956bf:	push   %r14
  4956c1:	push   %r13
  4956c3:	push   %r12
  4956c5:	push   %rbx
  4956c6:	and    $0xffffffffffffffc0,%rsp
  4956ca:	sub    $0x300,%rsp
  4956d1:	mov    0x20(%rbp),%rax
  4956d5:	vmovq  0x10(%rbp),%xmm2
  4956da:	mov    %rdx,0xf0(%rsp)
  4956e2:	mov    %rax,0x1e0(%rsp)
  4956ea:	mov    0x38(%rbp),%eax
  4956ed:	mov    %r9,0x1e8(%rsp)
  4956f5:	mov    %fs:0x28,%r8
  4956fe:	mov    %r8,0x2f8(%rsp)
  495706:	mov    0x40(%rbp),%r8d
  49570a:	cmp    %eax,0x30(%rbp)
  49570d:	jae    497101 <velri_slang_dot_linear_w8a8_f32+0x1a51>
  495713:	cmp    0x48(%rbp),%r8d
  495717:	jae    497101 <velri_slang_dot_linear_w8a8_f32+0x1a51>
  49571d:	mov    %esi,%eax
  49571f:	mov    0x28(%rbp),%r14d
  495723:	mov    %rdi,%r15
  495726:	mov    0x48(%rbp),%edx
  495729:	vmovd  %ecx,%xmm7
  49572d:	mov    0x30(%rbp),%ebx
  495730:	mov    0x50(%rbp),%r9d
  495734:	vxorps %xmm0,%xmm0,%xmm0
  495738:	mov    %rax,0xe8(%rsp)
  495740:	mov    0x50(%rbp),%eax
  495743:	sub    %r8d,%edx
  495746:	mov    %r14,0x1d8(%rsp)
  49574e:	mov    %edx,%edi
  495750:	sub    $0x1,%eax
  495753:	mov    %r15,0x170(%rsp)
  49575b:	mov    %eax,0xf8(%rsp)
  495762:	lea    0x1f0(%rsp),%rax
  49576a:	mov    %rax,0xd8(%rsp)
  495772:	mov    0x50(%rbp),%eax
  495775:	vmovq  %xmm2,0x28(%rsp)
  49577b:	shr    $0x6,%eax
  49577e:	vmovq  %xmm7,0x40(%rsp)
  495784:	shl    $0x6,%rax
  495788:	vmovq  %xmm4,0x38(%rsp)
  49578e:	mov    %rax,0x78(%rsp)
  495793:	mov    $0x80808080,%eax
  495798:	vpbroadcastd %eax,%ymm1
  49579e:	mov    0x38(%rbp),%edx
  4957a1:	mov    $0x40,%eax
  4957a6:	mov    %ebx,%esi
  4957a8:	mov    %ebx,0x94(%rsp)
  4957af:	mov    0xd8(%rsp),%r10
  4957b7:	mov    %esi,%ecx
  4957b9:	movl   $0x0,0x1f0(%rsp)
  4957c4:	sub    %ebx,%edx
  4957c6:	cmp    %eax,%edx
  4957c8:	mov    %edx,0x88(%rsp)
  4957cf:	cmovbe %edx,%eax
  4957d2:	mov    %r10,%rdx
  4957d5:	mov    %eax,0xe4(%rsp)
  4957dc:	add    %eax,%ebx
  4957de:	test   %r9d,%r9d
  4957e1:	je     497127 <velri_slang_dot_linear_w8a8_f32+0x1a77>
  4957e7:	mov    0xe8(%rsp),%r11
  4957ef:	mov    0xf8(%rsp),%r12d
  4957f7:	mov    0x78(%rsp),%r15
  4957fc:	mov    0x170(%rsp),%r14
  495804:	nop
  495805:	data16 cs nopw 0x0(%rax,%rax,1)
  495810:	mov    %esi,%ecx
  495812:	imul   %r11,%rcx
  495816:	cmp    $0x3e,%r12d
  49581a:	jbe    4985fa <velri_slang_dot_linear_w8a8_f32+0x2f4a>
  495820:	add    %r14,%rcx
  495823:	vpxor  %xmm5,%xmm5,%xmm5
  495827:	mov    %rcx,%rax
  49582a:	lea    (%r15,%rcx,1),%rdx
  49582e:	xchg   %ax,%ax
  495830:	vmovdqu8 (%rax),%zmm2
  495836:	add    $0x40,%rax
  49583a:	vpmovsxbw %ymm2,%zmm3
  495840:	vextracti64x4 $0x1,%zmm2,%ymm2
  495847:	vpmovsxbw %ymm2,%zmm2
  49584d:	vpmovsxwd %ymm2,%zmm4
  495853:	vextracti64x4 $0x1,%zmm2,%ymm2
  49585a:	vpmovsxwd %ymm2,%zmm2
  495860:	vpaddd %zmm2,%zmm4,%zmm2
  495866:	vpmovsxwd %ymm3,%zmm4
  49586c:	vextracti64x4 $0x1,%zmm3,%ymm3
  495873:	vpmovsxwd %ymm3,%zmm3
  495879:	vpaddd %zmm3,%zmm4,%zmm3
  49587f:	vpaddd %zmm3,%zmm2,%zmm2
  495885:	vpaddd %zmm2,%zmm5,%zmm5
  49588b:	cmp    %rdx,%rax
  49588e:	jne    495830 <velri_slang_dot_linear_w8a8_f32+0x180>
  495890:	vextracti32x8 $0x1,%zmm5,%ymm3
  495897:	vpaddd %ymm5,%ymm3,%ymm3
  49589b:	vextracti32x4 $0x1,%ymm3,%xmm2
  4958a2:	vpaddd %xmm3,%xmm2,%xmm2
  4958a6:	vpsrldq $0x8,%xmm2,%xmm4
  4958ab:	vpaddd %xmm4,%xmm2,%xmm2
  4958af:	vpsrldq $0x4,%xmm2,%xmm4
  4958b4:	vpaddd %xmm4,%xmm2,%xmm2
  4958b8:	test   $0x3f,%r9b
  4958bc:	je     49860c <velri_slang_dot_linear_w8a8_f32+0x2f5c>
  4958c2:	mov    %r9d,%edx
  4958c5:	vmovdqa %ymm3,%ymm5
  4958c9:	and    $0xffffffc0,%edx
  4958cc:	mov    %r9d,%eax
  4958cf:	sub    %edx,%eax
  4958d1:	lea    -0x1(%rax),%r13d
  4958d5:	cmp    $0x1e,%r13d
  4958d9:	jbe    49594e <velri_slang_dot_linear_w8a8_f32+0x29e>
  4958db:	mov    %edx,%r13d
  4958de:	vmovdqu8 (%rcx,%r13,1),%ymm2
  4958e5:	vpmovsxbw %xmm2,%ymm4
  4958ea:	vextracti32x4 $0x1,%ymm2,%xmm2
  4958f1:	vpmovsxwd %xmm4,%ymm3
  4958f6:	vextracti32x4 $0x1,%ymm4,%xmm4
  4958fd:	vpmovsxbw %xmm2,%ymm2
  495902:	vpmovsxwd %xmm4,%ymm4
  495907:	vpaddd %ymm4,%ymm3,%ymm3
  49590b:	vpmovsxwd %xmm2,%ymm4
  495910:	vextracti32x4 $0x1,%ymm2,%xmm2
  495917:	vpmovsxwd %xmm2,%ymm2
  49591c:	vpaddd %ymm5,%ymm3,%ymm3
  495920:	vpaddd %ymm2,%ymm4,%ymm2
  495924:	vpaddd %ymm2,%ymm3,%ymm3
  495928:	vextracti32x4 $0x1,%ymm3,%xmm2
  49592f:	vpaddd %xmm3,%xmm2,%xmm2
  495933:	vpsrldq $0x8,%xmm2,%xmm3
  495938:	vpaddd %xmm3,%xmm2,%xmm2
  49593c:	vpsrldq $0x4,%xmm2,%xmm3
  495941:	vpaddd %xmm3,%xmm2,%xmm2
  495945:	test   $0x1f,%al
  495947:	je     495977 <velri_slang_dot_linear_w8a8_f32+0x2c7>
  495949:	and    $0xffffffe0,%eax
  49594c:	add    %eax,%edx
  49594e:	mov    %edx,%eax
  495950:	add    %rcx,%rax
  495953:	sub    %eax,%edx
  495955:	data16 cs nopw 0x0(%rax,%rax,1)
  495960:	movsbl (%rax),%ecx
  495963:	add    $0x1,%rax
  495967:	vmovd  %ecx,%xmm3
  49596b:	lea    (%rdx,%rax,1),%ecx
  49596e:	vpaddd %xmm3,%xmm2,%xmm2
  495972:	cmp    %r9d,%ecx
  495975:	jb     495960 <velri_slang_dot_linear_w8a8_f32+0x2b0>
  495977:	vpslld $0x7,%xmm2,%xmm2
  49597c:	add    $0x1,%esi
  49597f:	add    $0x4,%r10
  495983:	vmovd  %xmm2,-0x4(%r10)
  495989:	cmp    %esi,%ebx
  49598b:	jne    495810 <velri_slang_dot_linear_w8a8_f32+0x160>
  495991:	cmp    $0x4,%edi
  495994:	jbe    497153 <velri_slang_dot_linear_w8a8_f32+0x1aa3>
  49599a:	mov    0xe4(%rsp),%eax
  4959a1:	mov    %r8d,0x8c(%rsp)
  4959a9:	mov    %edi,0x24(%rsp)
  4959ad:	mov    0x40(%rsp),%r10
  4959b2:	lea    -0x4(%rax),%edx
  4959b5:	mov    %r8d,0x40(%rbp)
  4959b9:	mov    %edx,%eax
  4959bb:	mov    %r9d,0x50(%rbp)
  4959bf:	and    $0xfffffffc,%eax
  4959c2:	mov    %edx,0x20(%rsp)
  4959c6:	lea    0x4(%rax),%ecx
  4959c9:	xor    %eax,%eax
  4959cb:	cmpl   $0x3,0x88(%rsp)
  4959d3:	mov    %ebx,0x30(%rbp)
  4959d6:	cmova  %ecx,%eax
  4959d9:	mov    %ecx,0x34(%rsp)
  4959dd:	mov    0x94(%rsp),%ecx
  4959e4:	mov    0x28(%rsp),%rbx
  4959e9:	mov    %eax,0x30(%rsp)
  4959ed:	mov    %edx,%eax
  4959ef:	and    $0xfffffffc,%eax
  4959f2:	lea    0x4(%rcx,%rax,1),%r14d
  4959f7:	mov    %r14d,0xe0(%rsp)
  4959ff:	nop
  495a00:	mov    0x8c(%rsp),%r11d
  495a08:	mov    %r10,%rdi
  495a0b:	mov    %r11,%rcx
  495a0e:	lea    0x1(%r11),%eax
  495a12:	lea    0x2(%r11),%edx
  495a16:	mov    %r11,%rsi
  495a19:	imul   %r10,%rcx
  495a1d:	add    $0x4,%esi
  495a20:	mov    %r11,0x178(%rsp)
  495a28:	mov    %rcx,0x168(%rsp)
  495a30:	mov    %r10,%rcx
  495a33:	imul   %rax,%rcx
  495a37:	shl    $0x2,%rax
  495a3b:	mov    %rcx,0x160(%rsp)
  495a43:	mov    %r10,%rcx
  495a46:	imul   %rdx,%rcx
  495a4a:	shl    $0x2,%rdx
  495a4e:	mov    %rcx,0x158(%rsp)
  495a56:	lea    0x3(%r11),%ecx
  495a5a:	imul   %rcx,%rdi
  495a5e:	shl    $0x2,%rcx
  495a62:	mov    %rdi,0x150(%rsp)
  495a6a:	mov    %r10,%rdi
  495a6d:	imul   %rsi,%rdi
  495a71:	shl    $0x2,%rsi
  495a75:	mov    %rdi,0x148(%rsp)
  495a7d:	lea    (%rbx,%rsi,1),%rdi
  495a81:	mov    %rdi,0x1c8(%rsp)
  495a89:	mov    0x38(%rsp),%rdi
  495a8e:	add    %rdi,%rsi
  495a91:	mov    %rsi,0x1c0(%rsp)
  495a99:	lea    (%rbx,%rcx,1),%rsi
  495a9d:	add    %rdi,%rcx
  495aa0:	mov    %rcx,0x1b0(%rsp)
  495aa8:	lea    (%rbx,%rdx,1),%rcx
  495aac:	add    %rdi,%rdx
  495aaf:	mov    %rdx,0x1a0(%rsp)
  495ab7:	lea    (%rbx,%rax,1),%rdx
  495abb:	add    %rdi,%rax
  495abe:	mov    %rax,0x190(%rsp)
  495ac6:	lea    0x0(,%r11,4),%rax
  495ace:	mov    %rdx,0x198(%rsp)
  495ad6:	lea    (%rbx,%rax,1),%rdx
  495ada:	add    %rdi,%rax
  495add:	mov    %rsi,0x1b8(%rsp)
  495ae5:	mov    %rcx,0x1a8(%rsp)
  495aed:	mov    %rdx,0x188(%rsp)
  495af5:	mov    %rax,0x180(%rsp)
  495afd:	cmpl   $0x3,0x88(%rsp)
  495b05:	jbe    4972d9 <velri_slang_dot_linear_w8a8_f32+0x1c29>
  495b0b:	mov    0xd8(%rsp),%rax
  495b13:	mov    0x160(%rsp),%rcx
  495b1b:	mov    %rbx,0x70(%rsp)
  495b20:	mov    %r10,0x68(%rsp)
  495b25:	mov    0x94(%rsp),%r15d
  495b2d:	mov    %rax,0x1d0(%rsp)
  495b35:	mov    0xf0(%rsp),%rax
  495b3d:	add    %rax,%rcx
  495b40:	mov    %rcx,0x80(%rsp)
  495b48:	mov    0x148(%rsp),%rcx
  495b50:	lea    (%rax,%rcx,1),%rdx
  495b54:	mov    0x150(%rsp),%rcx
  495b5c:	mov    %rdx,0x60(%rsp)
  495b61:	lea    (%rax,%rcx,1),%rdx
  495b65:	mov    0x158(%rsp),%rcx
  495b6d:	mov    %rdx,0x58(%rsp)
  495b72:	lea    (%rax,%rcx,1),%rdx
  495b76:	add    0x168(%rsp),%rax
  495b7e:	mov    0x1e0(%rsp),%rcx
  495b86:	mov    %rdx,0x50(%rsp)
  495b8b:	mov    0x1e8(%rsp),%rdx
  495b93:	mov    %rax,0x48(%rsp)
  495b98:	mov    0x18(%rbp),%eax
  495b9b:	nopl   0x0(%rax,%rax,1)
  495ba0:	mov    0x50(%rbp),%esi
  495ba3:	mov    %r15d,%ebx
  495ba6:	lea    0x1(%r15),%r11d
  495baa:	lea    0x2(%r15),%r10d
  495bae:	lea    0x3(%r15),%r9d
  495bb2:	test   %esi,%esi
  495bb4:	je     498348 <velri_slang_dot_linear_w8a8_f32+0x2c98>
  495bba:	mov    0xe8(%rsp),%r14
  495bc2:	mov    %r14,%rdi
  495bc5:	mov    %r14,%rsi
  495bc8:	mov    %r14,%r8
  495bcb:	imul   %rbx,%rdi
  495bcf:	imul   %r11,%rsi
  495bd3:	imul   %r10,%r8
  495bd7:	imul   %r9,%r14
  495bdb:	mov    %rdi,0xd0(%rsp)
  495be3:	mov    %rsi,0x98(%rsp)
  495beb:	mov    %r8,0xc8(%rsp)
  495bf3:	mov    %r14,0xc0(%rsp)
  495bfb:	cmpl   $0x3e,0xf8(%rsp)
  495c03:	jbe    498459 <velri_slang_dot_linear_w8a8_f32+0x2da9>
  495c09:	mov    0x170(%rsp),%r13
  495c11:	vpxord %xmm18,%xmm18,%xmm18
  495c17:	vmovdqa32 %zmm18,%zmm25
  495c1d:	vmovdqa32 %zmm18,%zmm24
  495c23:	vmovdqa32 %zmm18,%zmm23
  495c29:	lea    0x0(%r13,%r14,1),%r12
  495c2e:	add    %r13,%r8
  495c31:	add    %r13,%rdi
  495c34:	lea    0x0(%r13,%rsi,1),%r14
  495c39:	mov    $0x80808080,%r13d
  495c3f:	xor    %esi,%esi
  495c41:	vmovdqa32 %zmm18,%zmm22
  495c47:	vmovdqa32 %zmm18,%zmm21
  495c4d:	vmovdqa32 %zmm18,%zmm20
  495c53:	vmovdqa32 %zmm18,%zmm19
  495c59:	vmovdqa32 %zmm18,%zmm8
  495c5f:	vmovdqa32 %zmm18,%zmm9
  495c65:	vmovdqa32 %zmm18,%zmm10
  495c6b:	vmovdqa32 %zmm18,%zmm11
  495c71:	vmovdqa32 %zmm18,%zmm12
  495c77:	vmovdqa32 %zmm18,%zmm13
  495c7d:	vmovdqa32 %zmm18,%zmm14
  495c83:	vmovdqa32 %zmm18,%zmm27
  495c89:	vmovdqa32 %zmm18,%zmm28
  495c8f:	vmovdqa32 %zmm18,%zmm29
  495c95:	vmovdqa32 %zmm18,%zmm30
  495c9b:	vmovdqa32 %zmm18,%zmm31
  495ca1:	vpbroadcastd %r13d,%zmm7
  495ca7:	nopw   0x0(%rax,%rax,1)
  495cb0:	mov    0x48(%rsp),%r13
  495cb5:	vmovdqu8 (%rdi,%rsi,1),%zmm3
  495cbc:	vmovdqu8 (%r14,%rsi,1),%zmm4
  495cc3:	vmovdqu8 (%r8,%rsi,1),%zmm5
  495cca:	vpxorq 0x0(%r13,%rsi,1),%zmm7,%zmm2
  495cd2:	vpmovsxbw %ymm3,%zmm26
  495cd8:	mov    0x80(%rsp),%r13
  495ce0:	vmovdqu8 (%r12,%rsi,1),%zmm6
  495ce7:	vpdpbusd %zmm4,%zmm2,%zmm21
  495ced:	vpmovzxbw %ymm2,%zmm15
  495cf3:	vpdpwssd %zmm26,%zmm15,%zmm18
  495cf9:	vextracti64x4 $0x1,%zmm2,%ymm26
  495d00:	vpdpbusd %zmm5,%zmm2,%zmm10
  495d06:	vpmovzxbw %ymm26,%zmm15
  495d0c:	vextracti64x4 $0x1,%zmm3,%ymm26
  495d13:	vpdpbusd %zmm6,%zmm2,%zmm27
  495d19:	vpmovsxbw %ymm26,%zmm26
  495d1f:	vpdpwssd %zmm26,%zmm15,%zmm18
  495d25:	vpxorq 0x0(%r13,%rsi,1),%zmm7,%zmm26
  495d2d:	mov    0x50(%rsp),%r13
  495d32:	vpdpbusd %zmm3,%zmm26,%zmm25
  495d38:	vpdpbusd %zmm4,%zmm26,%zmm20
  495d3e:	vpdpbusd %zmm5,%zmm26,%zmm11
  495d44:	vpdpbusd %zmm6,%zmm26,%zmm28
  495d4a:	vpxorq 0x0(%r13,%rsi,1),%zmm7,%zmm26
  495d52:	mov    0x58(%rsp),%r13
  495d57:	vpdpbusd %zmm3,%zmm26,%zmm24
  495d5d:	vpdpbusd %zmm4,%zmm26,%zmm19
  495d63:	vpdpbusd %zmm5,%zmm26,%zmm12
  495d69:	vpdpbusd %zmm6,%zmm26,%zmm29
  495d6f:	vpxorq 0x0(%r13,%rsi,1),%zmm7,%zmm26
  495d77:	mov    0x60(%rsp),%r13
  495d7c:	vpdpbusd %zmm3,%zmm26,%zmm23
  495d82:	vpdpbusd %zmm4,%zmm26,%zmm8
  495d88:	vpdpbusd %zmm5,%zmm26,%zmm13
  495d8e:	vpdpbusd %zmm6,%zmm26,%zmm30
  495d94:	vpxorq 0x0(%r13,%rsi,1),%zmm7,%zmm26
  495d9c:	add    $0x40,%rsi
  495da0:	vpdpbusd %zmm3,%zmm26,%zmm22
  495da6:	vpdpbusd %zmm4,%zmm26,%zmm9
  495dac:	vpdpbusd %zmm5,%zmm26,%zmm14
  495db2:	vpdpbusd %zmm6,%zmm26,%zmm31
  495db8:	cmp    0x78(%rsp),%rsi
  495dbd:	jne    495cb0 <velri_slang_dot_linear_w8a8_f32+0x600>
  495dc3:	vextracti32x8 $0x1,%zmm18,%ymm26
  495dca:	vpaddd %ymm18,%ymm26,%ymm4
  495dd0:	vextracti32x4 $0x1,%ymm4,%xmm18
  495dd7:	vpaddd %xmm4,%xmm18,%xmm26
  495ddd:	vpsrldq $0x8,%xmm26,%xmm18
  495de4:	vpaddd %xmm18,%xmm26,%xmm18
  495dea:	vpsrldq $0x4,%xmm18,%xmm26
  495df1:	vpaddd %xmm26,%xmm18,%xmm18
  495df7:	vmovd  %xmm18,%r8d
  495dfd:	vextracti32x8 $0x1,%zmm25,%ymm18
  495e04:	vpaddd %ymm25,%ymm18,%ymm26
  495e0a:	vextracti32x4 $0x1,%ymm26,%xmm18
  495e11:	vpaddd %xmm26,%xmm18,%xmm25
  495e17:	vpsrldq $0x8,%xmm25,%xmm18
  495e1e:	vpaddd %xmm18,%xmm25,%xmm18
  495e24:	vpsrldq $0x4,%xmm18,%xmm25
  495e2b:	vpaddd %xmm25,%xmm18,%xmm18
  495e31:	vmovd  %xmm18,0x144(%rsp)
  495e39:	vextracti32x8 $0x1,%zmm24,%ymm18
  495e40:	vpaddd %ymm24,%ymm18,%ymm25
  495e46:	vextracti32x4 $0x1,%ymm25,%xmm18
  495e4d:	vpaddd %xmm25,%xmm18,%xmm24
  495e53:	vpsrldq $0x8,%xmm24,%xmm18
  495e5a:	vpaddd %xmm18,%xmm24,%xmm18
  495e60:	vpsrldq $0x4,%xmm18,%xmm24
  495e67:	vpaddd %xmm24,%xmm18,%xmm18
  495e6d:	vmovd  %xmm18,0x140(%rsp)
  495e75:	vextracti32x8 $0x1,%zmm23,%ymm18
  495e7c:	vpaddd %ymm23,%ymm18,%ymm24
  495e82:	vextracti32x4 $0x1,%ymm24,%xmm18
  495e89:	vpaddd %xmm24,%xmm18,%xmm23
  495e8f:	vpsrldq $0x8,%xmm23,%xmm18
  495e96:	vpaddd %xmm18,%xmm23,%xmm18
  495e9c:	vpsrldq $0x4,%xmm18,%xmm23
  495ea3:	vpaddd %xmm23,%xmm18,%xmm18
  495ea9:	vmovd  %xmm18,0x13c(%rsp)
  495eb1:	vextracti32x8 $0x1,%zmm22,%ymm18
  495eb8:	vpaddd %ymm22,%ymm18,%ymm23
  495ebe:	vextracti32x4 $0x1,%ymm23,%xmm18
  495ec5:	vpaddd %xmm23,%xmm18,%xmm22
  495ecb:	vpsrldq $0x8,%xmm22,%xmm18
  495ed2:	vpaddd %xmm18,%xmm22,%xmm18
  495ed8:	vpsrldq $0x4,%xmm18,%xmm22
  495edf:	vpaddd %xmm22,%xmm18,%xmm18
  495ee5:	vmovd  %xmm18,0x138(%rsp)
  495eed:	vextracti32x8 $0x1,%zmm21,%ymm18
  495ef4:	vpaddd %ymm21,%ymm18,%ymm22
  495efa:	vextracti32x4 $0x1,%ymm22,%xmm18
  495f01:	vpaddd %xmm22,%xmm18,%xmm21
  495f07:	vpsrldq $0x8,%xmm21,%xmm18
  495f0e:	vpaddd %xmm18,%xmm21,%xmm18
  495f14:	vpsrldq $0x4,%xmm18,%xmm21
  495f1b:	vpaddd %xmm21,%xmm18,%xmm18
  495f21:	vmovd  %xmm18,0x114(%rsp)
  495f29:	vextracti32x8 $0x1,%zmm20,%ymm18
  495f30:	vpaddd %ymm20,%ymm18,%ymm21
  495f36:	vextracti32x4 $0x1,%ymm21,%xmm18
  495f3d:	vpaddd %xmm21,%xmm18,%xmm20
  495f43:	vpsrldq $0x8,%xmm20,%xmm18
  495f4a:	vpaddd %xmm18,%xmm20,%xmm18
  495f50:	vpsrldq $0x4,%xmm18,%xmm20
  495f57:	vpaddd %xmm20,%xmm18,%xmm18
  495f5d:	vmovd  %xmm18,0xfc(%rsp)
  495f65:	vextracti32x8 $0x1,%zmm19,%ymm18
  495f6c:	vpaddd %ymm19,%ymm18,%ymm20
  495f72:	vextracti32x4 $0x1,%ymm20,%xmm18
  495f79:	vpaddd %xmm20,%xmm18,%xmm19
  495f7f:	vpsrldq $0x8,%xmm19,%xmm18
  495f86:	vpaddd %xmm18,%xmm19,%xmm18
  495f8c:	vpsrldq $0x4,%xmm18,%xmm19
  495f93:	vpaddd %xmm19,%xmm18,%xmm18
  495f99:	vmovd  %xmm18,0x100(%rsp)
  495fa1:	vextracti32x8 $0x1,%zmm8,%ymm18
  495fa8:	vpaddd %ymm8,%ymm18,%ymm8
  495fae:	vextracti32x4 $0x1,%ymm8,%xmm18
  495fb5:	vpaddd %xmm8,%xmm18,%xmm19
  495fbb:	vpsrldq $0x8,%xmm19,%xmm18
  495fc2:	vpaddd %xmm18,%xmm19,%xmm18
  495fc8:	vpsrldq $0x4,%xmm18,%xmm19
  495fcf:	vpaddd %xmm19,%xmm18,%xmm18
  495fd5:	vmovd  %xmm18,0x104(%rsp)
  495fdd:	vextracti32x8 $0x1,%zmm9,%ymm18
  495fe4:	vpaddd %ymm9,%ymm18,%ymm9
  495fea:	vextracti32x4 $0x1,%ymm9,%xmm18
  495ff1:	vpaddd %xmm9,%xmm18,%xmm19
  495ff7:	vpsrldq $0x8,%xmm19,%xmm18
  495ffe:	vpaddd %xmm18,%xmm19,%xmm18
  496004:	vpsrldq $0x4,%xmm18,%xmm19
  49600b:	vpaddd %xmm19,%xmm18,%xmm18
  496011:	vmovd  %xmm18,0x108(%rsp)
  496019:	vextracti32x8 $0x1,%zmm10,%ymm18
  496020:	vpaddd %ymm10,%ymm18,%ymm10
  496026:	vextracti32x4 $0x1,%ymm10,%xmm18
  49602d:	vpaddd %xmm10,%xmm18,%xmm19
  496033:	vpsrldq $0x8,%xmm19,%xmm18
  49603a:	vpaddd %xmm18,%xmm19,%xmm18
  496040:	vpsrldq $0x4,%xmm18,%xmm19
  496047:	vpaddd %xmm19,%xmm18,%xmm18
  49604d:	vmovd  %xmm18,0x10c(%rsp)
  496055:	vextracti32x8 $0x1,%zmm11,%ymm18
  49605c:	vpaddd %ymm11,%ymm18,%ymm11
  496062:	vextracti32x4 $0x1,%ymm11,%xmm18
  496069:	vpaddd %xmm11,%xmm18,%xmm19
  49606f:	vpsrldq $0x8,%xmm19,%xmm18
  496076:	vpaddd %xmm18,%xmm19,%xmm18
  49607c:	vpsrldq $0x4,%xmm18,%xmm19
  496083:	vpaddd %xmm19,%xmm18,%xmm18
  496089:	vmovd  %xmm18,0x110(%rsp)
  496091:	vextracti32x8 $0x1,%zmm12,%ymm18
  496098:	vpaddd %ymm12,%ymm18,%ymm12
  49609e:	vextracti32x4 $0x1,%ymm12,%xmm18
  4960a5:	vpaddd %xmm12,%xmm18,%xmm19
  4960ab:	vpsrldq $0x8,%xmm19,%xmm18
  4960b2:	vpaddd %xmm18,%xmm19,%xmm18
  4960b8:	vpsrldq $0x4,%xmm18,%xmm19
  4960bf:	vpaddd %xmm19,%xmm18,%xmm18
  4960c5:	vmovd  %xmm18,0x118(%rsp)
  4960cd:	vextracti32x8 $0x1,%zmm13,%ymm18
  4960d4:	vpaddd %ymm13,%ymm18,%ymm13
  4960da:	vextracti32x4 $0x1,%ymm13,%xmm18
  4960e1:	vpaddd %xmm13,%xmm18,%xmm19
  4960e7:	vpsrldq $0x8,%xmm19,%xmm18
  4960ee:	vpaddd %xmm18,%xmm19,%xmm18
  4960f4:	vpsrldq $0x4,%xmm18,%xmm19
  4960fb:	vpaddd %xmm19,%xmm18,%xmm18
  496101:	vmovd  %xmm18,0x11c(%rsp)
  496109:	vextracti32x8 $0x1,%zmm14,%ymm18
  496110:	vpaddd %ymm14,%ymm18,%ymm14
  496116:	vextracti32x4 $0x1,%ymm14,%xmm18
  49611d:	vpaddd %xmm14,%xmm18,%xmm19
  496123:	vpsrldq $0x8,%xmm19,%xmm18
  49612a:	vpaddd %xmm18,%xmm19,%xmm18
  496130:	vpsrldq $0x4,%xmm18,%xmm19
  496137:	vpaddd %xmm19,%xmm18,%xmm18
  49613d:	vmovd  %xmm18,0x120(%rsp)
  496145:	vextracti32x8 $0x1,%zmm27,%ymm18
  49614c:	vpaddd %ymm27,%ymm18,%ymm27
  496152:	vextracti32x4 $0x1,%ymm27,%xmm18
  496159:	vpaddd %xmm27,%xmm18,%xmm19
  49615f:	vpsrldq $0x8,%xmm19,%xmm18
  496166:	vpaddd %xmm18,%xmm19,%xmm18
  49616c:	vpsrldq $0x4,%xmm18,%xmm19
  496173:	vpaddd %xmm19,%xmm18,%xmm18
  496179:	vmovd  %xmm18,0x124(%rsp)
  496181:	vextracti32x8 $0x1,%zmm28,%ymm18
  496188:	vpaddd %ymm28,%ymm18,%ymm28
  49618e:	vextracti32x4 $0x1,%ymm28,%xmm18
  496195:	vpaddd %xmm28,%xmm18,%xmm19
  49619b:	vpsrldq $0x8,%xmm19,%xmm18
  4961a2:	vpaddd %xmm18,%xmm19,%xmm18
  4961a8:	vpsrldq $0x4,%xmm18,%xmm19
  4961af:	vpaddd %xmm19,%xmm18,%xmm18
  4961b5:	vmovd  %xmm18,0x128(%rsp)
  4961bd:	vextracti32x8 $0x1,%zmm29,%ymm18
  4961c4:	vpaddd %ymm29,%ymm18,%ymm29
  4961ca:	vextracti32x4 $0x1,%ymm29,%xmm18
  4961d1:	vpaddd %xmm29,%xmm18,%xmm19
  4961d7:	vpsrldq $0x8,%xmm19,%xmm18
  4961de:	vpaddd %xmm18,%xmm19,%xmm18
  4961e4:	vpsrldq $0x4,%xmm18,%xmm19
  4961eb:	vpaddd %xmm19,%xmm18,%xmm18
  4961f1:	vmovd  %xmm18,0x12c(%rsp)
  4961f9:	vextracti32x8 $0x1,%zmm30,%ymm18
  496200:	vpaddd %ymm30,%ymm18,%ymm30
  496206:	vextracti32x4 $0x1,%ymm30,%xmm18
  49620d:	vpaddd %xmm30,%xmm18,%xmm19
  496213:	vpsrldq $0x8,%xmm19,%xmm18
  49621a:	vpaddd %xmm18,%xmm19,%xmm18
  496220:	vpsrldq $0x4,%xmm18,%xmm19
  496227:	vpaddd %xmm19,%xmm18,%xmm18
  49622d:	vmovd  %xmm18,0x130(%rsp)
  496235:	vextracti32x8 $0x1,%zmm31,%ymm18
  49623c:	vpaddd %ymm31,%ymm18,%ymm31
  496242:	vextracti32x4 $0x1,%ymm31,%xmm18
  496249:	vpaddd %xmm31,%xmm18,%xmm19
  49624f:	vpsrldq $0x8,%xmm19,%xmm18
  496256:	vpaddd %xmm18,%xmm19,%xmm18
  49625c:	vpsrldq $0x4,%xmm18,%xmm19
  496263:	vpaddd %xmm19,%xmm18,%xmm18
  496269:	vmovd  %xmm18,0x134(%rsp)
  496271:	testb  $0x3f,0x50(%rbp)
  496275:	je     496a2b <velri_slang_dot_linear_w8a8_f32+0x137b>
  49627b:	mov    0x50(%rbp),%r13d
  49627f:	vmovdqa32 %ymm31,%ymm5
  496285:	vmovdqa32 %ymm29,%ymm3
  49628b:	vmovdqa32 %ymm28,%ymm31
  496291:	vmovdqa %ymm9,%ymm7
  496295:	vmovdqa32 %ymm8,%ymm17
  49629b:	vmovdqa32 %ymm23,%ymm15
  4962a1:	vmovdqa %ymm12,0xa0(%rsp)
  4962aa:	vmovdqa32 %ymm22,%ymm8
  4962b0:	and    $0xffffffc0,%r13d
  4962b4:	vmovdqa32 %ymm30,%ymm2
  4962ba:	vmovdqa %ymm14,%ymm6
  4962be:	vmovdqa32 %ymm13,%ymm16
  4962c4:	vmovdqa32 %ymm11,%ymm29
  4962ca:	vmovdqa32 %ymm21,%ymm28
  4962d0:	vmovdqa32 %ymm25,%ymm23
  4962d6:	vmovdqa32 %ymm26,%ymm22
  4962dc:	vmovdqa %ymm4,%ymm9
  4962e0:	mov    0x50(%rbp),%r12d
  4962e4:	sub    %r13d,%r12d
  4962e7:	lea    -0x1(%r12),%esi
  4962ec:	cmp    $0x1e,%esi
  4962ef:	jbe    496808 <velri_slang_dot_linear_w8a8_f32+0x1158>
  4962f5:	mov    %r13d,%esi
  4962f8:	mov    0x170(%rsp),%r8
  496300:	mov    0xd0(%rsp),%rdi
  496308:	vmovdqa %ymm9,%ymm4
  49630c:	vmovdqu8 (%r14,%rsi,1),%ymm19
  496313:	vmovdqa32 %ymm27,%ymm30
  496319:	vmovdqa32 %ymm29,%ymm27
  49631f:	vmovdqa32 %ymm24,%ymm9
  496325:	add    %r8,%rdi
  496328:	vmovdqa32 %ymm16,%ymm29
  49632e:	vmovdqu8 (%rdi,%rsi,1),%ymm12
  496335:	mov    0xc8(%rsp),%rdi
  49633d:	add    %r8,%rdi
  496340:	vpmovsxbw %xmm12,%ymm11
  496345:	vmovdqu8 (%rdi,%rsi,1),%ymm18
  49634c:	mov    0xc0(%rsp),%rdi
  496354:	add    %r8,%rdi
  496357:	vmovdqu8 (%rdi,%rsi,1),%ymm14
  49635e:	mov    0x168(%rsp),%rdi
  496366:	add    0xf0(%rsp),%rsi
  49636e:	vpxorq (%rsi,%rdi,1),%ymm1,%ymm13
  496375:	mov    0x160(%rsp),%rdi
  49637d:	vpdpbusd %ymm19,%ymm13,%ymm8
  496383:	vpmovzxbw %xmm13,%ymm21
  496389:	vpdpwssd %ymm11,%ymm21,%ymm4
  49638f:	vmovdqa32 %ymm22,%ymm11
  496395:	vpdpbusd %ymm18,%ymm13,%ymm10
  49639b:	vpdpbusd %ymm14,%ymm13,%ymm30
  4963a1:	vextracti32x4 $0x1,%ymm13,%xmm13
  4963a8:	vpmovzxbw %xmm13,%ymm13
  4963ad:	vmovdqa32 %ymm8,%ymm21
  4963b3:	vpxorq (%rsi,%rdi,1),%ymm1,%ymm8
  4963ba:	mov    0x158(%rsp),%rdi
  4963c2:	vpdpbusd %ymm19,%ymm8,%ymm28
  4963c8:	vmovdqa32 %ymm10,%ymm26
  4963ce:	vmovdqa32 %ymm23,%ymm10
  4963d4:	vmovdqa32 %ymm20,%ymm23
  4963da:	vpdpbusd %ymm12,%ymm8,%ymm11
  4963e0:	vpdpbusd %ymm18,%ymm8,%ymm27
  4963e6:	vpdpbusd %ymm14,%ymm8,%ymm31
  4963ec:	vpxorq (%rsi,%rdi,1),%ymm1,%ymm8
  4963f3:	mov    0x150(%rsp),%rdi
  4963fb:	vpdpbusd %ymm12,%ymm8,%ymm10
  496401:	vpdpbusd %ymm19,%ymm8,%ymm23
  496407:	vmovdqa32 %ymm28,%ymm22
  49640d:	vmovdqa32 0xa0(%rsp),%ymm28
  496415:	vpdpbusd %ymm14,%ymm8,%ymm3
  49641b:	vpdpbusd %ymm18,%ymm8,%ymm28
  496421:	vpxorq (%rsi,%rdi,1),%ymm1,%ymm8
  496428:	mov    0x148(%rsp),%rdi
  496430:	vpdpbusd %ymm12,%ymm8,%ymm9
  496436:	vpxorq (%rsi,%rdi,1),%ymm1,%ymm20
  49643d:	vpdpbusd %ymm14,%ymm8,%ymm2
  496443:	vpdpbusd %ymm12,%ymm20,%ymm15
  496449:	vextracti32x4 $0x1,%ymm12,%xmm12
  496450:	vpdpbusd %ymm14,%ymm20,%ymm5
  496456:	vpmovsxbw %xmm12,%ymm14
  49645b:	vpdpwssd %ymm13,%ymm14,%ymm4
  496461:	vpdpbusd %ymm19,%ymm8,%ymm17
  496467:	vpdpbusd %ymm18,%ymm8,%ymm29
  49646d:	vpdpbusd %ymm19,%ymm20,%ymm7
  496473:	vpdpbusd %ymm18,%ymm20,%ymm6
  496479:	vextracti32x4 $0x1,%ymm4,%xmm13
  496480:	vpaddd %xmm4,%xmm13,%xmm12
  496484:	vpsrldq $0x8,%xmm12,%xmm13
  49648a:	vpaddd %xmm13,%xmm12,%xmm12
  49648f:	vpsrldq $0x4,%xmm12,%xmm13
  496495:	vpaddd %xmm13,%xmm12,%xmm12
  49649a:	vmovd  %xmm12,%r8d
  49649f:	vextracti32x4 $0x1,%ymm11,%xmm12
  4964a6:	vpaddd %xmm11,%xmm12,%xmm11
  4964ab:	vpsrldq $0x8,%xmm11,%xmm12
  4964b1:	vpaddd %xmm12,%xmm11,%xmm11
  4964b6:	vpsrldq $0x4,%xmm11,%xmm12
  4964bc:	vpaddd %xmm12,%xmm11,%xmm11
  4964c1:	vmovd  %xmm11,0x144(%rsp)
  4964ca:	vextracti32x4 $0x1,%ymm10,%xmm11
  4964d1:	vpaddd %xmm10,%xmm11,%xmm10
  4964d6:	vpsrldq $0x8,%xmm10,%xmm11
  4964dc:	vpaddd %xmm11,%xmm10,%xmm10
  4964e1:	vpsrldq $0x4,%xmm10,%xmm11
  4964e7:	vpaddd %xmm11,%xmm10,%xmm10
  4964ec:	vmovd  %xmm10,0x140(%rsp)
  4964f5:	vextracti32x4 $0x1,%ymm9,%xmm10
  4964fc:	vpaddd %xmm9,%xmm10,%xmm9
  496501:	vpsrldq $0x8,%xmm9,%xmm10
  496507:	vpaddd %xmm10,%xmm9,%xmm9
  49650c:	vpsrldq $0x4,%xmm9,%xmm10
  496512:	vpaddd %xmm10,%xmm9,%xmm9
  496517:	vmovd  %xmm9,0x13c(%rsp)
  496520:	vextracti32x4 $0x1,%ymm15,%xmm9
  496527:	vpaddd %xmm15,%xmm9,%xmm8
  49652c:	vpsrldq $0x8,%xmm8,%xmm9
  496532:	vpaddd %xmm9,%xmm8,%xmm8
  496537:	vpsrldq $0x4,%xmm8,%xmm9
  49653d:	vpaddd %xmm9,%xmm8,%xmm8
  496542:	vmovd  %xmm8,0x138(%rsp)
  49654b:	vextracti32x4 $0x1,%ymm21,%xmm8
  496552:	vpaddd %xmm21,%xmm8,%xmm21
  496558:	vpsrldq $0x8,%xmm21,%xmm8
  49655f:	vpaddd %xmm8,%xmm21,%xmm8
  496565:	vpsrldq $0x4,%xmm8,%xmm9
  49656b:	vpaddd %xmm9,%xmm8,%xmm8
  496570:	vmovd  %xmm8,0x114(%rsp)
  496579:	vextracti32x4 $0x1,%ymm22,%xmm8
  496580:	vpaddd %xmm22,%xmm8,%xmm22
  496586:	vpsrldq $0x8,%xmm22,%xmm8
  49658d:	vpaddd %xmm8,%xmm22,%xmm8
  496593:	vpsrldq $0x4,%xmm8,%xmm9
  496599:	vpaddd %xmm9,%xmm8,%xmm8
  49659e:	vmovd  %xmm8,0xfc(%rsp)
  4965a7:	vextracti32x4 $0x1,%ymm23,%xmm8
  4965ae:	vpaddd %xmm23,%xmm8,%xmm23
  4965b4:	vpsrldq $0x8,%xmm23,%xmm8
  4965bb:	vpaddd %xmm8,%xmm23,%xmm8
  4965c1:	vpsrldq $0x4,%xmm8,%xmm9
  4965c7:	vpaddd %xmm9,%xmm8,%xmm8
  4965cc:	vmovd  %xmm8,0x100(%rsp)
  4965d5:	vextracti32x4 $0x1,%ymm17,%xmm8
  4965dc:	vpaddd %xmm17,%xmm8,%xmm24
  4965e2:	vpsrldq $0x8,%xmm24,%xmm8
  4965e9:	vpaddd %xmm8,%xmm24,%xmm8
  4965ef:	vpsrldq $0x4,%xmm8,%xmm9
  4965f5:	vpaddd %xmm9,%xmm8,%xmm8
  4965fa:	vmovd  %xmm8,0x104(%rsp)
  496603:	vextracti32x4 $0x1,%ymm7,%xmm8
  49660a:	vpaddd %xmm7,%xmm8,%xmm25
  496610:	vpsrldq $0x8,%xmm25,%xmm8
  496617:	vpaddd %xmm8,%xmm25,%xmm8
  49661d:	vpsrldq $0x4,%xmm8,%xmm9
  496623:	vpaddd %xmm9,%xmm8,%xmm8
  496628:	vmovd  %xmm8,0x108(%rsp)
  496631:	vextracti32x4 $0x1,%ymm26,%xmm8
  496638:	vpaddd %xmm26,%xmm8,%xmm26
  49663e:	vpsrldq $0x8,%xmm26,%xmm8
  496645:	vpaddd %xmm8,%xmm26,%xmm8
  49664b:	vpsrldq $0x4,%xmm8,%xmm9
  496651:	vpaddd %xmm9,%xmm8,%xmm8
  496656:	vmovd  %xmm8,0x10c(%rsp)
  49665f:	vextracti32x4 $0x1,%ymm27,%xmm8
  496666:	vpaddd %xmm27,%xmm8,%xmm27
  49666c:	vpsrldq $0x8,%xmm27,%xmm8
  496673:	vpaddd %xmm8,%xmm27,%xmm8
  496679:	vpsrldq $0x4,%xmm8,%xmm9
  49667f:	vpaddd %xmm9,%xmm8,%xmm8
  496684:	vmovd  %xmm8,0x110(%rsp)
  49668d:	vextracti32x4 $0x1,%ymm28,%xmm8
  496694:	vpaddd %xmm28,%xmm8,%xmm28
  49669a:	vpsrldq $0x8,%xmm28,%xmm8
  4966a1:	vpaddd %xmm8,%xmm28,%xmm8
  4966a7:	vpsrldq $0x4,%xmm8,%xmm9
  4966ad:	vpaddd %xmm9,%xmm8,%xmm8
  4966b2:	vmovd  %xmm8,0x118(%rsp)
  4966bb:	vextracti32x4 $0x1,%ymm29,%xmm8
  4966c2:	vpaddd %xmm29,%xmm8,%xmm29
  4966c8:	vpsrldq $0x8,%xmm29,%xmm8
  4966cf:	vpaddd %xmm8,%xmm29,%xmm8
  4966d5:	vpsrldq $0x4,%xmm8,%xmm9
  4966db:	vpaddd %xmm9,%xmm8,%xmm8
  4966e0:	vmovd  %xmm8,0x11c(%rsp)
  4966e9:	vextracti32x4 $0x1,%ymm6,%xmm8
  4966f0:	vpaddd %xmm6,%xmm8,%xmm19
  4966f6:	vpsrldq $0x8,%xmm19,%xmm8
  4966fd:	vpaddd %xmm8,%xmm19,%xmm8
  496703:	vpsrldq $0x4,%xmm8,%xmm9
  496709:	vpaddd %xmm9,%xmm8,%xmm8
  49670e:	vmovd  %xmm8,0x120(%rsp)
  496717:	vextracti32x4 $0x1,%ymm30,%xmm8
  49671e:	vpaddd %xmm30,%xmm8,%xmm30
  496724:	vpsrldq $0x8,%xmm30,%xmm8
  49672b:	vpaddd %xmm8,%xmm30,%xmm8
  496731:	vpsrldq $0x4,%xmm8,%xmm9
  496737:	vpaddd %xmm9,%xmm8,%xmm8
  49673c:	vmovd  %xmm8,0x124(%rsp)
  496745:	vextracti32x4 $0x1,%ymm31,%xmm8
  49674c:	vpaddd %xmm31,%xmm8,%xmm31
  496752:	vpsrldq $0x8,%xmm31,%xmm8
  496759:	vpaddd %xmm8,%xmm31,%xmm8
  49675f:	vpsrldq $0x4,%xmm8,%xmm9
  496765:	vpaddd %xmm9,%xmm8,%xmm8
  49676a:	vextracti32x4 $0x1,%ymm3,%xmm9
  496771:	vmovd  %xmm8,0x128(%rsp)
  49677a:	vpaddd %xmm3,%xmm9,%xmm8
  49677e:	vpsrldq $0x8,%xmm8,%xmm9
  496784:	vpaddd %xmm9,%xmm8,%xmm8
  496789:	vpsrldq $0x4,%xmm8,%xmm9
  49678f:	vpaddd %xmm9,%xmm8,%xmm8
  496794:	vextracti32x4 $0x1,%ymm2,%xmm9
  49679b:	vmovd  %xmm8,0x12c(%rsp)
  4967a4:	vpaddd %xmm2,%xmm9,%xmm8
  4967a8:	vpsrldq $0x8,%xmm8,%xmm9
  4967ae:	vpaddd %xmm9,%xmm8,%xmm8
  4967b3:	vpsrldq $0x4,%xmm8,%xmm9
  4967b9:	vpaddd %xmm9,%xmm8,%xmm8
  4967be:	vmovd  %xmm8,0x130(%rsp)
  4967c7:	vextracti32x4 $0x1,%ymm5,%xmm8
  4967ce:	vpaddd %xmm5,%xmm8,%xmm18
  4967d4:	vpsrldq $0x8,%xmm18,%xmm8
  4967db:	vpaddd %xmm8,%xmm18,%xmm8
  4967e1:	vpsrldq $0x4,%xmm8,%xmm9
  4967e7:	vpaddd %xmm9,%xmm8,%xmm8
  4967ec:	vmovd  %xmm8,0x134(%rsp)
  4967f5:	test   $0x1f,%r12b
  4967f9:	je     496a2b <velri_slang_dot_linear_w8a8_f32+0x137b>
  4967ff:	mov    %r12d,%esi
  496802:	and    $0xffffffe0,%esi
  496805:	add    %esi,%r13d
  496808:	mov    %eax,0x18(%rbp)
  49680b:	mov    %r13d,%r12d
  49680e:	vmovq  %rbx,%xmm6
  496813:	vmovq  %r11,%xmm7
  496818:	lea    (%r14,%r12,1),%rdi
  49681c:	mov    %r15d,0x90(%rsp)
  496824:	add    0x80(%rsp),%r12
  49682c:	vmovq  %r10,%xmm5
  496831:	vmovq  %r9,%xmm3
  496836:	vmovq  %rcx,%xmm4
  49683b:	vmovq  %rdx,%xmm2
  496840:	mov    0xc0(%rsp),%rcx
  496848:	mov    %rdi,%rsi
  49684b:	sub    0x98(%rsp),%rsi
  496853:	mov    %r12,%r14
  496856:	sub    0x160(%rsp),%r14
  49685e:	mov    0xd0(%rsp),%rax
  496866:	movsbl (%rsi,%rcx,1),%r11d
  49686b:	mov    0x168(%rsp),%rcx
  496873:	mov    0xc8(%rsp),%rbx
  49687b:	movsbl (%rsi,%rax,1),%r15d
  496880:	movzbl (%r14,%rcx,1),%ecx
  496885:	mov    0x150(%rsp),%rdx
  49688d:	movsbl (%rsi,%rbx,1),%ebx
  496891:	movsbl (%rdi),%eax
  496894:	lea    -0x80(%rcx),%esi
  496897:	movzbl (%r12),%ecx
  49689c:	movzbl %sil,%r10d
  4968a0:	lea    -0x80(%rcx),%esi
  4968a3:	mov    0x158(%rsp),%rcx
  4968ab:	movzbl %sil,%r9d
  4968af:	movzbl (%r14,%rcx,1),%ecx
  4968b4:	lea    -0x80(%rcx),%esi
  4968b7:	movzbl %sil,%ecx
  4968bb:	movzbl (%r14,%rdx,1),%esi
  4968c0:	mov    %sil,0xa0(%rsp)
  4968c8:	add    $0xffffff80,%esi
  4968cb:	movzbl %sil,%edx
  4968cf:	mov    0x148(%rsp),%rsi
  4968d7:	movzbl (%r14,%rsi,1),%r14d
  4968dc:	add    $0xffffff80,%r14d
  4968e0:	movzbl %r14b,%esi
  4968e4:	mov    %r10d,%r14d
  4968e7:	imul   %r15d,%r14d
  4968eb:	add    %r14d,%r8d
  4968ee:	mov    %r9d,%r14d
  4968f1:	imul   %r15d,%r14d
  4968f5:	add    %r14d,0x144(%rsp)
  4968fd:	mov    %ecx,%r14d
  496900:	imul   %r15d,%r14d
  496904:	add    %r14d,0x140(%rsp)
  49690c:	mov    %edx,%r14d
  49690f:	imul   %r15d,%r14d
  496913:	add    %r14d,0x13c(%rsp)
  49691b:	mov    %r10d,%r14d
  49691e:	imul   %eax,%r14d
  496922:	add    %r14d,0x114(%rsp)
  49692a:	mov    %r9d,%r14d
  49692d:	imul   %eax,%r14d
  496931:	add    %r14d,0xfc(%rsp)
  496939:	mov    %ecx,%r14d
  49693c:	imul   %eax,%r14d
  496940:	imul   %esi,%r15d
  496944:	add    %r15d,0x138(%rsp)
  49694c:	add    %r14d,0x100(%rsp)
  496954:	mov    %edx,%r14d
  496957:	imul   %eax,%r14d
  49695b:	add    %r14d,0x104(%rsp)
  496963:	mov    %r10d,%r14d
  496966:	imul   %ebx,%r14d
  49696a:	add    %r14d,0x10c(%rsp)
  496972:	mov    %r9d,%r14d
  496975:	imul   %ebx,%r14d
  496979:	add    %r14d,0x110(%rsp)
  496981:	mov    %ecx,%r14d
  496984:	imul   %ebx,%r14d
  496988:	add    %r14d,0x118(%rsp)
  496990:	mov    %edx,%r14d
  496993:	imul   %esi,%eax
  496996:	add    %eax,0x108(%rsp)
  49699d:	imul   %ebx,%r14d
  4969a1:	add    %r14d,0x11c(%rsp)
  4969a9:	imul   %esi,%ebx
  4969ac:	add    $0x1,%r13d
  4969b0:	add    $0x1,%rdi
  4969b4:	add    $0x1,%r12
  4969b8:	imul   %r11d,%r10d
  4969bc:	add    %ebx,0x120(%rsp)
  4969c3:	imul   %r11d,%r9d
  4969c7:	add    %r10d,0x124(%rsp)
  4969cf:	imul   %r11d,%ecx
  4969d3:	add    %r9d,0x128(%rsp)
  4969db:	imul   %r11d,%edx
  4969df:	add    %ecx,0x12c(%rsp)
  4969e6:	imul   %r11d,%esi
  4969ea:	add    %edx,0x130(%rsp)
  4969f1:	add    %esi,0x134(%rsp)
  4969f8:	cmp    0x50(%rbp),%r13d
  4969fc:	jb     496840 <velri_slang_dot_linear_w8a8_f32+0x1190>
  496a02:	mov    0x18(%rbp),%eax
  496a05:	mov    0x90(%rsp),%r15d
  496a0d:	vmovq  %xmm6,%rbx
  496a12:	vmovq  %xmm7,%r11
  496a17:	vmovq  %xmm5,%r10
  496a1c:	vmovq  %xmm3,%r9
  496a21:	vmovq  %xmm4,%rcx
  496a26:	vmovq  %xmm2,%rdx
  496a2b:	mov    0x1d0(%rsp),%rdi
  496a33:	mov    0x1d8(%rsp),%rsi
  496a3b:	mov    (%rdi),%r12d
  496a3e:	imul   %rbx,%rsi
  496a42:	add    0x178(%rsp),%rsi
  496a4a:	shl    $0x2,%rsi
  496a4e:	sub    %r12d,%r8d
  496a51:	lea    (%rcx,%rsi,1),%r13
  496a55:	vcvtsi2ss %r8d,%xmm0,%xmm8
  496a5a:	test   $0x4,%al
  496a5c:	je     497298 <velri_slang_dot_linear_w8a8_f32+0x1be8>
  496a62:	mov    0x188(%rsp),%rdi
  496a6a:	vmovss (%rdi),%xmm9
  496a6e:	test   $0x2,%al
  496a70:	je     496a77 <velri_slang_dot_linear_w8a8_f32+0x13c7>
  496a72:	vmulss (%rdx,%rbx,4),%xmm9,%xmm9
  496a77:	vmulss %xmm9,%xmm8,%xmm8
  496a7c:	test   $0x1,%al
  496a7e:	je     496a8c <velri_slang_dot_linear_w8a8_f32+0x13dc>
  496a80:	mov    0x180(%rsp),%rdi
  496a88:	vaddss (%rdi),%xmm8,%xmm8
  496a8c:	mov    0x144(%rsp),%edi
  496a93:	vmovss %xmm8,0x0(%r13)
  496a99:	lea    0x4(%rcx,%rsi,1),%r8
  496a9e:	sub    %r12d,%edi
  496aa1:	vcvtsi2ss %edi,%xmm0,%xmm8
  496aa5:	test   $0x4,%al
  496aa7:	je     497288 <velri_slang_dot_linear_w8a8_f32+0x1bd8>
  496aad:	mov    0x198(%rsp),%rdi
  496ab5:	vmovss (%rdi),%xmm9
  496ab9:	test   $0x2,%al
  496abb:	je     496ac2 <velri_slang_dot_linear_w8a8_f32+0x1412>
  496abd:	vmulss (%rdx,%rbx,4),%xmm9,%xmm9
  496ac2:	vmulss %xmm9,%xmm8,%xmm8
  496ac7:	test   $0x1,%al
  496ac9:	je     496ad7 <velri_slang_dot_linear_w8a8_f32+0x1427>
  496acb:	mov    0x190(%rsp),%rdi
  496ad3:	vaddss (%rdi),%xmm8,%xmm8
  496ad7:	mov    0x140(%rsp),%edi
  496ade:	vmovss %xmm8,(%r8)
  496ae3:	lea    0x8(%rcx,%rsi,1),%r8
  496ae8:	sub    %r12d,%edi
  496aeb:	vcvtsi2ss %edi,%xmm0,%xmm8
  496aef:	test   $0x4,%al
  496af1:	je     497278 <velri_slang_dot_linear_w8a8_f32+0x1bc8>
  496af7:	mov    0x1a8(%rsp),%rdi
  496aff:	vmovss (%rdi),%xmm9
  496b03:	test   $0x2,%al
  496b05:	je     496b0c <velri_slang_dot_linear_w8a8_f32+0x145c>
  496b07:	vmulss (%rdx,%rbx,4),%xmm9,%xmm9
  496b0c:	vmulss %xmm9,%xmm8,%xmm8
  496b11:	test   $0x1,%al
  496b13:	je     496b21 <velri_slang_dot_linear_w8a8_f32+0x1471>
  496b15:	mov    0x1a0(%rsp),%rdi
  496b1d:	vaddss (%rdi),%xmm8,%xmm8
  496b21:	mov    0x13c(%rsp),%edi
  496b28:	vmovss %xmm8,(%r8)
  496b2d:	lea    0xc(%rcx,%rsi,1),%r8
  496b32:	sub    %r12d,%edi
  496b35:	vcvtsi2ss %edi,%xmm0,%xmm8
  496b39:	test   $0x4,%al
  496b3b:	je     497268 <velri_slang_dot_linear_w8a8_f32+0x1bb8>
  496b41:	mov    0x1b8(%rsp),%rdi
  496b49:	vmovss (%rdi),%xmm9
  496b4d:	test   $0x2,%al
  496b4f:	je     496b56 <velri_slang_dot_linear_w8a8_f32+0x14a6>
  496b51:	vmulss (%rdx,%rbx,4),%xmm9,%xmm9
  496b56:	vmulss %xmm9,%xmm8,%xmm8
  496b5b:	test   $0x1,%al
  496b5d:	je     496b6b <velri_slang_dot_linear_w8a8_f32+0x14bb>
  496b5f:	mov    0x1b0(%rsp),%rdi
  496b67:	vaddss (%rdi),%xmm8,%xmm8
  496b6b:	lea    0x10(%rcx,%rsi,1),%rdi
  496b70:	mov    0x138(%rsp),%esi
  496b77:	vmovss %xmm8,(%r8)
  496b7c:	sub    %r12d,%esi
  496b7f:	vcvtsi2ss %esi,%xmm0,%xmm8
  496b83:	test   $0x4,%al
  496b85:	je     497258 <velri_slang_dot_linear_w8a8_f32+0x1ba8>
  496b8b:	mov    0x1c8(%rsp),%rsi
  496b93:	vmovss (%rsi),%xmm9
  496b97:	test   $0x2,%al
  496b99:	je     496ba0 <velri_slang_dot_linear_w8a8_f32+0x14f0>
  496b9b:	vmulss (%rdx,%rbx,4),%xmm9,%xmm9
  496ba0:	vmulss %xmm9,%xmm8,%xmm8
  496ba5:	test   $0x1,%al
  496ba7:	je     496bb5 <velri_slang_dot_linear_w8a8_f32+0x1505>
  496ba9:	mov    0x1c0(%rsp),%rbx
  496bb1:	vaddss (%rbx),%xmm8,%xmm8
  496bb5:	vmovss %xmm8,(%rdi)
  496bb9:	mov    0x1d0(%rsp),%rdi
  496bc1:	mov    0x1d8(%rsp),%rsi
  496bc9:	mov    0x4(%rdi),%r8d
  496bcd:	mov    0x114(%rsp),%edi
  496bd4:	imul   %r11,%rsi
  496bd8:	add    0x178(%rsp),%rsi
  496be0:	shl    $0x2,%rsi
  496be4:	sub    %r8d,%edi
  496be7:	vcvtsi2ss %edi,%xmm0,%xmm8
  496beb:	lea    (%rcx,%rsi,1),%rbx
  496bef:	test   $0x4,%al
  496bf1:	je     497248 <velri_slang_dot_linear_w8a8_f32+0x1b98>
  496bf7:	mov    0x188(%rsp),%rdi
  496bff:	vmovss (%rdi),%xmm9
  496c03:	test   $0x2,%al
  496c05:	je     496c0d <velri_slang_dot_linear_w8a8_f32+0x155d>
  496c07:	vmulss (%rdx,%r11,4),%xmm9,%xmm9
  496c0d:	vmulss %xmm9,%xmm8,%xmm8
  496c12:	test   $0x1,%al
  496c14:	je     496c22 <velri_slang_dot_linear_w8a8_f32+0x1572>
  496c16:	mov    0x180(%rsp),%rdi
  496c1e:	vaddss (%rdi),%xmm8,%xmm8
  496c22:	mov    0xfc(%rsp),%edi
  496c29:	vmovss %xmm8,(%rbx)
  496c2d:	lea    0x4(%rcx,%rsi,1),%rbx
  496c32:	sub    %r8d,%edi
  496c35:	vcvtsi2ss %edi,%xmm0,%xmm8
  496c39:	test   $0x4,%al
  496c3b:	je     497238 <velri_slang_dot_linear_w8a8_f32+0x1b88>
  496c41:	mov    0x198(%rsp),%rdi
  496c49:	vmovss (%rdi),%xmm9
  496c4d:	test   $0x2,%al
  496c4f:	je     496c57 <velri_slang_dot_linear_w8a8_f32+0x15a7>
  496c51:	vmulss (%rdx,%r11,4),%xmm9,%xmm9
  496c57:	vmulss %xmm9,%xmm8,%xmm8
  496c5c:	test   $0x1,%al
  496c5e:	je     496c6c <velri_slang_dot_linear_w8a8_f32+0x15bc>
  496c60:	mov    0x190(%rsp),%rdi
  496c68:	vaddss (%rdi),%xmm8,%xmm8
  496c6c:	mov    0x100(%rsp),%edi
  496c73:	vmovss %xmm8,(%rbx)
  496c77:	lea    0x8(%rcx,%rsi,1),%rbx
  496c7c:	sub    %r8d,%edi
  496c7f:	vcvtsi2ss %edi,%xmm0,%xmm8
  496c83:	test   $0x4,%al
  496c85:	je     497228 <velri_slang_dot_linear_w8a8_f32+0x1b78>
  496c8b:	mov    0x1a8(%rsp),%rdi
  496c93:	vmovss (%rdi),%xmm9
  496c97:	test   $0x2,%al
  496c99:	je     496ca1 <velri_slang_dot_linear_w8a8_f32+0x15f1>
  496c9b:	vmulss (%rdx,%r11,4),%xmm9,%xmm9
  496ca1:	vmulss %xmm9,%xmm8,%xmm8
  496ca6:	test   $0x1,%al
  496ca8:	je     496cb6 <velri_slang_dot_linear_w8a8_f32+0x1606>
  496caa:	mov    0x1a0(%rsp),%rdi
  496cb2:	vaddss (%rdi),%xmm8,%xmm8
  496cb6:	mov    0x104(%rsp),%edi
  496cbd:	vmovss %xmm8,(%rbx)
  496cc1:	lea    0xc(%rcx,%rsi,1),%rbx
  496cc6:	sub    %r8d,%edi
  496cc9:	vcvtsi2ss %edi,%xmm0,%xmm8
  496ccd:	test   $0x4,%al
  496ccf:	je     497218 <velri_slang_dot_linear_w8a8_f32+0x1b68>
  496cd5:	mov    0x1b8(%rsp),%rdi
  496cdd:	vmovss (%rdi),%xmm9
  496ce1:	test   $0x2,%al
  496ce3:	je     496ceb <velri_slang_dot_linear_w8a8_f32+0x163b>
  496ce5:	vmulss (%rdx,%r11,4),%xmm9,%xmm9
  496ceb:	vmulss %xmm9,%xmm8,%xmm8
  496cf0:	test   $0x1,%al
  496cf2:	je     496d00 <velri_slang_dot_linear_w8a8_f32+0x1650>
  496cf4:	mov    0x1b0(%rsp),%rdi
  496cfc:	vaddss (%rdi),%xmm8,%xmm8
  496d00:	lea    0x10(%rcx,%rsi,1),%rdi
  496d05:	mov    0x108(%rsp),%esi
  496d0c:	vmovss %xmm8,(%rbx)
  496d10:	sub    %r8d,%esi
  496d13:	vcvtsi2ss %esi,%xmm0,%xmm8
  496d17:	test   $0x4,%al
  496d19:	je     497208 <velri_slang_dot_linear_w8a8_f32+0x1b58>
  496d1f:	mov    0x1c8(%rsp),%rbx
  496d27:	vmovss (%rbx),%xmm10
  496d2b:	test   $0x2,%al
  496d2d:	je     496d35 <velri_slang_dot_linear_w8a8_f32+0x1685>
  496d2f:	vmulss (%rdx,%r11,4),%xmm10,%xmm10
  496d35:	vmulss %xmm10,%xmm8,%xmm8
  496d3a:	test   $0x1,%al
  496d3c:	je     496d4a <velri_slang_dot_linear_w8a8_f32+0x169a>
  496d3e:	mov    0x1c0(%rsp),%rbx
  496d46:	vaddss (%rbx),%xmm8,%xmm8
  496d4a:	mov    0x1d0(%rsp),%rbx
  496d52:	mov    0x1d8(%rsp),%rsi
  496d5a:	vmovss %xmm8,(%rdi)
  496d5e:	mov    0x10c(%rsp),%edi
  496d65:	mov    0x8(%rbx),%r8d
  496d69:	imul   %r10,%rsi
  496d6d:	add    0x178(%rsp),%rsi
  496d75:	shl    $0x2,%rsi
  496d79:	sub    %r8d,%edi
  496d7c:	lea    (%rcx,%rsi,1),%r11
  496d80:	vcvtsi2ss %edi,%xmm0,%xmm8
  496d84:	test   $0x4,%al
  496d86:	je     4971f8 <velri_slang_dot_linear_w8a8_f32+0x1b48>
  496d8c:	mov    0x188(%rsp),%rbx
  496d94:	vmovss (%rbx),%xmm9
  496d98:	test   $0x2,%al
  496d9a:	je     496da2 <velri_slang_dot_linear_w8a8_f32+0x16f2>
  496d9c:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  496da2:	vmulss %xmm9,%xmm8,%xmm8
  496da7:	test   $0x1,%al
  496da9:	je     496db7 <velri_slang_dot_linear_w8a8_f32+0x1707>
  496dab:	mov    0x180(%rsp),%rbx
  496db3:	vaddss (%rbx),%xmm8,%xmm8
  496db7:	mov    0x110(%rsp),%edi
  496dbe:	vmovss %xmm8,(%r11)
  496dc3:	lea    0x4(%rcx,%rsi,1),%r11
  496dc8:	sub    %r8d,%edi
  496dcb:	vcvtsi2ss %edi,%xmm0,%xmm8
  496dcf:	test   $0x4,%al
  496dd1:	je     4971e8 <velri_slang_dot_linear_w8a8_f32+0x1b38>
  496dd7:	mov    0x198(%rsp),%rbx
  496ddf:	vmovss (%rbx),%xmm9
  496de3:	test   $0x2,%al
  496de5:	je     496ded <velri_slang_dot_linear_w8a8_f32+0x173d>
  496de7:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  496ded:	vmulss %xmm9,%xmm8,%xmm8
  496df2:	test   $0x1,%al
  496df4:	je     496e02 <velri_slang_dot_linear_w8a8_f32+0x1752>
  496df6:	mov    0x190(%rsp),%rbx
  496dfe:	vaddss (%rbx),%xmm8,%xmm8
  496e02:	mov    0x118(%rsp),%edi
  496e09:	vmovss %xmm8,(%r11)
  496e0e:	lea    0x8(%rcx,%rsi,1),%r11
  496e13:	sub    %r8d,%edi
  496e16:	vcvtsi2ss %edi,%xmm0,%xmm8
  496e1a:	test   $0x4,%al
  496e1c:	je     4971d8 <velri_slang_dot_linear_w8a8_f32+0x1b28>
  496e22:	mov    0x1a8(%rsp),%rbx
  496e2a:	vmovss (%rbx),%xmm9
  496e2e:	test   $0x2,%al
  496e30:	je     496e38 <velri_slang_dot_linear_w8a8_f32+0x1788>
  496e32:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  496e38:	vmulss %xmm9,%xmm8,%xmm8
  496e3d:	test   $0x1,%al
  496e3f:	je     496e4d <velri_slang_dot_linear_w8a8_f32+0x179d>
  496e41:	mov    0x1a0(%rsp),%rbx
  496e49:	vaddss (%rbx),%xmm8,%xmm8
  496e4d:	mov    0x11c(%rsp),%edi
  496e54:	vmovss %xmm8,(%r11)
  496e59:	lea    0xc(%rcx,%rsi,1),%r11
  496e5e:	sub    %r8d,%edi
  496e61:	vcvtsi2ss %edi,%xmm0,%xmm8
  496e65:	test   $0x4,%al
  496e67:	je     4971c8 <velri_slang_dot_linear_w8a8_f32+0x1b18>
  496e6d:	mov    0x1b8(%rsp),%rbx
  496e75:	vmovss (%rbx),%xmm9
  496e79:	test   $0x2,%al
  496e7b:	je     496e83 <velri_slang_dot_linear_w8a8_f32+0x17d3>
  496e7d:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  496e83:	vmulss %xmm9,%xmm8,%xmm8
  496e88:	test   $0x1,%al
  496e8a:	je     496e98 <velri_slang_dot_linear_w8a8_f32+0x17e8>
  496e8c:	mov    0x1b0(%rsp),%rbx
  496e94:	vaddss (%rbx),%xmm8,%xmm8
  496e98:	lea    0x10(%rcx,%rsi,1),%rdi
  496e9d:	mov    0x120(%rsp),%esi
  496ea4:	vmovss %xmm8,(%r11)
  496ea9:	sub    %r8d,%esi
  496eac:	vcvtsi2ss %esi,%xmm0,%xmm8
  496eb0:	test   $0x4,%al
  496eb2:	je     4971b8 <velri_slang_dot_linear_w8a8_f32+0x1b08>
  496eb8:	mov    0x1c8(%rsp),%rbx
  496ec0:	vmovss (%rbx),%xmm9
  496ec4:	test   $0x2,%al
  496ec6:	je     496ece <velri_slang_dot_linear_w8a8_f32+0x181e>
  496ec8:	vmulss (%rdx,%r10,4),%xmm9,%xmm9
  496ece:	vmulss %xmm9,%xmm8,%xmm8
  496ed3:	test   $0x1,%al
  496ed5:	je     496ee3 <velri_slang_dot_linear_w8a8_f32+0x1833>
  496ed7:	mov    0x1c0(%rsp),%rbx
  496edf:	vaddss (%rbx),%xmm8,%xmm8
  496ee3:	mov    0x1d0(%rsp),%rbx
  496eeb:	mov    0x1d8(%rsp),%rsi
  496ef3:	vmovss %xmm8,(%rdi)
  496ef7:	mov    0x124(%rsp),%edi
  496efe:	mov    0xc(%rbx),%r8d
  496f02:	imul   %r9,%rsi
  496f06:	add    0x178(%rsp),%rsi
  496f0e:	shl    $0x2,%rsi
  496f12:	sub    %r8d,%edi
  496f15:	lea    (%rcx,%rsi,1),%r10
  496f19:	vcvtsi2ss %edi,%xmm0,%xmm8
  496f1d:	test   $0x4,%al
  496f1f:	je     4971a8 <velri_slang_dot_linear_w8a8_f32+0x1af8>
  496f25:	mov    0x188(%rsp),%rbx
  496f2d:	vmovss (%rbx),%xmm9
  496f31:	test   $0x2,%al
  496f33:	je     496f3b <velri_slang_dot_linear_w8a8_f32+0x188b>
  496f35:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  496f3b:	vmulss %xmm9,%xmm8,%xmm8
  496f40:	test   $0x1,%al
  496f42:	je     496f50 <velri_slang_dot_linear_w8a8_f32+0x18a0>
  496f44:	mov    0x180(%rsp),%rbx
  496f4c:	vaddss (%rbx),%xmm8,%xmm8
  496f50:	mov    0x128(%rsp),%edi
  496f57:	vmovss %xmm8,(%r10)
  496f5c:	lea    0x4(%rcx,%rsi,1),%r10
  496f61:	sub    %r8d,%edi
  496f64:	vcvtsi2ss %edi,%xmm0,%xmm8
  496f68:	test   $0x4,%al
  496f6a:	je     497198 <velri_slang_dot_linear_w8a8_f32+0x1ae8>
  496f70:	mov    0x198(%rsp),%rbx
  496f78:	vmovss (%rbx),%xmm9
  496f7c:	test   $0x2,%al
  496f7e:	je     496f86 <velri_slang_dot_linear_w8a8_f32+0x18d6>
  496f80:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  496f86:	vmulss %xmm9,%xmm8,%xmm8
  496f8b:	test   $0x1,%al
  496f8d:	je     496f9b <velri_slang_dot_linear_w8a8_f32+0x18eb>
  496f8f:	mov    0x190(%rsp),%rbx
  496f97:	vaddss (%rbx),%xmm8,%xmm8
  496f9b:	mov    0x12c(%rsp),%edi
  496fa2:	vmovss %xmm8,(%r10)
  496fa7:	lea    0x8(%rcx,%rsi,1),%r10
  496fac:	sub    %r8d,%edi
  496faf:	vcvtsi2ss %edi,%xmm0,%xmm8
  496fb3:	test   $0x4,%al
  496fb5:	je     497188 <velri_slang_dot_linear_w8a8_f32+0x1ad8>
  496fbb:	mov    0x1a8(%rsp),%rbx
  496fc3:	vmovss (%rbx),%xmm9
  496fc7:	test   $0x2,%al
  496fc9:	je     496fd1 <velri_slang_dot_linear_w8a8_f32+0x1921>
  496fcb:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  496fd1:	vmulss %xmm9,%xmm8,%xmm8
  496fd6:	test   $0x1,%al
  496fd8:	je     496fe6 <velri_slang_dot_linear_w8a8_f32+0x1936>
  496fda:	mov    0x1a0(%rsp),%rbx
  496fe2:	vaddss (%rbx),%xmm8,%xmm8
  496fe6:	mov    0x130(%rsp),%edi
  496fed:	vmovss %xmm8,(%r10)
  496ff2:	lea    0xc(%rcx,%rsi,1),%r10
  496ff7:	sub    %r8d,%edi
  496ffa:	vcvtsi2ss %edi,%xmm0,%xmm8
  496ffe:	test   $0x4,%al
  497000:	je     497178 <velri_slang_dot_linear_w8a8_f32+0x1ac8>
  497006:	mov    0x1b8(%rsp),%rbx
  49700e:	vmovss (%rbx),%xmm9
  497012:	test   $0x2,%al
  497014:	je     49701c <velri_slang_dot_linear_w8a8_f32+0x196c>
  497016:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  49701c:	vmulss %xmm9,%xmm8,%xmm8
  497021:	test   $0x1,%al
  497023:	je     497031 <velri_slang_dot_linear_w8a8_f32+0x1981>
  497025:	mov    0x1b0(%rsp),%rbx
  49702d:	vaddss (%rbx),%xmm8,%xmm8
  497031:	lea    0x10(%rcx,%rsi,1),%rdi
  497036:	mov    0x134(%rsp),%esi
  49703d:	vmovss %xmm8,(%r10)
  497042:	sub    %r8d,%esi
  497045:	vcvtsi2ss %esi,%xmm0,%xmm8
  497049:	test   $0x4,%al
  49704b:	je     497168 <velri_slang_dot_linear_w8a8_f32+0x1ab8>
  497051:	mov    0x1c8(%rsp),%rbx
  497059:	vmovss (%rbx),%xmm9
  49705d:	test   $0x2,%al
  49705f:	je     497067 <velri_slang_dot_linear_w8a8_f32+0x19b7>
  497061:	vmulss (%rdx,%r9,4),%xmm9,%xmm9
  497067:	vmulss %xmm9,%xmm8,%xmm8
  49706c:	test   $0x1,%al
  49706e:	je     4972a8 <velri_slang_dot_linear_w8a8_f32+0x1bf8>
  497074:	mov    0x1c0(%rsp),%rbx
  49707c:	add    $0x4,%r15d
  497080:	vaddss (%rbx),%xmm8,%xmm8
  497084:	vmovss %xmm8,(%rdi)
  497088:	cmp    0xe0(%rsp),%r15d
  497090:	je     4972be <velri_slang_dot_linear_w8a8_f32+0x1c0e>
  497096:	addq   $0x10,0x1d0(%rsp)
  49709f:	jmp    495ba0 <velri_slang_dot_linear_w8a8_f32+0x4f0>
  4970a4:	nopl   0x0(%rax)
  4970a8:	add    $0x1,%rsi
  4970ac:	vmovss %xmm2,(%rdx)
  4970b0:	cmp    %ebx,%esi
  4970b2:	jb     4980f0 <velri_slang_dot_linear_w8a8_f32+0x2a40>
  4970b8:	mov    0x40(%rsp),%rsi
  4970bd:	add    $0x4,%r12
  4970c1:	add    $0x4,%r13
  4970c5:	addq   $0x1,0x1d0(%rsp)
  4970ce:	add    %rsi,0x1b8(%rsp)
  4970d6:	mov    0x1d0(%rsp),%rcx
  4970de:	cmp    0x48(%rbp),%ecx
  4970e1:	jb     497a50 <velri_slang_dot_linear_w8a8_f32+0x23a0>
  4970e7:	mov    0x190(%rsp),%edi
  4970ee:	mov    0x30(%rbp),%ebx
  4970f1:	mov    0x40(%rbp),%r8d
  4970f5:	cmp    0x38(%rbp),%ebx
  4970f8:	jb     49579e <velri_slang_dot_linear_w8a8_f32+0xee>
  4970fe:	vzeroupper
  497101:	mov    0x2f8(%rsp),%rax
  497109:	sub    %fs:0x28,%rax
  497112:	jne    498630 <velri_slang_dot_linear_w8a8_f32+0x2f80>
  497118:	lea    -0x28(%rbp),%rsp
  49711c:	pop    %rbx
  49711d:	pop    %r12
  49711f:	pop    %r13
  497121:	pop    %r14
  497123:	pop    %r15
  497125:	pop    %rbp
  497126:	ret
  497127:	lea    0x1(%rcx),%eax
  49712a:	movl   $0x0,(%rdx)
  497130:	cmp    %ebx,%eax
  497132:	je     495991 <velri_slang_dot_linear_w8a8_f32+0x2e1>
  497138:	add    $0x2,%ecx
  49713b:	movl   $0x0,0x4(%rdx)
  497142:	add    $0x8,%rdx
  497146:	cmp    %ebx,%ecx
  497148:	jne    497127 <velri_slang_dot_linear_w8a8_f32+0x1a77>
  49714a:	cmp    $0x4,%edi
  49714d:	ja     49599a <velri_slang_dot_linear_w8a8_f32+0x2ea>
  497153:	mov    0xe4(%rsp),%eax
  49715a:	mov    %r8d,%r11d
  49715d:	lea    -0x4(%rax),%edx
  497160:	jmp    4979b6 <velri_slang_dot_linear_w8a8_f32+0x2306>
  497165:	nopl   (%rax)
  497168:	vmovss 0x6e9c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497170:	jmp    49705d <velri_slang_dot_linear_w8a8_f32+0x19ad>
  497175:	nopl   (%rax)
  497178:	vmovss 0x6e8c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497180:	jmp    497012 <velri_slang_dot_linear_w8a8_f32+0x1962>
  497185:	nopl   (%rax)
  497188:	vmovss 0x6e7c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497190:	jmp    496fc7 <velri_slang_dot_linear_w8a8_f32+0x1917>
  497195:	nopl   (%rax)
  497198:	vmovss 0x6e6c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971a0:	jmp    496f7c <velri_slang_dot_linear_w8a8_f32+0x18cc>
  4971a5:	nopl   (%rax)
  4971a8:	vmovss 0x6e5c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971b0:	jmp    496f31 <velri_slang_dot_linear_w8a8_f32+0x1881>
  4971b5:	nopl   (%rax)
  4971b8:	vmovss 0x6e4c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971c0:	jmp    496ec4 <velri_slang_dot_linear_w8a8_f32+0x1814>
  4971c5:	nopl   (%rax)
  4971c8:	vmovss 0x6e3c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971d0:	jmp    496e79 <velri_slang_dot_linear_w8a8_f32+0x17c9>
  4971d5:	nopl   (%rax)
  4971d8:	vmovss 0x6e2c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971e0:	jmp    496e2e <velri_slang_dot_linear_w8a8_f32+0x177e>
  4971e5:	nopl   (%rax)
  4971e8:	vmovss 0x6e1c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4971f0:	jmp    496de3 <velri_slang_dot_linear_w8a8_f32+0x1733>
  4971f5:	nopl   (%rax)
  4971f8:	vmovss 0x6e0c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497200:	jmp    496d98 <velri_slang_dot_linear_w8a8_f32+0x16e8>
  497205:	nopl   (%rax)
  497208:	vmovss 0x6dfc(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  497210:	jmp    496d2b <velri_slang_dot_linear_w8a8_f32+0x167b>
  497215:	nopl   (%rax)
  497218:	vmovss 0x6dec(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497220:	jmp    496ce1 <velri_slang_dot_linear_w8a8_f32+0x1631>
  497225:	nopl   (%rax)
  497228:	vmovss 0x6ddc(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497230:	jmp    496c97 <velri_slang_dot_linear_w8a8_f32+0x15e7>
  497235:	nopl   (%rax)
  497238:	vmovss 0x6dcc(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497240:	jmp    496c4d <velri_slang_dot_linear_w8a8_f32+0x159d>
  497245:	nopl   (%rax)
  497248:	vmovss 0x6dbc(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497250:	jmp    496c03 <velri_slang_dot_linear_w8a8_f32+0x1553>
  497255:	nopl   (%rax)
  497258:	vmovss 0x6dac(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497260:	jmp    496b97 <velri_slang_dot_linear_w8a8_f32+0x14e7>
  497265:	nopl   (%rax)
  497268:	vmovss 0x6d9c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497270:	jmp    496b4d <velri_slang_dot_linear_w8a8_f32+0x149d>
  497275:	nopl   (%rax)
  497278:	vmovss 0x6d8c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497280:	jmp    496b03 <velri_slang_dot_linear_w8a8_f32+0x1453>
  497285:	nopl   (%rax)
  497288:	vmovss 0x6d7c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  497290:	jmp    496ab9 <velri_slang_dot_linear_w8a8_f32+0x1409>
  497295:	nopl   (%rax)
  497298:	vmovss 0x6d6c(%rip),%xmm9        # 49e00c <_IO_stdin_used+0xc>
  4972a0:	jmp    496a6e <velri_slang_dot_linear_w8a8_f32+0x13be>
  4972a5:	nopl   (%rax)
  4972a8:	vmovss %xmm8,(%rdi)
  4972ac:	add    $0x4,%r15d
  4972b0:	cmp    0xe0(%rsp),%r15d
  4972b8:	jne    497096 <velri_slang_dot_linear_w8a8_f32+0x19e6>
  4972be:	mov    0x70(%rsp),%rbx
  4972c3:	mov    0x68(%rsp),%r10
  4972c8:	mov    0xe4(%rsp),%ecx
  4972cf:	cmp    %ecx,0x34(%rsp)
  4972d3:	jae    497976 <velri_slang_dot_linear_w8a8_f32+0x22c6>
  4972d9:	mov    0xf0(%rsp),%rax
  4972e1:	mov    0x160(%rsp),%rdx
  4972e9:	mov    0x30(%rsp),%r9d
  4972ee:	lea    (%rax,%rdx,1),%rcx
  4972f2:	mov    0x148(%rsp),%rdx
  4972fa:	vmovq  %rcx,%xmm2
  4972ff:	lea    (%rax,%rdx,1),%rcx
  497303:	mov    0x150(%rsp),%rdx
  49730b:	vmovq  %rcx,%xmm6
  497310:	lea    (%rax,%rdx,1),%rcx
  497314:	mov    0x158(%rsp),%rdx
  49731c:	vmovq  %rcx,%xmm5
  497321:	lea    (%rax,%rdx,1),%rcx
  497325:	add    0x168(%rsp),%rax
  49732d:	vmovq  %rax,%xmm3
  497332:	mov    0x18(%rbp),%eax
  497335:	vmovq  %rcx,%xmm4
  49733a:	nopw   0x0(%rax,%rax,1)
  497340:	mov    0x94(%rsp),%esi
  497347:	mov    0x50(%rbp),%edx
  49734a:	lea    (%rsi,%r9,1),%r8d
  49734e:	test   %edx,%edx
  497350:	je     498090 <velri_slang_dot_linear_w8a8_f32+0x29e0>
  497356:	mov    0xe8(%rsp),%rdx
  49735e:	imul   %r8,%rdx
  497362:	cmpl   $0x3e,0xf8(%rsp)
  49736a:	jbe    498421 <velri_slang_dot_linear_w8a8_f32+0x2d71>
  497370:	mov    0x170(%rsp),%rcx
  497378:	vpxor  %xmm13,%xmm13,%xmm13
  49737d:	vmovq  %xmm2,%rsi
  497382:	vmovq  %xmm6,%rdi
  497387:	vmovdqa32 %zmm13,%zmm12
  49738d:	vmovdqa32 %zmm13,%zmm11
  497393:	vmovdqa32 %zmm13,%zmm10
  497399:	lea    (%rcx,%rdx,1),%r15
  49739d:	mov    $0x80808080,%ecx
  4973a2:	xor    %edx,%edx
  4973a4:	vmovdqa32 %zmm13,%zmm9
  4973aa:	vpbroadcastd %ecx,%zmm14
  4973b0:	vmovq  %xmm5,%r11
  4973b5:	vmovq  %xmm4,%r14
  4973ba:	vmovq  %xmm3,%r13
  4973bf:	nop
  4973c0:	vmovdqu8 (%r15,%rdx,1),%zmm19
  4973c7:	vpxorq 0x0(%r13,%rdx,1),%zmm14,%zmm24
  4973cf:	vpdpbusd %zmm19,%zmm24,%zmm13
  4973d5:	vpxorq (%rsi,%rdx,1),%zmm14,%zmm24
  4973dc:	vpdpbusd %zmm19,%zmm24,%zmm12
  4973e2:	vpxorq (%r14,%rdx,1),%zmm14,%zmm24
  4973e9:	vpdpbusd %zmm19,%zmm24,%zmm11
  4973ef:	vpxorq (%r11,%rdx,1),%zmm14,%zmm24
  4973f6:	vpdpbusd %zmm19,%zmm24,%zmm10
  4973fc:	vpxorq (%rdi,%rdx,1),%zmm14,%zmm24
  497403:	add    $0x40,%rdx
  497407:	vpdpbusd %zmm19,%zmm24,%zmm9
  49740d:	cmp    0x78(%rsp),%rdx
  497412:	jne    4973c0 <velri_slang_dot_linear_w8a8_f32+0x1d10>
  497414:	vextracti32x8 $0x1,%zmm13,%ymm14
  49741b:	vmovq  %r13,%xmm3
  497420:	vmovq  %r11,%xmm5
  497425:	vpaddd %ymm13,%ymm14,%ymm13
  49742a:	vmovq  %rdi,%xmm6
  49742f:	vmovq  %rsi,%xmm2
  497434:	vextracti32x4 $0x1,%ymm13,%xmm14
  49743b:	vmovq  %r14,%xmm4
  497440:	vpaddd %xmm13,%xmm14,%xmm19
  497446:	vpsrldq $0x8,%xmm19,%xmm14
  49744d:	vpaddd %xmm14,%xmm19,%xmm14
  497453:	vpsrldq $0x4,%xmm14,%xmm19
  49745a:	vpaddd %xmm19,%xmm14,%xmm14
  497460:	vmovd  %xmm14,%r13d
  497465:	vextracti32x8 $0x1,%zmm12,%ymm14
  49746c:	vpaddd %ymm12,%ymm14,%ymm12
  497471:	vextracti32x4 $0x1,%ymm12,%xmm14
  497478:	vpaddd %xmm12,%xmm14,%xmm19
  49747e:	vpsrldq $0x8,%xmm19,%xmm14
  497485:	vpaddd %xmm14,%xmm19,%xmm14
  49748b:	vpsrldq $0x4,%xmm14,%xmm19
  497492:	vpaddd %xmm19,%xmm14,%xmm14
  497498:	vmovd  %xmm14,%r11d
  49749d:	vextracti32x8 $0x1,%zmm11,%ymm14
  4974a4:	vpaddd %ymm11,%ymm14,%ymm11
  4974a9:	vextracti32x4 $0x1,%ymm11,%xmm14
  4974b0:	vpaddd %xmm11,%xmm14,%xmm19
  4974b6:	vpsrldq $0x8,%xmm19,%xmm14
  4974bd:	vpaddd %xmm14,%xmm19,%xmm14
  4974c3:	vpsrldq $0x4,%xmm14,%xmm19
  4974ca:	vpaddd %xmm19,%xmm14,%xmm14
  4974d0:	vmovd  %xmm14,%edi
  4974d4:	vextracti32x8 $0x1,%zmm10,%ymm14
  4974db:	vpaddd %ymm10,%ymm14,%ymm10
  4974e0:	vextracti32x4 $0x1,%ymm10,%xmm14
  4974e7:	vpaddd %xmm10,%xmm14,%xmm19
  4974ed:	vpsrldq $0x8,%xmm19,%xmm14
  4974f4:	vpaddd %xmm14,%xmm19,%xmm14
  4974fa:	vpsrldq $0x4,%xmm14,%xmm19
  497501:	vpaddd %xmm19,%xmm14,%xmm14
  497507:	vmovd  %xmm14,%esi
  49750b:	vextracti32x8 $0x1,%zmm9,%ymm14
  497512:	vpaddd %ymm9,%ymm14,%ymm9
  497517:	vextracti32x4 $0x1,%ymm9,%xmm14
  49751e:	vpaddd %xmm9,%xmm14,%xmm19
  497524:	vpsrldq $0x8,%xmm19,%xmm14
  49752b:	vpaddd %xmm14,%xmm19,%xmm14
  497531:	vpsrldq $0x4,%xmm14,%xmm19
  497538:	vpaddd %xmm19,%xmm14,%xmm14
  49753e:	vmovd  %xmm14,%ecx
  497542:	testb  $0x3f,0x50(%rbp)
  497546:	je     497794 <velri_slang_dot_linear_w8a8_f32+0x20e4>
  49754c:	mov    0x50(%rbp),%r12d
  497550:	and    $0xffffffc0,%r12d
  497554:	mov    0x50(%rbp),%edx
  497557:	sub    %r12d,%edx
  49755a:	lea    -0x1(%rdx),%r14d
  49755e:	cmp    $0x1e,%r14d
  497562:	jbe    4976b2 <velri_slang_dot_linear_w8a8_f32+0x2002>
  497568:	mov    0x160(%rsp),%rsi
  497570:	mov    %r12d,%ecx
  497573:	vmovdqu8 (%r15,%rcx,1),%ymm14
  49757a:	add    0xf0(%rsp),%rcx
  497582:	vpxorq (%rcx,%rsi,1),%ymm1,%ymm19
  497589:	mov    0x158(%rsp),%rsi
  497591:	vpdpbusd %ymm14,%ymm19,%ymm12
  497597:	vpxorq (%rcx,%rsi,1),%ymm1,%ymm19
  49759e:	mov    0x150(%rsp),%rsi
  4975a6:	vpdpbusd %ymm14,%ymm19,%ymm11
  4975ac:	vpxorq (%rcx,%rsi,1),%ymm1,%ymm19
  4975b3:	mov    0x148(%rsp),%rsi
  4975bb:	vpdpbusd %ymm14,%ymm19,%ymm10
  4975c1:	vpxorq (%rcx,%rsi,1),%ymm1,%ymm19
  4975c8:	mov    0x168(%rsp),%rsi
  4975d0:	vpdpbusd %ymm14,%ymm19,%ymm9
  4975d6:	vpxorq (%rcx,%rsi,1),%ymm1,%ymm19
  4975dd:	vpdpbusd %ymm14,%ymm19,%ymm13
  4975e3:	vextracti32x4 $0x1,%ymm13,%xmm14
  4975ea:	vpaddd %xmm13,%xmm14,%xmm13
  4975ef:	vpsrldq $0x8,%xmm13,%xmm14
  4975f5:	vpaddd %xmm14,%xmm13,%xmm13
  4975fa:	vpsrldq $0x4,%xmm13,%xmm14
  497600:	vpaddd %xmm14,%xmm13,%xmm13
  497605:	vmovd  %xmm13,%r13d
  49760a:	vextracti32x4 $0x1,%ymm12,%xmm13
  497611:	vpaddd %xmm12,%xmm13,%xmm12
  497616:	vpsrldq $0x8,%xmm12,%xmm13
  49761c:	vpaddd %xmm13,%xmm12,%xmm12
  497621:	vpsrldq $0x4,%xmm12,%xmm13
  497627:	vpaddd %xmm13,%xmm12,%xmm12
  49762c:	vmovd  %xmm12,%r11d
  497631:	vextracti32x4 $0x1,%ymm11,%xmm12
  497638:	vpaddd %xmm11,%xmm12,%xmm11
  49763d:	vpsrldq $0x8,%xmm11,%xmm12
  497643:	vpaddd %xmm12,%xmm11,%xmm11
  497648:	vpsrldq $0x4,%xmm11,%xmm12
  49764e:	vpaddd %xmm12,%xmm11,%xmm11
  497653:	vmovd  %xmm11,%edi
  497657:	vextracti32x4 $0x1,%ymm10,%xmm11
  49765e:	vpaddd %xmm10,%xmm11,%xmm10
  497663:	vpsrldq $0x8,%xmm10,%xmm11
  497669:	vpaddd %xmm11,%xmm10,%xmm10
  49766e:	vpsrldq $0x4,%xmm10,%xmm11
  497674:	vpaddd %xmm11,%xmm10,%xmm10
  497679:	vmovd  %xmm10,%esi
  49767d:	vextracti32x4 $0x1,%ymm9,%xmm10
  497684:	vpaddd %xmm9,%xmm10,%xmm9
  497689:	vpsrldq $0x8,%xmm9,%xmm10
  49768f:	vpaddd %xmm10,%xmm9,%xmm9
  497694:	vpsrldq $0x4,%xmm9,%xmm10
  49769a:	vpaddd %xmm10,%xmm9,%xmm9
  49769f:	vmovd  %xmm9,%ecx
  4976a3:	test   $0x1f,%dl
  4976a6:	je     497794 <velri_slang_dot_linear_w8a8_f32+0x20e4>
  4976ac:	and    $0xffffffe0,%edx
  4976af:	add    %edx,%r12d
  4976b2:	mov    %r12d,%r14d
  4976b5:	mov    %eax,0x18(%rbp)
  4976b8:	vmovq  %r8,%xmm7
  4976bd:	mov    %r12d,%eax
  4976c0:	lea    (%r15,%r14,1),%rdx
  4976c4:	vmovq  %xmm2,%r15
  4976c9:	add    %r15,%r14
  4976cc:	mov    %r9,%r15
  4976cf:	mov    %edi,%r9d
  4976d2:	mov    %esi,%edi
  4976d4:	mov    %ecx,%esi
  4976d6:	mov    %rdx,%rcx
  4976d9:	nopl   0x0(%rax)
  4976e0:	mov    %r14,%r12
  4976e3:	movsbl (%rcx),%r8d
  4976e7:	add    $0x1,%eax
  4976ea:	add    $0x1,%rcx
  4976ee:	mov    0x168(%rsp),%rdx
  4976f6:	sub    0x160(%rsp),%r12
  4976fe:	add    $0x1,%r14
  497702:	movzbl (%r12,%rdx,1),%edx
  497707:	add    $0xffffff80,%edx
  49770a:	movzbl %dl,%edx
  49770d:	imul   %r8d,%edx
  497711:	add    %edx,%r13d
  497714:	movzbl -0x1(%r14),%edx
  497719:	add    $0xffffff80,%edx
  49771c:	movzbl %dl,%edx
  49771f:	imul   %r8d,%edx
  497723:	add    %edx,%r11d
  497726:	mov    0x158(%rsp),%rdx
  49772e:	movzbl (%r12,%rdx,1),%edx
  497733:	add    $0xffffff80,%edx
  497736:	movzbl %dl,%edx
  497739:	imul   %r8d,%edx
  49773d:	add    %edx,%r9d
  497740:	mov    0x150(%rsp),%rdx
  497748:	movzbl (%r12,%rdx,1),%edx
  49774d:	mov    %dl,0x1d0(%rsp)
  497754:	add    $0xffffff80,%edx
  497757:	movzbl %dl,%edx
  49775a:	imul   %r8d,%edx
  49775e:	add    %edx,%edi
  497760:	mov    0x148(%rsp),%rdx
  497768:	movzbl (%r12,%rdx,1),%edx
  49776d:	add    $0xffffff80,%edx
  497770:	movzbl %dl,%edx
  497773:	imul   %r8d,%edx
  497777:	add    %edx,%esi
  497779:	cmp    0x50(%rbp),%eax
  49777c:	jb     4976e0 <velri_slang_dot_linear_w8a8_f32+0x2030>
  497782:	mov    0x18(%rbp),%eax
  497785:	mov    %esi,%ecx
  497787:	vmovq  %xmm7,%r8
  49778c:	mov    %edi,%esi
  49778e:	mov    %r9d,%edi
  497791:	mov    %r15,%r9
  497794:	mov    0x1d8(%rsp),%rdx
  49779c:	mov    0x1e0(%rsp),%r15
  4977a4:	imul   %r8,%rdx
  4977a8:	add    0x178(%rsp),%rdx
  4977b0:	shl    $0x2,%rdx
  4977b4:	lea    (%r15,%rdx,1),%r14
  4977b8:	mov    0xd8(%rsp),%r15
  4977c0:	mov    (%r15,%r9,4),%r12d
  4977c4:	sub    %r12d,%r13d
  4977c7:	vcvtsi2ss %r13d,%xmm0,%xmm9
  4977cc:	test   $0x4,%al
  4977ce:	je     498060 <velri_slang_dot_linear_w8a8_f32+0x29b0>
  4977d4:	mov    0x188(%rsp),%r15
  4977dc:	vmovss (%r15),%xmm10
  4977e1:	test   $0x2,%al
  4977e3:	je     4977f3 <velri_slang_dot_linear_w8a8_f32+0x2143>
  4977e5:	mov    0x1e8(%rsp),%r15
  4977ed:	vmulss (%r15,%r8,4),%xmm10,%xmm10
  4977f3:	vmulss %xmm10,%xmm9,%xmm9
  4977f8:	test   $0x1,%al
  4977fa:	je     497809 <velri_slang_dot_linear_w8a8_f32+0x2159>
  4977fc:	mov    0x180(%rsp),%r15
  497804:	vaddss (%r15),%xmm9,%xmm9
  497809:	mov    0x1e0(%rsp),%r15
  497811:	sub    %r12d,%r11d
  497814:	vmovss %xmm9,(%r14)
  497819:	vcvtsi2ss %r11d,%xmm0,%xmm9
  49781e:	lea    0x4(%r15,%rdx,1),%r13
  497823:	test   $0x4,%al
  497825:	je     498050 <velri_slang_dot_linear_w8a8_f32+0x29a0>
  49782b:	mov    0x198(%rsp),%r11
  497833:	vmovss (%r11),%xmm10
  497838:	test   $0x2,%al
  49783a:	je     49784a <velri_slang_dot_linear_w8a8_f32+0x219a>
  49783c:	mov    0x1e8(%rsp),%r11
  497844:	vmulss (%r11,%r8,4),%xmm10,%xmm10
  49784a:	vmulss %xmm10,%xmm9,%xmm9
  49784f:	test   $0x1,%al
  497851:	je     497860 <velri_slang_dot_linear_w8a8_f32+0x21b0>
  497853:	mov    0x190(%rsp),%r15
  49785b:	vaddss (%r15),%xmm9,%xmm9
  497860:	mov    0x1e0(%rsp),%r11
  497868:	sub    %r12d,%edi
  49786b:	vmovss %xmm9,0x0(%r13)
  497871:	vcvtsi2ss %edi,%xmm0,%xmm9
  497875:	lea    0x8(%r11,%rdx,1),%r11
  49787a:	test   $0x4,%al
  49787c:	je     498040 <velri_slang_dot_linear_w8a8_f32+0x2990>
  497882:	mov    0x1a8(%rsp),%rdi
  49788a:	vmovss (%rdi),%xmm10
  49788e:	test   $0x2,%al
  497890:	je     4978a0 <velri_slang_dot_linear_w8a8_f32+0x21f0>
  497892:	mov    0x1e8(%rsp),%rdi
  49789a:	vmulss (%rdi,%r8,4),%xmm10,%xmm10
  4978a0:	vmulss %xmm10,%xmm9,%xmm9
  4978a5:	test   $0x1,%al
  4978a7:	je     4978b5 <velri_slang_dot_linear_w8a8_f32+0x2205>
  4978a9:	mov    0x1a0(%rsp),%rdi
  4978b1:	vaddss (%rdi),%xmm9,%xmm9
  4978b5:	mov    0x1e0(%rsp),%rdi
  4978bd:	sub    %r12d,%esi
  4978c0:	vmovss %xmm9,(%r11)
  4978c5:	vcvtsi2ss %esi,%xmm0,%xmm9
  4978c9:	lea    0xc(%rdi,%rdx,1),%rdi
  4978ce:	test   $0x4,%al
  4978d0:	je     498030 <velri_slang_dot_linear_w8a8_f32+0x2980>
  4978d6:	mov    0x1b8(%rsp),%rsi
  4978de:	vmovss (%rsi),%xmm10
  4978e2:	test   $0x2,%al
  4978e4:	je     4978f4 <velri_slang_dot_linear_w8a8_f32+0x2244>
  4978e6:	mov    0x1e8(%rsp),%rsi
  4978ee:	vmulss (%rsi,%r8,4),%xmm10,%xmm10
  4978f4:	vmulss %xmm10,%xmm9,%xmm9
  4978f9:	test   $0x1,%al
  4978fb:	je     497909 <velri_slang_dot_linear_w8a8_f32+0x2259>
  4978fd:	mov    0x1b0(%rsp),%rsi
  497905:	vaddss (%rsi),%xmm9,%xmm9
  497909:	mov    0x1e0(%rsp),%rsi
  497911:	sub    %r12d,%ecx
  497914:	vmovss %xmm9,(%rdi)
  497918:	vcvtsi2ss %ecx,%xmm0,%xmm9
  49791c:	lea    0x10(%rsi,%rdx,1),%rdx
  497921:	test   $0x4,%al
  497923:	je     498020 <velri_slang_dot_linear_w8a8_f32+0x2970>
  497929:	mov    0x1c8(%rsp),%rcx
  497931:	vmovss (%rcx),%xmm10
  497935:	test   $0x2,%al
  497937:	je     497947 <velri_slang_dot_linear_w8a8_f32+0x2297>
  497939:	mov    0x1e8(%rsp),%rcx
  497941:	vmulss (%rcx,%r8,4),%xmm10,%xmm10
  497947:	vmulss %xmm10,%xmm9,%xmm9
  49794c:	test   $0x1,%al
  49794e:	je     498070 <velri_slang_dot_linear_w8a8_f32+0x29c0>
  497954:	mov    0x1c0(%rsp),%rcx
  49795c:	add    $0x1,%r9
  497960:	vaddss (%rcx),%xmm9,%xmm9
  497964:	vmovss %xmm9,(%rdx)
  497968:	cmp    0xe4(%rsp),%r9d
  497970:	jb     497340 <velri_slang_dot_linear_w8a8_f32+0x1c90>
  497976:	addl   $0x5,0x8c(%rsp)
  49797e:	mov    0x48(%rbp),%eax
  497981:	sub    0x8c(%rsp),%eax
  497988:	cmp    $0x4,%eax
  49798b:	ja     495a00 <velri_slang_dot_linear_w8a8_f32+0x350>
  497991:	mov    0x8c(%rsp),%r11d
  497999:	mov    0x24(%rsp),%edi
  49799d:	mov    0x30(%rbp),%ebx
  4979a0:	mov    0x40(%rbp),%r8d
  4979a4:	mov    0x50(%rbp),%r9d
  4979a8:	mov    0x20(%rsp),%edx
  4979ac:	cmp    0x48(%rbp),%r11d
  4979b0:	jae    4970f5 <velri_slang_dot_linear_w8a8_f32+0x1a45>
  4979b6:	mov    %r11d,%ecx
  4979b9:	mov    0x38(%rsp),%rsi
  4979be:	mov    0x28(%rsp),%r10
  4979c3:	mov    %ebx,0x30(%rbp)
  4979c6:	lea    0x0(,%rcx,4),%rax
  4979ce:	mov    %r8d,0x40(%rbp)
  4979d2:	mov    0xe4(%rsp),%ebx
  4979d9:	lea    (%rsi,%rax,1),%r12
  4979dd:	lea    (%r10,%rax,1),%r13
  4979e1:	mov    0x40(%rsp),%rax
  4979e6:	mov    %rcx,0x1d0(%rsp)
  4979ee:	mov    %edi,0x190(%rsp)
  4979f5:	imul   %rcx,%rax
  4979f9:	mov    0xf0(%rsp),%rcx
  497a01:	lea    (%rcx,%rax,1),%r14
  497a05:	mov    %edx,%eax
  497a07:	and    $0xfffffffc,%eax
  497a0a:	mov    %r14,0x1b8(%rsp)
  497a12:	lea    0x4(%rax),%esi
  497a15:	xor    %eax,%eax
  497a17:	cmpl   $0x3,0x88(%rsp)
  497a1f:	cmova  %esi,%eax
  497a22:	mov    %esi,0x1a0(%rsp)
  497a29:	mov    %eax,%r11d
  497a2c:	mov    %edx,%eax
  497a2e:	mov    0x94(%rsp),%edx
  497a35:	and    $0xfffffffc,%eax
  497a38:	mov    %r11d,0x198(%rsp)
  497a40:	lea    0x4(%rdx,%rax,1),%eax
  497a44:	mov    %edx,%r15d
  497a47:	vmovd  %eax,%xmm16
  497a4d:	mov    0x18(%rbp),%eax
  497a50:	mov    0x1b8(%rsp),%rcx
  497a58:	sub    0xf0(%rsp),%rcx
  497a60:	mov    %r15d,%edx
  497a63:	mov    %rcx,0x1c0(%rsp)
  497a6b:	mov    $0x80808080,%ecx
  497a70:	mov    0xd8(%rsp),%r11
  497a78:	vpbroadcastd %ecx,%zmm6
  497a7e:	cmpl   $0x3,0x88(%rsp)
  497a86:	jbe    4980d8 <velri_slang_dot_linear_w8a8_f32+0x2a28>
  497a8c:	mov    %r15d,0x1a8(%rsp)
  497a94:	mov    %r9d,%r10d
  497a97:	nopw   0x0(%rax,%rax,1)
  497aa0:	lea    0x1(%rdx),%esi
  497aa3:	lea    0x2(%rdx),%ecx
  497aa6:	vmovd  %edx,%xmm12
  497aaa:	vmovq  %rsi,%xmm11
  497aaf:	lea    0x3(%rdx),%esi
  497ab2:	vmovq  %rcx,%xmm10
  497ab7:	vmovq  %rsi,%xmm8
  497abc:	test   %r10d,%r10d
  497abf:	je     4980a8 <velri_slang_dot_linear_w8a8_f32+0x29f8>
  497ac5:	mov    0xe8(%rsp),%rdi
  497acd:	vmovq  %xmm12,%rsi
  497ad2:	mov    %rdi,%rcx
  497ad5:	imul   %rsi,%rcx
  497ad9:	vmovq  %xmm11,%rsi
  497ade:	vmovq  %rcx,%xmm13
  497ae3:	mov    %rdi,%rcx
  497ae6:	imul   %rsi,%rcx
  497aea:	vmovq  %xmm10,%rsi
  497aef:	vmovq  %rcx,%xmm17
  497af5:	mov    %rdi,%rcx
  497af8:	imul   %rsi,%rcx
  497afc:	vmovq  %rcx,%xmm14
  497b01:	vmovq  %xmm8,%rcx
  497b06:	imul   %rcx,%rdi
  497b0a:	vmovq  %rdi,%xmm15
  497b0f:	cmpl   $0x3e,0xf8(%rsp)
  497b17:	jbe    4985b1 <velri_slang_dot_linear_w8a8_f32+0x2f01>
  497b1d:	mov    0x170(%rsp),%rcx
  497b25:	vmovq  %xmm17,%rsi
  497b2b:	vpxor  %xmm2,%xmm2,%xmm2
  497b2f:	vmovdqa32 %zmm2,%zmm4
  497b35:	vmovdqa32 %zmm2,%zmm20
  497b3b:	vmovdqa32 %zmm2,%zmm9
  497b41:	lea    (%rcx,%rdi,1),%r8
  497b45:	lea    (%rcx,%rsi,1),%r9
  497b49:	vmovq  %xmm14,%rdi
  497b4e:	vmovq  %xmm13,%rsi
  497b53:	add    %rcx,%rdi
  497b56:	add    %rcx,%rsi
  497b59:	xor    %ecx,%ecx
  497b5b:	nopl   0x0(%rax)
  497b5f:	data16 cs nopw 0x0(%rax,%rax,1)
  497b6a:	data16 cs nopw 0x0(%rax,%rax,1)
  497b75:	data16 cs nopw 0x0(%rax,%rax,1)
  497b80:	mov    0x1b8(%rsp),%r15
  497b88:	vpxorq (%r15,%rcx,1),%zmm6,%zmm5
  497b8f:	vpdpbusd (%rsi,%rcx,1),%zmm5,%zmm2
  497b96:	vpdpbusd (%r9,%rcx,1),%zmm5,%zmm4
  497b9d:	vpdpbusd (%rdi,%rcx,1),%zmm5,%zmm20
  497ba4:	vpdpbusd (%r8,%rcx,1),%zmm5,%zmm9
  497bab:	add    $0x40,%rcx
  497baf:	cmp    0x78(%rsp),%rcx
  497bb4:	jne    497b80 <velri_slang_dot_linear_w8a8_f32+0x24d0>
  497bb6:	vextracti32x8 $0x1,%zmm2,%ymm7
  497bbd:	vpaddd %ymm2,%ymm7,%ymm7
  497bc1:	vextracti32x4 $0x1,%ymm7,%xmm2
  497bc8:	vpaddd %xmm7,%xmm2,%xmm2
  497bcc:	vpsrldq $0x8,%xmm2,%xmm5
  497bd1:	vpaddd %xmm5,%xmm2,%xmm2
  497bd5:	vpsrldq $0x4,%xmm2,%xmm5
  497bda:	vpaddd %xmm5,%xmm2,%xmm2
  497bde:	vextracti32x8 $0x1,%zmm4,%ymm5
  497be5:	vpaddd %ymm4,%ymm5,%ymm5
  497be9:	vmovd  %xmm2,%r8d
  497bee:	vextracti32x4 $0x1,%ymm5,%xmm2
  497bf5:	vpaddd %xmm5,%xmm2,%xmm2
  497bf9:	vpsrldq $0x8,%xmm2,%xmm4
  497bfe:	vpaddd %xmm4,%xmm2,%xmm2
  497c02:	vpsrldq $0x4,%xmm2,%xmm4
  497c07:	vpaddd %xmm4,%xmm2,%xmm2
  497c0b:	vextracti32x8 $0x1,%zmm20,%ymm4
  497c12:	vpaddd %ymm20,%ymm4,%ymm4
  497c18:	vmovd  %xmm2,%edi
  497c1c:	vextracti32x4 $0x1,%ymm4,%xmm2
  497c23:	vpaddd %xmm4,%xmm2,%xmm2
  497c27:	vpsrldq $0x8,%xmm2,%xmm20
  497c2e:	vpaddd %xmm20,%xmm2,%xmm2
  497c34:	vpsrldq $0x4,%xmm2,%xmm20
  497c3b:	vpaddd %xmm20,%xmm2,%xmm2
  497c41:	vmovd  %xmm2,%esi
  497c45:	vextracti32x8 $0x1,%zmm9,%ymm2
  497c4c:	vpaddd %ymm9,%ymm2,%ymm2
  497c51:	vextracti32x4 $0x1,%ymm2,%xmm9
  497c58:	vpaddd %xmm2,%xmm9,%xmm9
  497c5c:	vpsrldq $0x8,%xmm9,%xmm20
  497c63:	vpaddd %xmm20,%xmm9,%xmm9
  497c69:	vpsrldq $0x4,%xmm9,%xmm20
  497c70:	vpaddd %xmm20,%xmm9,%xmm9
  497c76:	vmovd  %xmm9,0x1c8(%rsp)
  497c7f:	test   $0x3f,%r10b
  497c83:	je     497e2f <velri_slang_dot_linear_w8a8_f32+0x277f>
  497c89:	mov    %r10d,%r14d
  497c8c:	and    $0xffffffc0,%r14d
  497c90:	mov    %r10d,%ecx
  497c93:	sub    %r14d,%ecx
  497c96:	lea    -0x1(%rcx),%r15d
  497c9a:	cmp    $0x1e,%r15d
  497c9e:	jbe    497d98 <velri_slang_dot_linear_w8a8_f32+0x26e8>
  497ca4:	mov    0xf0(%rsp),%rdi
  497cac:	mov    %r14d,%esi
  497caf:	mov    0x1c0(%rsp),%r8
  497cb7:	mov    0x170(%rsp),%r15
  497cbf:	add    %rsi,%rdi
  497cc2:	vpxorq (%rdi,%r8,1),%ymm1,%ymm9
  497cc9:	vmovq  %xmm14,%rdi
  497cce:	add    %r15,%rdi
  497cd1:	vpdpbusd (%rdi,%rsi,1),%ymm9,%ymm4
  497cd8:	vmovq  %xmm15,%rdi
  497cdd:	vpdpbusd (%r9,%rsi,1),%ymm9,%ymm5
  497ce4:	add    %r15,%rdi
  497ce7:	vpdpbusd (%rdi,%rsi,1),%ymm9,%ymm2
  497cee:	vmovq  %xmm13,%rdi
  497cf3:	add    %r15,%rdi
  497cf6:	vpdpbusd (%rdi,%rsi,1),%ymm9,%ymm7
  497cfd:	vextracti32x4 $0x1,%ymm7,%xmm9
  497d04:	vpaddd %xmm7,%xmm9,%xmm7
  497d08:	vpsrldq $0x8,%xmm7,%xmm9
  497d0d:	vpaddd %xmm9,%xmm7,%xmm7
  497d12:	vpsrldq $0x4,%xmm7,%xmm9
  497d17:	vpaddd %xmm9,%xmm7,%xmm7
  497d1c:	vmovd  %xmm7,%r8d
  497d21:	vextracti32x4 $0x1,%ymm5,%xmm7
  497d28:	vpaddd %xmm5,%xmm7,%xmm5
  497d2c:	vpsrldq $0x8,%xmm5,%xmm7
  497d31:	vpaddd %xmm7,%xmm5,%xmm5
  497d35:	vpsrldq $0x4,%xmm5,%xmm7
  497d3a:	vpaddd %xmm7,%xmm5,%xmm5
  497d3e:	vmovd  %xmm5,%edi
  497d42:	vextracti32x4 $0x1,%ymm4,%xmm5
  497d49:	vpaddd %xmm4,%xmm5,%xmm4
  497d4d:	vpsrldq $0x8,%xmm4,%xmm5
  497d52:	vpaddd %xmm5,%xmm4,%xmm4
  497d56:	vpsrldq $0x4,%xmm4,%xmm5
  497d5b:	vpaddd %xmm5,%xmm4,%xmm4
  497d5f:	vmovd  %xmm4,%esi
  497d63:	vextracti32x4 $0x1,%ymm2,%xmm4
  497d6a:	vpaddd %xmm2,%xmm4,%xmm2
  497d6e:	vpsrldq $0x8,%xmm2,%xmm4
  497d73:	vpaddd %xmm4,%xmm2,%xmm2
  497d77:	vpsrldq $0x4,%xmm2,%xmm4
  497d7c:	vpaddd %xmm4,%xmm2,%xmm2
  497d80:	vmovd  %xmm2,0x1c8(%rsp)
  497d89:	test   $0x1f,%cl
  497d8c:	je     497e2f <velri_slang_dot_linear_w8a8_f32+0x277f>
  497d92:	and    $0xffffffe0,%ecx
  497d95:	add    %ecx,%r14d
  497d98:	mov    %r14d,%r15d
  497d9b:	mov    %edx,0x1b0(%rsp)
  497da2:	add    %r15,%r9
  497da5:	add    0x1b8(%rsp),%r15
  497dad:	mov    %eax,0x18(%rbp)
  497db0:	mov    %r15,%rax
  497db3:	mov    %r14d,%r15d
  497db6:	cs nopw 0x0(%rax,%rax,1)
  497dc0:	mov    %r9,%r14
  497dc3:	add    $0x1,%r15d
  497dc7:	add    $0x1,%r9
  497dcb:	add    $0x1,%rax
  497dcf:	vmovq  %xmm17,%rcx
  497dd5:	vmovq  %xmm13,%rdx
  497dda:	sub    %rcx,%r14
  497ddd:	movzbl -0x1(%rax),%ecx
  497de1:	movsbl (%r14,%rdx,1),%edx
  497de6:	add    $0xffffff80,%ecx
  497de9:	movzbl %cl,%ecx
  497dec:	imul   %ecx,%edx
  497def:	add    %edx,%r8d
  497df2:	movsbl -0x1(%r9),%edx
  497df7:	imul   %ecx,%edx
  497dfa:	add    %edx,%edi
  497dfc:	vmovq  %xmm14,%rdx
  497e01:	movsbl (%r14,%rdx,1),%edx
  497e06:	imul   %ecx,%edx
  497e09:	add    %edx,%esi
  497e0b:	vmovq  %xmm15,%rdx
  497e10:	movsbl (%r14,%rdx,1),%r14d
  497e15:	imul   %r14d,%ecx
  497e19:	add    %ecx,0x1c8(%rsp)
  497e20:	cmp    %r10d,%r15d
  497e23:	jb     497dc0 <velri_slang_dot_linear_w8a8_f32+0x2710>
  497e25:	mov    0x1b0(%rsp),%edx
  497e2c:	mov    0x18(%rbp),%eax
  497e2f:	mov    0x1d8(%rsp),%rcx
  497e37:	vmovq  %xmm12,%r9
  497e3c:	sub    (%r11),%r8d
  497e3f:	vcvtsi2ss %r8d,%xmm0,%xmm2
  497e44:	imul   %r9,%rcx
  497e48:	mov    0x1e0(%rsp),%r9
  497e50:	add    0x1d0(%rsp),%rcx
  497e58:	lea    (%r9,%rcx,4),%rcx
  497e5c:	test   $0x4,%al
  497e5e:	je     498010 <velri_slang_dot_linear_w8a8_f32+0x2960>
  497e64:	vmovss 0x0(%r13),%xmm4
  497e6a:	test   $0x2,%al
  497e6c:	je     497e81 <velri_slang_dot_linear_w8a8_f32+0x27d1>
  497e6e:	mov    0x1e8(%rsp),%r9
  497e76:	vmovq  %xmm12,%r15
  497e7b:	vmulss (%r9,%r15,4),%xmm4,%xmm4
  497e81:	vmulss %xmm4,%xmm2,%xmm2
  497e85:	test   $0x1,%al
  497e87:	je     497e8f <velri_slang_dot_linear_w8a8_f32+0x27df>
  497e89:	vaddss (%r12),%xmm2,%xmm2
  497e8f:	vmovss %xmm2,(%rcx)
  497e93:	vmovq  %xmm11,%r9
  497e98:	sub    0x4(%r11),%edi
  497e9c:	mov    0x1d8(%rsp),%rcx
  497ea4:	vcvtsi2ss %edi,%xmm0,%xmm2
  497ea8:	imul   %r9,%rcx
  497eac:	mov    0x1e0(%rsp),%r9
  497eb4:	add    0x1d0(%rsp),%rcx
  497ebc:	lea    (%r9,%rcx,4),%rcx
  497ec0:	test   $0x4,%al
  497ec2:	je     498000 <velri_slang_dot_linear_w8a8_f32+0x2950>
  497ec8:	vmovss 0x0(%r13),%xmm4
  497ece:	test   $0x2,%al
  497ed0:	je     497ee5 <velri_slang_dot_linear_w8a8_f32+0x2835>
  497ed2:	mov    0x1e8(%rsp),%rdi
  497eda:	vmovq  %xmm11,%r9
  497edf:	vmulss (%rdi,%r9,4),%xmm4,%xmm4
  497ee5:	vmulss %xmm4,%xmm2,%xmm2
  497ee9:	test   $0x1,%al
  497eeb:	je     497ef3 <velri_slang_dot_linear_w8a8_f32+0x2843>
  497eed:	vaddss (%r12),%xmm2,%xmm2
  497ef3:	vmovss %xmm2,(%rcx)
  497ef7:	vmovq  %xmm10,%rdi
  497efc:	sub    0x8(%r11),%esi
  497f00:	mov    0x1d8(%rsp),%rcx
  497f08:	vcvtsi2ss %esi,%xmm0,%xmm2
  497f0c:	imul   %rdi,%rcx
  497f10:	mov    0x1e0(%rsp),%rdi
  497f18:	add    0x1d0(%rsp),%rcx
  497f20:	lea    (%rdi,%rcx,4),%rcx
  497f24:	test   $0x4,%al
  497f26:	je     497ff0 <velri_slang_dot_linear_w8a8_f32+0x2940>
  497f2c:	vmovss 0x0(%r13),%xmm4
  497f32:	test   $0x2,%al
  497f34:	je     497f48 <velri_slang_dot_linear_w8a8_f32+0x2898>
  497f36:	mov    0x1e8(%rsp),%rsi
  497f3e:	vmovq  %xmm10,%rdi
  497f43:	vmulss (%rsi,%rdi,4),%xmm4,%xmm4
  497f48:	vmulss %xmm4,%xmm2,%xmm2
  497f4c:	test   $0x1,%al
  497f4e:	je     497f56 <velri_slang_dot_linear_w8a8_f32+0x28a6>
  497f50:	vaddss (%r12),%xmm2,%xmm2
  497f56:	vmovss %xmm2,(%rcx)
  497f5a:	mov    0x1d8(%rsp),%rcx
  497f62:	vmovq  %xmm8,%rsi
  497f67:	imul   %rsi,%rcx
  497f6b:	mov    0x1e0(%rsp),%rsi
  497f73:	add    0x1d0(%rsp),%rcx
  497f7b:	lea    (%rsi,%rcx,4),%rsi
  497f7f:	mov    0x1c8(%rsp),%ecx
  497f86:	sub    0xc(%r11),%ecx
  497f8a:	vcvtsi2ss %ecx,%xmm0,%xmm2
  497f8e:	test   $0x4,%al
  497f90:	je     497fe0 <velri_slang_dot_linear_w8a8_f32+0x2930>
  497f92:	vmovss 0x0(%r13),%xmm4
  497f98:	test   $0x2,%al
  497f9a:	je     497fae <velri_slang_dot_linear_w8a8_f32+0x28fe>
  497f9c:	mov    0x1e8(%rsp),%rcx
  497fa4:	vmovq  %xmm8,%rdi
  497fa9:	vmulss (%rcx,%rdi,4),%xmm4,%xmm4
  497fae:	vmulss %xmm4,%xmm2,%xmm2
  497fb2:	test   $0x1,%al
  497fb4:	je     497fbc <velri_slang_dot_linear_w8a8_f32+0x290c>
  497fb6:	vaddss (%r12),%xmm2,%xmm2
  497fbc:	add    $0x4,%edx
  497fbf:	vmovd  %xmm16,%ecx
  497fc5:	vmovss %xmm2,(%rsi)
  497fc9:	cmp    %ecx,%edx
  497fcb:	je     4980c0 <velri_slang_dot_linear_w8a8_f32+0x2a10>
  497fd1:	add    $0x10,%r11
  497fd5:	jmp    497aa0 <velri_slang_dot_linear_w8a8_f32+0x23f0>
  497fda:	nopw   0x0(%rax,%rax,1)
  497fe0:	vmovss 0x6024(%rip),%xmm4        # 49e00c <_IO_stdin_used+0xc>
  497fe8:	jmp    497f98 <velri_slang_dot_linear_w8a8_f32+0x28e8>
  497fea:	nopw   0x0(%rax,%rax,1)
  497ff0:	vmovss 0x6014(%rip),%xmm4        # 49e00c <_IO_stdin_used+0xc>
  497ff8:	jmp    497f32 <velri_slang_dot_linear_w8a8_f32+0x2882>
  497ffd:	nopl   (%rax)
  498000:	vmovss 0x6004(%rip),%xmm4        # 49e00c <_IO_stdin_used+0xc>
  498008:	jmp    497ece <velri_slang_dot_linear_w8a8_f32+0x281e>
  49800d:	nopl   (%rax)
  498010:	vmovss 0x5ff4(%rip),%xmm4        # 49e00c <_IO_stdin_used+0xc>
  498018:	jmp    497e6a <velri_slang_dot_linear_w8a8_f32+0x27ba>
  49801d:	nopl   (%rax)
  498020:	vmovss 0x5fe4(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  498028:	jmp    497935 <velri_slang_dot_linear_w8a8_f32+0x2285>
  49802d:	nopl   (%rax)
  498030:	vmovss 0x5fd4(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  498038:	jmp    4978e2 <velri_slang_dot_linear_w8a8_f32+0x2232>
  49803d:	nopl   (%rax)
  498040:	vmovss 0x5fc4(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  498048:	jmp    49788e <velri_slang_dot_linear_w8a8_f32+0x21de>
  49804d:	nopl   (%rax)
  498050:	vmovss 0x5fb4(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  498058:	jmp    497838 <velri_slang_dot_linear_w8a8_f32+0x2188>
  49805d:	nopl   (%rax)
  498060:	vmovss 0x5fa4(%rip),%xmm10        # 49e00c <_IO_stdin_used+0xc>
  498068:	jmp    4977e1 <velri_slang_dot_linear_w8a8_f32+0x2131>
  49806d:	nopl   (%rax)
  498070:	vmovss %xmm9,(%rdx)
  498074:	add    $0x1,%r9
  498078:	cmp    0xe4(%rsp),%r9d
  498080:	jb     497340 <velri_slang_dot_linear_w8a8_f32+0x1c90>
  498086:	jmp    497976 <velri_slang_dot_linear_w8a8_f32+0x22c6>
  49808b:	nopl   0x0(%rax,%rax,1)
  498090:	xor    %ecx,%ecx
  498092:	xor    %esi,%esi
  498094:	xor    %edi,%edi
  498096:	xor    %r11d,%r11d
  498099:	xor    %r13d,%r13d
  49809c:	jmp    497794 <velri_slang_dot_linear_w8a8_f32+0x20e4>
  4980a1:	nopl   0x0(%rax)
  4980a8:	movl   $0x0,0x1c8(%rsp)
  4980b3:	xor    %esi,%esi
  4980b5:	xor    %edi,%edi
  4980b7:	xor    %r8d,%r8d
  4980ba:	jmp    497e2f <velri_slang_dot_linear_w8a8_f32+0x277f>
  4980bf:	nop
  4980c0:	mov    0x1a8(%rsp),%r15d
  4980c8:	mov    %r10d,%r9d
  4980cb:	cmp    %ebx,0x1a0(%rsp)
  4980d2:	jae    4970b8 <velri_slang_dot_linear_w8a8_f32+0x1a08>
  4980d8:	mov    $0x80808080,%edx
  4980dd:	mov    0x198(%rsp),%esi
  4980e4:	vpbroadcastd %edx,%zmm5
  4980ea:	nopw   0x0(%rax,%rax,1)
  4980f0:	lea    (%r15,%rsi,1),%edi
  4980f4:	test   %r9d,%r9d
  4980f7:	je     49832f <velri_slang_dot_linear_w8a8_f32+0x2c7f>
  4980fd:	mov    0xe8(%rsp),%rdx
  498105:	imul   %rdi,%rdx
  498109:	cmpl   $0x3e,0xf8(%rsp)
  498111:	jbe    4985ec <velri_slang_dot_linear_w8a8_f32+0x2f3c>
  498117:	mov    0x170(%rsp),%rcx
  49811f:	vpxor  %xmm4,%xmm4,%xmm4
  498123:	lea    (%rcx,%rdx,1),%r11
  498127:	xor    %ecx,%ecx
  498129:	nop
  49812a:	data16 cs nopw 0x0(%rax,%rax,1)
  498135:	data16 cs nopw 0x0(%rax,%rax,1)
  498140:	mov    0x1b8(%rsp),%r10
  498148:	vpxorq (%r10,%rcx,1),%zmm5,%zmm2
  49814f:	vpdpbusd (%r11,%rcx,1),%zmm2,%zmm4
  498156:	add    $0x40,%rcx
  49815a:	cmp    0x78(%rsp),%rcx
  49815f:	jne    498140 <velri_slang_dot_linear_w8a8_f32+0x2a90>
  498161:	vextracti32x8 $0x1,%zmm4,%ymm2
  498168:	vpaddd %ymm4,%ymm2,%ymm2
  49816c:	vextracti32x4 $0x1,%ymm2,%xmm4
  498173:	vpaddd %xmm2,%xmm4,%xmm4
  498177:	vpsrldq $0x8,%xmm4,%xmm6
  49817c:	vpaddd %xmm6,%xmm4,%xmm4
  498180:	vpsrldq $0x4,%xmm4,%xmm6
  498185:	vpaddd %xmm6,%xmm4,%xmm4
  498189:	vmovd  %xmm4,%ecx
  49818d:	test   $0x3f,%r9b
  498191:	je     4982b5 <velri_slang_dot_linear_w8a8_f32+0x2c05>
  498197:	mov    %r9d,%r8d
  49819a:	and    $0xffffffc0,%r8d
  49819e:	mov    %r9d,%r11d
  4981a1:	sub    %r8d,%r11d
  4981a4:	lea    -0x1(%r11),%r14d
  4981a8:	cmp    $0x1e,%r14d
  4981ac:	jbe    498211 <velri_slang_dot_linear_w8a8_f32+0x2b61>
  4981ae:	mov    0xf0(%rsp),%r10
  4981b6:	mov    %r8d,%ecx
  4981b9:	lea    (%r10,%rcx,1),%r14
  4981bd:	mov    0x1c0(%rsp),%r10
  4981c5:	vpxorq (%r14,%r10,1),%ymm1,%ymm4
  4981cc:	mov    0x170(%rsp),%r10
  4981d4:	lea    (%r10,%rdx,1),%r14
  4981d8:	vpdpbusd (%r14,%rcx,1),%ymm4,%ymm2
  4981df:	vextracti32x4 $0x1,%ymm2,%xmm4
  4981e6:	vpaddd %xmm2,%xmm4,%xmm2
  4981ea:	vpsrldq $0x8,%xmm2,%xmm4
  4981ef:	vpaddd %xmm4,%xmm2,%xmm2
  4981f3:	vpsrldq $0x4,%xmm2,%xmm4
  4981f8:	vpaddd %xmm4,%xmm2,%xmm2
  4981fc:	vmovd  %xmm2,%ecx
  498200:	test   $0x1f,%r11b
  498204:	je     4982b5 <velri_slang_dot_linear_w8a8_f32+0x2c05>
  49820a:	and    $0xffffffe0,%r11d
  49820e:	add    %r11d,%r8d
  498211:	mov    0x1c0(%rsp),%r10
  498219:	mov    %r8d,%r14d
  49821c:	mov    0xf0(%rsp),%r11
  498224:	mov    %rsi,0x1b0(%rsp)
  49822c:	add    %r14,%r10
  49822f:	add    %rdx,%r14
  498232:	add    0x170(%rsp),%r14
  49823a:	mov    %r14,%rsi
  49823d:	add    %r11,%r10
  498240:	mov    %eax,%r14d
  498243:	xor    %r11d,%r11d
  498246:	mov    %rsi,%rax
  498249:	data16 cs nopw 0x0(%rax,%rax,1)
  498254:	data16 cs nopw 0x0(%rax,%rax,1)
  49825f:	data16 cs nopw 0x0(%rax,%rax,1)
  49826a:	data16 cs nopw 0x0(%rax,%rax,1)
  498275:	data16 cs nopw 0x0(%rax,%rax,1)
  498280:	movzbl (%r10,%r11,1),%esi
  498285:	lea    -0x80(%rsi),%edx
  498288:	mov    %sil,0x1c8(%rsp)
  498290:	movsbl (%rax,%r11,1),%esi
  498295:	add    $0x1,%r11
  498299:	movzbl %dl,%edx
  49829c:	imul   %esi,%edx
  49829f:	add    %edx,%ecx
  4982a1:	lea    (%r8,%r11,1),%edx
  4982a5:	cmp    %r9d,%edx
  4982a8:	jb     498280 <velri_slang_dot_linear_w8a8_f32+0x2bd0>
  4982aa:	mov    0x1b0(%rsp),%rsi
  4982b2:	mov    %r14d,%eax
  4982b5:	mov    0x1d8(%rsp),%rdx
  4982bd:	mov    0x1e0(%rsp),%r10
  4982c5:	imul   %rdi,%rdx
  4982c9:	add    0x1d0(%rsp),%rdx
  4982d1:	lea    (%r10,%rdx,4),%rdx
  4982d5:	mov    0xd8(%rsp),%r10
  4982dd:	sub    (%r10,%rsi,4),%ecx
  4982e1:	vcvtsi2ss %ecx,%xmm0,%xmm2
  4982e5:	test   $0x4,%al
  4982e7:	je     498338 <velri_slang_dot_linear_w8a8_f32+0x2c88>
  4982e9:	vmovss 0x0(%r13),%xmm4
  4982ef:	test   $0x2,%al
  4982f1:	je     498300 <velri_slang_dot_linear_w8a8_f32+0x2c50>
  4982f3:	mov    0x1e8(%rsp),%rcx
  4982fb:	vmulss (%rcx,%rdi,4),%xmm4,%xmm4
  498300:	vmulss %xmm4,%xmm2,%xmm2
  498304:	test   $0x1,%al
  498306:	je     4970a8 <velri_slang_dot_linear_w8a8_f32+0x19f8>
  49830c:	vaddss (%r12),%xmm2,%xmm2
  498312:	add    $0x1,%rsi
  498316:	vmovss %xmm2,(%rdx)
  49831a:	cmp    %ebx,%esi
  49831c:	jae    4970b8 <velri_slang_dot_linear_w8a8_f32+0x1a08>
  498322:	lea    (%r15,%rsi,1),%edi
  498326:	test   %r9d,%r9d
  498329:	jne    4980fd <velri_slang_dot_linear_w8a8_f32+0x2a4d>
  49832f:	xor    %ecx,%ecx
  498331:	jmp    4982b5 <velri_slang_dot_linear_w8a8_f32+0x2c05>
  498333:	nopl   0x0(%rax,%rax,1)
  498338:	vmovss 0x5ccc(%rip),%xmm4        # 49e00c <_IO_stdin_used+0xc>
  498340:	jmp    4982ef <velri_slang_dot_linear_w8a8_f32+0x2c3f>
  498342:	nopw   0x0(%rax,%rax,1)
  498348:	movl   $0x0,0x134(%rsp)
  498353:	xor    %r8d,%r8d
  498356:	movl   $0x0,0x130(%rsp)
  498361:	movl   $0x0,0x12c(%rsp)
  49836c:	movl   $0x0,0x128(%rsp)
  498377:	movl   $0x0,0x124(%rsp)
  498382:	movl   $0x0,0x120(%rsp)
  49838d:	movl   $0x0,0x11c(%rsp)
  498398:	movl   $0x0,0x118(%rsp)
  4983a3:	movl   $0x0,0x110(%rsp)
  4983ae:	movl   $0x0,0x10c(%rsp)
  4983b9:	movl   $0x0,0x108(%rsp)
  4983c4:	movl   $0x0,0x104(%rsp)
  4983cf:	movl   $0x0,0x100(%rsp)
  4983da:	movl   $0x0,0xfc(%rsp)
  4983e5:	movl   $0x0,0x114(%rsp)
  4983f0:	movl   $0x0,0x138(%rsp)
  4983fb:	movl   $0x0,0x13c(%rsp)
  498406:	movl   $0x0,0x140(%rsp)
  498411:	movl   $0x0,0x144(%rsp)
  49841c:	jmp    496a2b <velri_slang_dot_linear_w8a8_f32+0x137b>
  498421:	mov    0x170(%rsp),%r15
  498429:	xor    %ecx,%ecx
  49842b:	xor    %esi,%esi
  49842d:	xor    %edi,%edi
  49842f:	vpxor  %xmm13,%xmm13,%xmm13
  498434:	xor    %r11d,%r11d
  498437:	xor    %r13d,%r13d
  49843a:	xor    %r12d,%r12d
  49843d:	vmovdqa %ymm13,%ymm12
  498442:	vmovdqa %ymm13,%ymm11
  498447:	vmovdqa %ymm13,%ymm10
  49844c:	add    %rdx,%r15
  49844f:	vmovdqa %ymm13,%ymm9
  498454:	jmp    497554 <velri_slang_dot_linear_w8a8_f32+0x1ea4>
  498459:	mov    %rsi,%rdi
  49845c:	vpxor  %xmm9,%xmm9,%xmm9
  498461:	xor    %r8d,%r8d
  498464:	xor    %r13d,%r13d
  498467:	mov    0x170(%rsp),%rsi
  49846f:	movl   $0x0,0x134(%rsp)
  49847a:	vmovdqa32 %ymm9,%ymm22
  498480:	vmovdqa32 %ymm9,%ymm23
  498486:	movl   $0x0,0x130(%rsp)
  498491:	vmovdqa32 %ymm9,%ymm24
  498497:	vmovdqa %ymm9,%ymm15
  49849c:	vmovdqa %ymm9,%ymm8
  4984a1:	movl   $0x0,0x12c(%rsp)
  4984ac:	lea    (%rsi,%rdi,1),%r14
  4984b0:	vmovdqa32 %ymm9,%ymm28
  4984b6:	vmovdqa32 %ymm9,%ymm20
  4984bc:	movl   $0x0,0x128(%rsp)
  4984c7:	vmovdqa32 %ymm9,%ymm17
  4984cd:	vmovdqa %ymm9,%ymm7
  4984d1:	vmovdqa %ymm9,%ymm10
  4984d6:	movl   $0x0,0x124(%rsp)
  4984e1:	vmovdqa32 %ymm9,%ymm29
  4984e7:	vmovdqa %ymm9,%ymm6
  4984eb:	vmovdqa32 %ymm9,%ymm16
  4984f1:	movl   $0x0,0x120(%rsp)
  4984fc:	vmovdqa32 %ymm9,%ymm27
  498502:	vmovdqa32 %ymm9,%ymm31
  498508:	vmovdqa %ymm9,%ymm3
  49850c:	movl   $0x0,0x11c(%rsp)
  498517:	vmovdqa %ymm9,%ymm2
  49851b:	vmovdqa %ymm9,%ymm5
  49851f:	movl   $0x0,0x118(%rsp)
  49852a:	movl   $0x0,0x110(%rsp)
  498535:	movl   $0x0,0x10c(%rsp)
  498540:	movl   $0x0,0x108(%rsp)
  49854b:	movl   $0x0,0x104(%rsp)
  498556:	movl   $0x0,0x100(%rsp)
  498561:	movl   $0x0,0xfc(%rsp)
  49856c:	movl   $0x0,0x114(%rsp)
  498577:	movl   $0x0,0x138(%rsp)
  498582:	movl   $0x0,0x13c(%rsp)
  49858d:	movl   $0x0,0x140(%rsp)
  498598:	movl   $0x0,0x144(%rsp)
  4985a3:	vmovdqa %ymm9,0xa0(%rsp)
  4985ac:	jmp    4962e0 <velri_slang_dot_linear_w8a8_f32+0xc30>
  4985b1:	mov    0x170(%rsp),%rcx
  4985b9:	xor    %esi,%esi
  4985bb:	xor    %edi,%edi
  4985bd:	xor    %r8d,%r8d
  4985c0:	vpxor  %xmm7,%xmm7,%xmm7
  4985c4:	vmovq  %xmm17,%r9
  4985ca:	xor    %r14d,%r14d
  4985cd:	movl   $0x0,0x1c8(%rsp)
  4985d8:	vmovdqa %ymm7,%ymm5
  4985dc:	vmovdqa %ymm7,%ymm4
  4985e0:	vmovdqa %ymm7,%ymm2
  4985e4:	add    %rcx,%r9
  4985e7:	jmp    497c90 <velri_slang_dot_linear_w8a8_f32+0x25e0>
  4985ec:	vpxor  %xmm2,%xmm2,%xmm2
  4985f0:	xor    %ecx,%ecx
  4985f2:	xor    %r8d,%r8d
  4985f5:	jmp    49819e <velri_slang_dot_linear_w8a8_f32+0x2aee>
  4985fa:	vpxor  %xmm5,%xmm5,%xmm5
  4985fe:	vpxor  %xmm2,%xmm2,%xmm2
  498602:	xor    %edx,%edx
  498604:	add    %r14,%rcx
  498607:	jmp    4958cc <velri_slang_dot_linear_w8a8_f32+0x21c>
  49860c:	vpslld $0x7,%xmm2,%xmm2
  498611:	add    $0x1,%esi
  498614:	vmovd  %xmm2,(%r10)
  498619:	cmp    %ebx,%esi
  49861b:	je     495991 <velri_slang_dot_linear_w8a8_f32+0x2e1>
  498621:	mov    %esi,%ecx
  498623:	add    $0x4,%r10
  498627:	imul   %r11,%rcx
  49862b:	jmp    495820 <velri_slang_dot_linear_w8a8_f32+0x170>
  498630:	call   402220 <__stack_chk_fail@plt>

Disassembly of section .fini:
