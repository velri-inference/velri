"""Render operator CSVs and Markdown from the recorded traces, without hardware."""
import os,sys,subprocess,tempfile
from pathlib import Path
d=Path(__file__).resolve().parent
root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
with tempfile.TemporaryDirectory() as tmp:
 for phase in ('before','after'):
  for dev in ('avx2','avx512','vulkan'):
   p=Path(tmp)/f'{phase}-{dev}-operators.csv'
   with p.open('w') as f:
    subprocess.run([sys.executable,root/'tools/profile/summarize.py',dev,'--vk-header',
                    d/'traces'/f'{phase}-pipelines.h',*sorted((d/'traces').glob(f'{phase}-{dev}-*.trace'))],stdout=f,check=True)
 subprocess.run([sys.executable,d/'make-tables.py',tmp,out,'--twin',d/'twin'],check=True)
