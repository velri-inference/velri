"""Render the collected profiles to a single CSV and a compact human-readable table."""
import argparse
import csv
import statistics
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('input',type=Path,help='directory with before/after-{avx2,avx512,vulkan}-operators.csv from summarize.py')
p.add_argument('output',type=Path)
p.add_argument('--twin',type=Path,required=True)
args=p.parse_args()
data,out=args.input,args.output
out.mkdir(parents=True,exist_ok=True)
devices={'avx2':'Ryzen 9 9950X AVX2','avx512':'Ryzen 9 9950X AVX-512','vulkan':'RTX 5070 Ti Vulkan'}
phases=('before','after')
raw=[]
tables={}
for device in devices:
    for phase in phases:
        with (data/f'{phase}-{device}-operators.csv').open() as f:
            rows=list(csv.DictReader(f))
        tables[device,phase]={(r['kernel'],r['operations_and_shape']):r for r in rows}
        raw.extend([{'device':device,'version':phase,**row} for row in rows])
with (out/'operators.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=raw[0],lineterminator='\n');w.writeheader();w.writerows(raw)

def cells(values,key,fmt):
    return ' / '.join('—' if not v or v[key]=='' else format(float(v[key]),fmt) for v in values)
def pretty(name):
    return name.replace('W8A8:', 'I8 ').replace('attention:','Attention ').replace('rope:','RoPE ').replace('quant:','Quant ').replace('rms:','RMSNorm ').replace('residual:','Add ').replace('gated:','SwiGLU ').replace('sampler:','Greedy ').replace('readback:','PCIe ').replace('embedding:', 'Embedding ').replace('last:', 'CopyLast ').replace('x','×').replace('+', ' + ').replace('empty:0','Пустая пара меток')
lines=['# Профиль одного запроса за 64 токена',
'',
'Три независимых запуска каждой сборки на каждом бэкенде. В каждой ячейке с парой чисел первое относится к исходной ревизии, второе — к оптимизированной. Микросекунды приведены на один вызов. Формы GEMV записаны как M×K. У Attention указаны число Q-голов, число KV-голов, размеры K и V и байты на элемент KV. Окно Attention проходит от 129 до 192 позиций. У RoPE указаны число голов, ширина головы и число вращаемых координат.',
'',
'Для INT8 указан эффективный TOPS, для FP32 — TFLOPS. Время объединённого кернела включает все операции из его строки. Для смешанной строки TOPS считает INT8 MAC, а CSV дополнительно содержит объём вспомогательной FP32 арифметики. «Пик» — независимо измеренная регистровая производительность CPU или FP32 FMA / плотных INT8 тензорных инструкций GPU. «Стрим.» — минимум арифметического пика и предела по независимо измеренной полосе памяти и логическому трафику данной формы. Для копирования и сканирования показаны ГБ/с. Прочерк в паре означает, что эта версия выполнила соответствующую работу в другом объединении.',
'',
'CPU измерен от входа до выхода синхронного submit. Vulkan измерен GPU-метками с отдельным барьером завершения кернела. Эти барьеры изменяют расписание GPU и существенно влияют на короткие диспетчи. Пустая пара показывает расходы пустого интервала. В загруженном интервале в измерение также входит завершение предыдущих операций и/или ожидание освобождения ресурсов. Основная скорость полной сессии измеряется отдельным исполняемым файлом с обычным командным буфером.',
'']
bw={'avx2':69.40,'avx512':70.50,'vulkan':838.196}
lines+=['| Проекции W8A8 за 64 шага | Время групп, мс | Эффективные TOPS | Логические ГБ/с | % от стримингового потолка |',
'|---|---:|---:|---:|---:|']
for device,name in devices.items():
    ctx=[]
    for phase in phases:
        rows=[r for r in tables[device,phase].values() if float(r['int8_ops_per_call'])]
        ns=sum(float(r['ms_per_tg64'])*1e6 for r in rows)
        b=sum(float(r['logical_bytes_per_call'])*float(r['calls_per_tg64']) for r in rows)
        work=sum(float(r['int8_ops_per_call'])*float(r['calls_per_tg64']) for r in rows)
        ctx.append((ns*1e-6,work/ns*1e-3,b/ns,100*b/ns/bw[device]))
    cells_local=[' / '.join(format(v[idx],fmt) for v in ctx) for idx,fmt in enumerate(('.2f','.4f','.2f','.2f'))]
    lines+=['| '+' | '.join([name]+cells_local)+' |']
for device,name in devices.items():
    lines+=['',f'## {name}','','| Операция и форма | Вызовов за tg64 | мкс | Ед. | Скорость | Пик | Δ пик, % | Стрим. | Δ стрим., % |','|---|---:|---:|---|---:|---:|---:|---:|---:|']
    a,b=(tables[device,phase] for phase in phases)
    keys=sorted(set(a)|set(b),key=lambda k:-max(float(x[k]['ms_per_tg64']) for x in (a,b) if k in x))
    for k in keys:
        values=[a.get(k),b.get(k)]
        v=next(x for x in values if x)
        cells_local=[pretty(k[1]),cells(values,'calls_per_tg64','.0f'),cells(values,'us_per_call','.3f'),v['unit'] or '—',
                     cells(values,'rate','.5f'),v['compute_peak'] or '—',cells(values,'delta_compute_pct','+.2f'),
                     format(float(v['streaming_roof']),'.5f') if v['streaming_roof'] else '—',cells(values,'delta_roof_pct','+.2f')]
        lines+=['| '+' | '.join(cells_local)+' |']
lines += ['', '## Проверка пропускной способности Vulkan без меток времени внутри графа', '',
'Дополнительный диспетч читает холодную копию тех же обученных INT8-весов перед каждым исходным диспетчем проекции. За tg64 это 66 202 894 336 дополнительных байт матриц. Сравниваются два вида дополнительной работы. Первый выполняет штатный кернел проекции с его эпилогом. Второй читает те же матрицы и записывает контрольную сумму. В обоих случаях используются исходные размеры сетки. Из времени каждой серии вычтена серия с дополнительным диспетчем нулевого размера, теми же привязками и барьерами. Все исходные кернелы и зависимые шаги продолжают выполняться.', '',
'| Ревизия | Дополнительная работа | Разности полного tg64 трёх пар, мс | Средняя разность, мс | ГБ/с весов | % от 838,196 ГБ/с |',
'|---|---|---:|---:|---:|---:|']
for phase,label in [('before','До'),('after','После')]:
    def times(mode):
        out_times=[]
        for p in sorted(args.twin.glob(f'{phase}-0x0_0-1-{mode}-*.csv')):
            with p.open() as f:
                rows=[float(r['total_ms']) for r in csv.DictReader(f) if r['run']!='all']
            assert len(rows)==3
            out_times.append(statistics.mean(rows))
        assert len(out_times)==3
        return out_times
    for mode,zero,desc in [(1,0,'Штатный W8A8'),(2,3,'Чтение и контрольная сумма')]:
        diff=[a-b for a,b in zip(times(mode),times(zero))]
        ms=statistics.mean(diff)
        rate=66_202_894_336/(ms*1e6)
        lines.append(f'| {label} | {desc} | {", ".join(f"{t:.2f}" for t in diff)} | {ms:.2f} | {rate:.2f} | {100*rate/838.196:.2f} |')
lines += ['', 'В финальной сборке добавленный W8A8 занял 90,41 мс, сканирование — 90,34 мс. Разница 0,08% меньше разброса между независимыми процессами. В этом эксперименте чтение весов с той же геометрией запусков воспроизвело затраты дополнительной арифметики в пределах разброса. Контроль с нулевым диспетчем сам добавляет команды в граф. Вычитание измеряет предельную стоимость добавленной работы и исключает часть расходов на диспетч и синхронизацию. Поэтому результат 87% в этом контроле дан отдельно от исходного 76,69% в основном пооператорном профиле.', '',
'Все 24 процесса контрольного эксперимента сохранили исходную траекторию. В первом процессе каждого из четырёх режимов для каждой сборки все 65 векторов FP32-логитов совпали побайтно с исходной штатной сессией. Профили Vulkan обеих сборок также проверены по всем логитам. [Сырые трейсы, исходники контроля и команды воспроизведения](operator-evidence.tar.gz)']
lines+=['','CSV содержит точные числа, имена пайплайнов, число вызовов, полезные байты и операции каждого формата. [operators.csv](operators.csv)','','Потолок полосы основной памяти применён ко всем арифметическим формам единообразно. Положительная Δ от него у малого оператора указывает на возможное обслуживание из кэша. Host greedy использует системную калибровку CPU, чтение логитов GPU→host — калибровку PCIe 57,8066 ГБ/с.','']
(out/'OPERATORS.md').write_text('\n'.join(lines))
