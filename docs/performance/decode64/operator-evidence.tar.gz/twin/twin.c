/* In a diagnostic executable, insert an identical cold copy of selected W8A8 projection
 * dispatches. A zero-workgroup placebo issues the same bindings and WAW dependencies.
 * All original dispatches still run. Restrict to single-row, overwrite-only projections. */
#include "velri_vk_abi.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static velri_backend_device *device;
static PFN_vkCmdDispatch real_dispatch;
static PFN_vkDestroyDevice real_destroy;
static bool enabled;
static vk_dispatch_stage extra;
static unsigned m_filter, k_filter, fused_filter;
enum { MAX_SLABS = 32, MAX_REPEATS = 4 };
static struct { const vk_buf *src; vk_buf *clone; } slabs[MAX_SLABS][MAX_REPEATS];
static size_t nslab;
static unsigned repeat, mode;
static void fail(const char *m) {fprintf(stderr,"cold twin: %s\n",m);exit(1);}
#define CHECK(x) do { if (!(x)) fail(#x); } while(0)

static void transfer(const vk_buf *src, vk_buf *dst) {
    VkCommandBuffer cmd = device->xfer_cmd;
    VkCommandBufferBeginInfo info={.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
                                   .flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT};
    CHECK(device->vkResetCommandBuffer(cmd,0)==VK_SUCCESS && device->vkBeginCommandBuffer(cmd,&info)==VK_SUCCESS);
    if(src) {
        VkBufferCopy copy={.size=src->size}; device->vkCmdCopyBuffer(cmd,src->buffer,dst->buffer,1,&copy);
    } else device->vkCmdFillBuffer(cmd,dst->buffer,0,dst->size,0);
    VkMemoryBarrier b={.sType=VK_STRUCTURE_TYPE_MEMORY_BARRIER,.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT,
                       .dstAccessMask=VK_ACCESS_SHADER_READ_BIT};
    device->vkCmdPipelineBarrier(cmd,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 0,1,&b,0,NULL,0,NULL);
    CHECK(device->vkEndCommandBuffer(cmd)==VK_SUCCESS);
    CHECK(device->vkResetFences(device->device,1,&device->xfer_fence)==VK_SUCCESS);
    VkSubmitInfo submit={.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO,.commandBufferCount=1,.pCommandBuffers=&cmd};
    CHECK(device->vkQueueSubmit(device->queue,1,&submit,device->xfer_fence)==VK_SUCCESS);
    CHECK(device->vkWaitForFences(device->device,1,&device->xfer_fence,VK_TRUE,UINT64_MAX)==VK_SUCCESS);
}

static int mirror(const vk_buf *src) {
    for(size_t i=0;i<nslab;++i) if(slabs[i][0].src==src) return (int)i;
    CHECK(nslab<MAX_SLABS);
    for(unsigned j=0;j<repeat;++j) {
        vk_buf *dst=NULL;
        CHECK(velri_vk_alloc_buf_locked(device, src->size, 16, &dst)==VELRI_OK);
        transfer(src, dst);
        slabs[nslab][j].src=src;
        slabs[nslab][j].clone=dst;
    }
    return (int)nslab++;
}
static int slab[3];
static size_t residual_pc, pc_offset[3], matrix_offset[3];
static uint32_t rows[3], nw, cols, wg;
static VkPipeline scan_pipe[2];
static vk_buf *sink;
static VkPipeline make_scan(unsigned threads) {
    char path[512]; CHECK(snprintf(path,sizeof(path),"%s/scan%u.spv",getenv("VELRI_TWIN_SHADERS"),threads)>0);
    FILE *f=fopen(path,"rb"); CHECK(f); fseek(f,0,SEEK_END);size_t n=(size_t)ftell(f);rewind(f);
    uint32_t *words=malloc(n);CHECK(words && fread(words,1,n,f)==n);fclose(f);
    VkShaderModuleCreateInfo sm_info={.sType=VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,.codeSize=n,.pCode=words};
    VkShaderModule sm;CHECK(device->vkCreateShaderModule(device->device,&sm_info,NULL,&sm)==VK_SUCCESS);free(words);
    VkComputePipelineCreateInfo info={.sType=VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO,
        .stage={.sType=VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,.stage=VK_SHADER_STAGE_COMPUTE_BIT,
                .module=sm,.pName="main"},.layout=device->pipe_layout};
    VkPipeline pipeline;CHECK(device->vkCreateComputePipelines(device->device,VK_NULL_HANDLE,1,&info,NULL,&pipeline)==VK_SUCCESS);
    device->vkDestroyShaderModule(device->device,sm,NULL);return pipeline;
}
static void VKAPI_CALL dispatch(VkCommandBuffer cmd,uint32_t gx,uint32_t gy,uint32_t gz) {
    if(enabled) {
        uint8_t pc[VK_MAX_PC_BYTES]; memcpy(pc, extra.pc,extra.pc_size);
        if (residual_pc != SIZE_MAX) memcpy(pc+residual_pc,&sink->bda,sizeof(sink->bda));
        for(unsigned j=0;j<repeat;++j) {
            struct {uint64_t w[3],sink;uint32_t m[3],k16,groups;} r={.k16=cols/16,.groups=gx};
            for(unsigned t=0;t<nw;++t) {
                r.w[t]=slabs[slab[t]][j].clone->bda+matrix_offset[t];
                r.m[t]=rows[t];
                memcpy(pc+pc_offset[t],r.w+t,sizeof(uint64_t));
            }
            if(mode>=2) {
                r.sink=sink->bda;
                device->vkCmdBindPipeline(cmd,VK_PIPELINE_BIND_POINT_COMPUTE,scan_pipe[wg==256]);
                device->vkCmdPushConstants(cmd,device->pipe_layout,VK_SHADER_STAGE_COMPUTE_BIT,0,sizeof(r),&r);
            } else {
                device->vkCmdPushConstants(cmd,device->pipe_layout,VK_SHADER_STAGE_COMPUTE_BIT,
                                           0,extra.pc_size,pc);
            }
            real_dispatch(cmd,(mode==1||mode==2)?gx:0,gy,gz);
            VkMemoryBarrier b={.sType=VK_STRUCTURE_TYPE_MEMORY_BARRIER,
                               .srcAccessMask=VK_ACCESS_SHADER_WRITE_BIT,
                               .dstAccessMask=VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT};
            device->vkCmdPipelineBarrier(cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                         VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,1,&b,0,NULL,0,NULL);
        }
        if(mode>=2) device->vkCmdBindPipeline(cmd,VK_PIPELINE_BIND_POINT_COMPUTE,extra.pipe);
        device->vkCmdPushConstants(cmd,device->pipe_layout,VK_SHADER_STAGE_COMPUTE_BIT,0,extra.pc_size,extra.pc);
    }
    real_dispatch(cmd,gx,gy,gz);
}

static void VKAPI_CALL destroy(VkDevice vk,const VkAllocationCallbacks *a) {
    for(size_t i=0;i<nslab;i++) for(unsigned j=0;j<repeat;j++)
        velri_vk_free_buf_locked(device,slabs[i][j].clone);
    if(sink) velri_vk_free_buf_locked(device,sink);
    for(unsigned i=0;i<2;i++) if(scan_pipe[i]) device->vkDestroyPipeline(vk,scan_pipe[i],NULL);
    real_destroy(vk,a);device=NULL;
}

uint32_t __real_velri_vk_fuse_decode(velri_backend_device *,const velri_submit_item *,
                                     const vk_encoded_dispatch *,uint32_t,vk_encoded_dispatch *);
uint32_t __wrap_velri_vk_fuse_decode(velri_backend_device *dev,const velri_submit_item *items,
                                     const vk_encoded_dispatch *enc,uint32_t count,vk_encoded_dispatch *out) {
    if(!device) {
        device=dev;
        const char *spec=getenv("VELRI_TWIN");
        CHECK(spec && sscanf(spec,"%ux%u:%u:%u:%u",&m_filter,&k_filter,&fused_filter,&repeat,&mode)==5);
        CHECK(repeat>0 && repeat<=MAX_REPEATS && mode<=3 && fused_filter<=3);
        if(mode>=2) {
            scan_pipe[0]=make_scan(128);scan_pipe[1]=make_scan(256);
        }
        CHECK(velri_vk_alloc_buf_locked(dev,1U<<20,16,&sink)==VELRI_OK); transfer(NULL,sink);
        real_dispatch=dev->vkCmdDispatch;dev->vkCmdDispatch=dispatch;
        real_destroy=dev->vkDestroyDevice;dev->vkDestroyDevice=destroy;
    }
    uint32_t n=__real_velri_vk_fuse_decode(dev,items,enc,count,out);
    const vk_encoded_dispatch *e=n?out:enc;
    enabled=false;
    if(!items->params || !items->params->has_seq_len || items->params->seq_len_override!=1 ||
       e->num_stages!=1) return n;
    nw=0;wg=128;residual_pc=SIZE_MAX;
    for(uint32_t i=0;i<(n?n:1);++i) {
        const velri_submit_item *it=items+i;
        if(it->op->kind==VELRI_OP_VEC_AXPBY && nw) {
            const vk_buf *buffer=it->outputs[0].mem_handle;
            uint64_t residual=buffer->bda+it->outputs[0].byte_offset;
            extra=e->stages[0];
            for (size_t j=0;j+8<=extra.pc_size;j+=8) {
                uint64_t val;memcpy(&val,extra.pc+j,8);if(val==residual){residual_pc=j;break;}
            }
            CHECK(residual_pc!=SIZE_MAX && rows[0]*4<=sink->size);
            continue;
        }
        if(it->op->kind==VELRI_OP_QUANTIZE_ROW) {wg=256;continue;}
        if(it->op->kind==VELRI_OP_ROPE || it->op->kind==VELRI_OP_GATED_MLP) continue;
        if(it->op->kind!=VELRI_OP_LINEAR || it->op->inputs[1].dtype!=VELRI_DTYPE_I8) return n;
        CHECK(nw<3);
        const vk_buf *source=it->inputs[1].mem_handle;
        rows[nw]=it->op->inputs[1].dims[0];cols=it->op->inputs[1].dims[1];
        matrix_offset[nw]=it->inputs[1].byte_offset;
        uint64_t addr=source->bda+matrix_offset[nw];
        extra=e->stages[0];
        size_t j=0;
        for(;j+sizeof(addr)<=extra.pc_size;j+=sizeof(addr)) {
            uint64_t val;memcpy(&val,extra.pc+j,sizeof(val));
            if(val==addr) break;
        }
        CHECK(j+sizeof(addr)<=extra.pc_size);
        pc_offset[nw]=j;
        if((m_filter==0 || rows[0]==m_filter) && (k_filter==0 || cols==k_filter))
            slab[nw]=mirror(source);
        ++nw;
    }
    if(!nw || (m_filter && rows[0]!=m_filter) || (k_filter && cols!=k_filter)) return n;
    if((fused_filter==1 && n) || (fused_filter==2 && !n) || (fused_filter==3 && nw<2)) return n;
    enabled=true;
    return n;
}
