"""Build and reproduce the cold-weight control for a benchmark checkout and its matching Release build."""
import argparse, csv, os, pathlib, subprocess
p=argparse.ArgumentParser(description=__doc__)
for key in ('checkout','build','weights','output'):p.add_argument(key,type=pathlib.Path)
p.add_argument('--cpus',default='0-15')
p.add_argument('--expected-logits',type=pathlib.Path)
p.add_argument('--phase',choices=('before','after'),required=True)
a=p.parse_args()
src,build,weights,out=[x.resolve() for x in (a.checkout,a.build,a.weights,a.output)]
tool=pathlib.Path(__file__).resolve().parent
out.mkdir(parents=True,exist_ok=True)
def run(cmd,**kwargs):return subprocess.run([str(x) for x in cmd],check=True,**kwargs)
inc=next(l.split('=',1)[1] for l in (build/'CMakeCache.txt').read_text().splitlines()
         if l.startswith('VELRI_VULKAN_INCLUDE_DIR:PATH='))
shaders=src/'velri-lib/src/kernels/slang'
for size in [128,256]:
 spv=out/f'scan{size}.spv'
 run(['slangc',tool/'twin.slang','-I',shaders/'common','-I',shaders/'vk','-target','spirv',
      '-profile','spirv_1_6','-Wno-41012','-fvk-use-c-layout','-O3','-entry',f'scan{size}',
      '-stage','compute','-o',spv])
 run(['spirv-val','--target-env','vulkan1.3',spv])
include=[src/'include',src/'tests',src/'src',src/'velri-lib/include',build/'velri-lib/generated/slang',inc]
include.extend(src/'velri-lib/src'/d for d in ['core','ops','platform','backend/vulkan'])
exe=out/'cold-control'
run([os.environ.get('CC','clang'),'-std=c23','-O3','-DNDEBUG',*['-I'+str(i) for i in include],
     tool/'twin.c',src/'tools/bench_session.c','-Wl,--wrap=velri_vk_fuse_decode',
     build/'libvelri_engine.a',build/'velri-lib/libvelri.a','-ldl','-lm','-pthread','-o',exe])
expected=None if not a.expected_logits else a.expected_logits.read_bytes()
for trial,order in enumerate(((0,1,2,3),(3,2,1,0),(1,0,3,2)),1):
 for mode in order:
  stem=out/f'{a.phase}-0x0_0-1-{mode}-{trial}'
  env={**os.environ,'VELRI_TWIN_SHADERS':str(out),'VELRI_TWIN':f'0x0:0:1:{mode}'}
  logits=out/'verify.f32'
  extra=['--logits',logits] if trial==1 else []
  with stem.with_suffix('.csv').open('w') as log,stem.with_suffix('.log').open('w') as err:
   run(['taskset','-c',a.cpus,exe,'vulkan','1','--weights',weights,'--warmups','2','--runs','3',*extra],
       env=env,stdout=log,stderr=err)
  if trial==1:
   content=logits.read_bytes()
   if expected is None: expected=content
   if content!=expected:raise ValueError('control logits differ')
  if '8a5348dd784b27aa' not in stem.with_suffix('.log').read_text():raise ValueError('trajectory differs')
