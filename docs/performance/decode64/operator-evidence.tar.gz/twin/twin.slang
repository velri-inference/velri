import vk_common;
struct Args {
    Ptr<uint4, Access.Read> w0, w1, w2;
    Ptr<uint> out;
    uint m0, m1, m2, k16, groups;
};
void scan<let T : uint>(Args a, uint3 group, uint3 tid) {
    uint lanes = WaveGetLaneCount();
    uint first = group.x * (T/lanes) + tid.x/lanes;
    uint stride = a.groups * (T/lanes);
    for(uint col=first; col<a.m0+a.m1+a.m2; col+=stride) {
        uint row=col;
        Ptr<uint4, Access.Read> w = a.w0;
        if(row>=a.m0) {row-=a.m0;w=a.w1;if(row>=a.m1){row-=a.m1;w=a.w2;}}
        uint4 sums=uint4(0);
        for(uint j=WaveGetLaneIndex();j<a.k16;j+=lanes)
            sums ^= load_a16(w+uint64_t(row)*a.k16+j);
        uint s=WaveActiveBitXor(sums.x^sums.y^sums.z^sums.w);
        if(WaveGetLaneIndex()==0u) a.out[col]=s;
    }
}
[shader("compute")] [numthreads(128,1,1)]
void scan128(uniform Args a,uint3 g:SV_GroupID,uint3 t:SV_GroupThreadID){scan<128u>(a,g,t);}
[shader("compute")] [numthreads(256,1,1)]
void scan256(uniform Args a,uint3 g:SV_GroupID,uint3 t:SV_GroupThreadID){scan<256u>(a,g,t);}
