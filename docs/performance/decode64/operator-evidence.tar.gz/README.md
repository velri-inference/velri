Each trace covers one individually generated request after two complete warmups. Build the checkout as described in the repository's tools/decode64-method.md and tools/profile/README.md. Run the Linux profile_session binary once per independent trial. Use VELRI_TRACE_RUN=3 and VELRI_TRACE_FILE=<name>. Link and run each executable against matching checkout internals. Vulkan device structure offsets and IDs can differ between revisions.

To regenerate tables from these 18 raw traces, run the following command after extraction.

```sh
python3 rebuild.py /path/to/Velri /tmp/regenerated-operators
```

To repeat the marginal W8A8 controls on the RTX 5070 Ti, use the same two Release builds as the full benchmark, including the common public W8A8 loader, checkpoint converter, and benchmark on both sides. Run each checkout sequentially. Pass the exact stock Vulkan prefill and 64 decode logits from the ordinary benchmark to --expected-logits. The pinned model and prompt have trajectory 8a5348dd784b27aa.

```sh
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/nvidia_icd.json
python3 twin/replay.py "$BASE_SRC" "$BASE_BUILD" model.w8 /tmp/twin-before --phase before --expected-logits stock.f32
python3 twin/replay.py "$FINAL_SRC" "$FINAL_BUILD" model.w8 /tmp/twin-after --phase after --expected-logits stock.f32
```

The control binary replaces each selected weight-buffer device address with a second on-device copy and adds a diagnostic dispatch before the original. Cold copies cover every dense projection, including LM head, and exceed GPU L2 by over an order of magnitude. Scale arrays and activations keep their original addresses. Source and duplicate have identical weights. For fused residual addition the duplicated shader writes its residual to private scratch, so the real residual is updated exactly once. Push constants and pipelines are restored for the original dispatch. Every result consumed by the session still comes from the original production graph.

Mode 0 binds duplicate weights and issues a zero-workgroup dispatch with a shader dependency before the original. Mode 1 uses the actual launch grid and production arithmetic. Mode 2 binds an independently compiled scan pipeline that reads the same weights with the same workgroup and grid sizes, reduces a checksum and stores it to private memory. Fused projections scan all constituent matrices. Mode 3 uses the scan pipeline with zero workgroups. Matched differences 1 minus 0 and 2 minus 3 measure incremental work under each diagnostic schedule, including the cold extra matrix traffic. The scan's lane assignment differs from the fused mathematical shader. Mode 0 is an added-command control, so its timing can differ from untouched inference. Compare native inference only with the normal bench_session wall clock.

Three independent processes per mode, two warmups and three measured tg64 windows per process. Trials interleave the four modes in the order defined in replay.py. Verify all 65 logit vectors on the first trial of every mode and the greedy trajectory on all trials. The normal benchmark provides native end-to-end timings. The separate dispatch trace records individual kernel intervals.
