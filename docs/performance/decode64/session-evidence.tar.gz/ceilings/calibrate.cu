#include <cstdio>
#include <cstdlib>
#include <cuda_runtime.h>
#define OK(call) do {auto e=(call);if(e!=cudaSuccess){fprintf(stderr,"%s %s\n",#call,cudaGetErrorString(e));exit(1);}}while(0)
template<int mode> __global__ void peak(float *sink,int cycles){
    int id=blockIdx.x*blockDim.x+threadIdx.x;
    unsigned a=0x34003400u+(threadIdx.x&7), b=0x30003000u+(threadIdx.x&3);
    if constexpr(mode==0){
        float regs[12];
        #pragma unroll
        for(int i=0;i<12;i++) regs[i]=i+id*0.00001f;
        for(int r=0;r<cycles;r++){
            #pragma unroll
            for(int i=0;i<12;i++) asm volatile("fma.rn.f32 %0,%0,%1,%2;" : "+f"(regs[i]) : "f"(1.00001f), "f"(0.001f));
        }
        float s=0;for(auto v:regs)s+=v;sink[id]=s;
    }else{
        union {float f; int i;} acc[6][4]={};
        for(int r=0;r<cycles;r++){
            #pragma unroll
            for(int j=0;j<6;j++){
                #define ARGS(typ,member) typ(acc[j][0].member),typ(acc[j][1].member),typ(acc[j][2].member),typ(acc[j][3].member)
                #define FRAGS "{%0,%1,%2,%3},{%4,%4,%4,%4},{%5,%5},{%0,%1,%2,%3};"
                if constexpr(mode==1) asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.f16.f16.f32 " FRAGS : ARGS("+f",f) : "r"(a),"r"(b));
                if constexpr(mode==2) asm volatile("mma.sync.aligned.m16n8k16.row.col.f32.bf16.bf16.f32 " FRAGS : ARGS("+f",f) : "r"(a),"r"(b));
                if constexpr(mode==3) asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 " FRAGS : ARGS("+r",i) : "r"(a),"r"(b));
            }
        }
        float s=0;for(auto &row:acc)for(auto &v:row)s+=mode==3?(float)v.i:v.f;sink[id]=s;
    }
}
template<int mode> double run(int blocks,float *out){
    constexpr int cycles=1024;
    cudaEvent_t start,end; OK(cudaEventCreate(&start));OK(cudaEventCreate(&end));
    for(int j=0;j<12;j++) peak<mode><<<blocks,128>>>(out,cycles);
    OK(cudaDeviceSynchronize()); float best=1e9;
    for(int s=0;s<12;s++){
        OK(cudaEventRecord(start));
        for(int i=0;i<4;i++) peak<mode><<<blocks,128>>>(out,cycles);
        OK(cudaEventRecord(end));OK(cudaEventSynchronize(end));float ms;OK(cudaEventElapsedTime(&ms,start,end));if(ms<best)best=ms;
    }
    OK(cudaEventDestroy(start));OK(cudaEventDestroy(end));
    constexpr int ops_lane=mode==0?24:6*2*16*8*(mode==3?32:16)/32;
    return double(blocks)*128*cycles*ops_lane*4/(best*1e9);
}
int main(){
    cudaDeviceProp p; OK(cudaGetDeviceProperties(&p,0)); int blocks=p.multiProcessorCount*24;
    printf("GPU %s SM %d L2 %d bus %d\n",p.name,p.multiProcessorCount,p.l2CacheSize,p.memoryBusWidth);
    float *buf; OK(cudaMalloc(&buf,blocks*128*sizeof(float)));
    printf("FP32 %.4f\n",run<0>(blocks,buf));printf("FP16 %.4f\n",run<1>(blocks,buf));printf("BF16 %.4f\n",run<2>(blocks,buf));printf("INT8 %.4f\n",run<3>(blocks,buf));OK(cudaFree(buf));
}
