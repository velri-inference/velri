#define _GNU_SOURCE
#include "pool.h"
#include <sched.h>
#include <stdlib.h>
static void pin(void *unused,size_t id,size_t nw) {
    cpu_set_t mask; CPU_ZERO(&mask); CPU_SET(id,&mask);
    if(sched_setaffinity(0,sizeof(mask),&mask)) abort();
}
velri_status __real_velri_pool_create(size_t,velri_pool **);
velri_status __wrap_velri_pool_create(size_t n,velri_pool **out){
    velri_status st=__real_velri_pool_create(n,out);
    if(st==VELRI_OK && n==16) velri_pool_parallel(*out,n,pin,NULL);
    return st;
}
