#include <initializer_list>
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#define OK(call) do{auto e=call;if(e!=cudaSuccess){fprintf(stderr,"%s\n",cudaGetErrorString(e));exit(1);}}while(0)
__global__ void scan(const uint4* input,uint4* out,unsigned n){
    unsigned id=threadIdx.x+blockIdx.x*blockDim.x, stride=gridDim.x*blockDim.x;
    uint4 s={};
    for(unsigned i=id;i<n;i+=stride){uint4 v=input[i];s.x^=v.x;s.y^=v.y;s.z^=v.z;s.w^=v.w;}
    out[id]=s;
}
__global__ void init(uint4 *p,unsigned n){
    unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i<n){unsigned v=i*0x9e3779b9u;p[i]=make_uint4(v,v*97941u,v*32033u,v*81233u);}
}
int main(){
    unsigned n=32u*1024*1024;uint4 *in,*out;OK(cudaMalloc(&in,n*16));OK(cudaMalloc(&out,70*32*256*16));
    init<<<n/256,256>>>(in,n);OK(cudaDeviceSynchronize());
    cudaEvent_t start,end;OK(cudaEventCreate(&start));OK(cudaEventCreate(&end));
    double peak=0;
    for(int b:{4,8,16,32}){
        for(int i=0;i<40;i++)scan<<<70*b,256>>>(in,out,n);
        OK(cudaDeviceSynchronize());
        for(int i=0;i<10;i++){
            OK(cudaEventRecord(start));for(int j=0;j<16;j++) scan<<<70*b,256>>>(in,out,n);
            OK(cudaEventRecord(end));OK(cudaEventSynchronize(end));float ms;OK(cudaEventElapsedTime(&ms,start,end));
            double gb=(double)n*16*16/(ms*1e6);if(gb>peak)peak=gb;
        }
    }
    printf("VRAM_read_512MiB_GB_s %.3f\n",peak);
    OK(cudaFree(in));OK(cudaFree(out));
}
