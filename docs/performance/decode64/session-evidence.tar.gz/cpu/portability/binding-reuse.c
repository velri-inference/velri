#define main engine_suite_main
#include "test_engine_runtime.c"
#undef main

typedef struct {
    velri_session *s;
    const int32_t *ids;
    float logits[3][3];
} sequence;
static void *step_sequence(void *arg) {
    sequence *task = arg;
    for (uint32_t j = 0; j < 3; ++j) {
        velri_step_result res;
        uint32_t n = j == 0 ? 3 : 1;
        CHECK_RC(velri_session_step(task->s, task->ids + (j == 0 ? 0 : j + 2), n,
                                    nullptr, nullptr, &res), "session step");
        CHECK(res.kv_len == j + 3 && res.last_step_allocs == 0, "private state and scratch");
        memcpy(task->logits[j], res.logits, 3*sizeof(float));
    }
    return nullptr;
}
static void exercise(bool tied, bool dual) {
    const velri_ctx_options opts = {.cpu_threads = 4U, .enable_vulkan = dual};
    velri_ctx *ctx = nullptr;
    velri_model *model = nullptr;
    velri_program *prog = nullptr;

    const velri_model_desc desc = {
        .arch = VELRI_ARCH_LLAMA, .weight_type = VELRI_TYPE_W8A8,
        .vocab_size = 3U, .hidden_size = 4U, .intermediate_size = 4U,
        .max_position_embeddings = 8U, .num_hidden_layers = 1U,
        .num_attention_heads = 1U, .tie_word_embeddings = tied, .norm_eps = 1e-5f,
    };
    CHECK_RC(velri_ctx_create(&opts, &ctx), "W8 context");
    CHECK_RC(velri_model_create_synthetic(ctx, &desc, &model), "W8 model");
    const float embed[3][4] = {{1, 2, -5, 4}, {-2, 3, 7, 1}, {3, -1, 4, 5}};
    const float ones[4] = {1, 1, 1, 1};
    const int8_t zeros[4][4] = {{0}};
    CHECK_RC(velri_model_bind_weight(model, "model.embed_tokens.weight", embed, sizeof(embed)), "embed");
    const char *norms[] = {"model.layers.0.input_layernorm.weight",
                           "model.layers.0.post_attention_layernorm.weight", "model.norm.weight"};
    for (size_t i = 0; i < sizeof(norms) / sizeof(norms[0]); ++i)
        CHECK_RC(velri_model_bind_weight(model, norms[i], ones, sizeof(ones)), norms[i]);
    const char *projections[] = {"self_attn.q_proj", "self_attn.k_proj", "self_attn.v_proj",
                                 "self_attn.o_proj", "mlp.gate_proj", "mlp.up_proj", "mlp.down_proj"};
    for (size_t i = 0; i < sizeof(projections) / sizeof(projections[0]); ++i) {
        char name[128];
        snprintf(name, sizeof(name), "model.layers.0.%s.weight", projections[i]);
        CHECK_RC(velri_model_bind_weight(model, name, zeros, sizeof(zeros)), name);
        snprintf(name, sizeof(name), "model.layers.0.%s.weight_scale", projections[i]);
        CHECK_RC(velri_model_bind_weight(model, name, ones, sizeof(ones)), name);
    }

    const int8_t head[3][4] = {{-128, 1, 2, 3}, {7, 12, 20, 127}, {-2, 3, 4, -5}};
    const float scale[3] = {0.25f, 0.5f, 0.125f};
    if (!tied) {
        CHECK_RC(velri_model_bind_weight(model, "lm_head.weight", head, sizeof(head)), "I8 head");
        CHECK(velri_program_prepare(ctx, model, nullptr, &prog) == VELRI_RC_ERR_NOT_FOUND &&
              !prog && strstr(velri_ctx_last_error(ctx), "lm_head.weight_scale"), "missing W8 scale");
        CHECK_RC(velri_model_bind_weight(model, "lm_head.weight_scale", scale, sizeof(scale)), "F32 scales");
    }


    const char *target = tied ? "model.layers.0.self_attn.q_proj.weight_scale" : "lm_head.weight_scale";
    const float *good = tied ? ones : scale;
    const size_t size = tied ? sizeof(ones) : sizeof(scale);
    alignas(float) unsigned char unaligned[sizeof(ones) + 1];
    memcpy(unaligned + 1, good, size);
    const uint32_t count = velri_model_weight_count(model);
    CHECK_RC(velri_model_bind_weight(model, target, good, size - 1), "register short scale");
    CHECK(velri_program_prepare(ctx, model, nullptr, &prog) == VELRI_RC_ERR_INVALID && !prog, "reject undersized scale");
    CHECK_RC(velri_model_bind_weight(model, target, unaligned + 1, size), "register unaligned scale");
    CHECK(velri_program_prepare(ctx, model, nullptr, &prog) == VELRI_RC_ERR_INVALID && !prog, "reject unaligned scale");
    CHECK_RC(velri_model_bind_weight(model, target, good, size), "retry scale");
    CHECK(velri_model_weight_count(model) == count, "replace a binding without adding an entry");

    const char *json = "{\"model\":{\"store\":\"vulkan:0\",\"compute\":\"vulkan:0\",\"hidden-layers\":{\"dense-mlp\":{\"compute\":\"cpu:0\",\"prefill-compute\":\"vulkan:0\"}}}}";
    velri_program_options opt = {.prefill_chunk_size = 2, .max_ctx = 8};
    if (dual) { opt.placement_json = json; opt.placement_json_len = strlen(json); }
    velri_program *second;
    CHECK_RC(velri_program_prepare(ctx, model, &opt, &prog), "first prepare");
    CHECK_RC(velri_program_prepare(ctx, model, &opt, &second), "independent reader");
    CHECK(velri_program_has_distinct_prefill(prog) == dual, "prefill/decode sharing");
    CHECK(velri_model_bind_weight(model, target, good, size) == VELRI_RC_ERR_BUSY, "busy with two programs");
    const int32_t ids0[] = {1, 0, 2, 0, 1}, ids1[] = {0, 2, 1, 1, 0};
    sequence jobs[] = {{.ids=ids0},{.ids=ids1}}, refs[] = {{.ids=ids0},{.ids=ids1}};
    for (int n = 0; n < 2; ++n) {
        CHECK_RC(velri_session_create(second, nullptr, &refs[n].s), "fresh reference slot");
        step_sequence(&refs[n]);
        CHECK_RC(velri_session_destroy(refs[n].s), "release reference");
        CHECK_RC(velri_session_create(prog, nullptr, &jobs[n].s), "concurrent slot");
    }
    pthread_t threads[2];
    for (int n = 0; n < 2; ++n)
        CHECK(!pthread_create(&threads[n], nullptr, step_sequence, &jobs[n]), "start reader");
    for (int n = 0; n < 2; ++n) {
        CHECK(!pthread_join(threads[n], nullptr), "complete reader");
        CHECK(!memcmp(refs[n].logits, jobs[n].logits, sizeof(jobs[n].logits)), "all session logits exact");
        CHECK_RC(velri_session_destroy(jobs[n].s), "release slot");
    }
    CHECK_RC(velri_program_destroy(prog), "release first reader");
    CHECK(velri_model_bind_weight(model, target, good, size) == VELRI_RC_ERR_BUSY, "busy with one program");
    CHECK_RC(velri_program_destroy(second), "release final reader");
    CHECK_RC(velri_model_bind_weight(model, target, good, size), "rebind after readers");
    CHECK_RC(velri_program_prepare(ctx, model, &opt, &prog), "reprepare");
    CHECK_RC(velri_program_destroy(prog), "release retried program");
    CHECK_RC(velri_model_destroy(model), "release model");
    CHECK_RC(velri_ctx_destroy(ctx), "release context");
    printf("PASS tied=%d dual=%d, short & unaligned scales, retry, two programs, two concurrent slots, exact logits\n",tied,dual);
}
int main(void) {
    for (int tied = 0; tied < 2; ++tied)
        for (int dual = 0; dual < 2; ++dual)
            exercise(tied, dual);
}
