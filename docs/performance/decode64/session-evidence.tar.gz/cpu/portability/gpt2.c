#define main engine_suite_main
#include "test_engine_runtime.c"
#undef main

static void run_mode(velri_ctx *ctx, bool w8, float logits[6][64]){
    velri_model_desc d={.arch=VELRI_ARCH_GPT2,.vocab_size=64,.hidden_size=32,
      .max_position_embeddings=32,.intermediate_size=64,.num_attention_heads=4,
      .num_hidden_layers=1,.norm_eps=1e-5f,.hidden_act=VELRI_ACTIVATION_GELU_TANH,
      .tie_word_embeddings=true,.weight_type=w8?VELRI_TYPE_W8A8:VELRI_TYPE_F32};
    velri_model *m; CHECK_RC(velri_model_create_synthetic(ctx,&d,&m),"gpt2 model");
    weight_pool pool={0}; populate_gpt2_weights(m,&d,&pool);
    const char *projs[]={"attn.c_attn","attn.c_proj","mlp.c_fc","mlp.c_proj"};
    const unsigned rows[]={96,32,64,32},cols[]={32,32,32,64};
    for(int p=0;p<4;p++){
        size_t sz=rows[p]*cols[p];
        float *f=pool_alloc_f32(&pool,sz,42,0,0);
        char name[128];
        snprintf(name,sizeof(name),"transformer.h.0.%s.weight",projs[p]);
        CHECK_RC(velri_model_bind_weight(m,name,f,w8?sz:sz*4),name);
        if(w8){
            float *scale=pool_alloc_f32(&pool,rows[p],166,0.2f,0.25f);
            snprintf(name,sizeof(name),"transformer.h.0.%s.weight_scale",projs[p]);
            CHECK_RC(velri_model_bind_weight(m,name,scale,rows[p]*4),name);
        }
    }
    velri_program_options options={.prefill_chunk_size=4,.max_ctx=32};
    velri_program *prog; CHECK_RC(velri_program_prepare(ctx,m,&options,&prog),"gpt2 plan");
    velri_session *s; CHECK_RC(velri_session_create(prog,nullptr,&s),"gpt2 session");
    const int32_t prompt[]={5,6,7,3,9,1,6};velri_sampling_params greedy={};
    int32_t token=0;
    for(int n=0;n<6;n++){
        velri_step_result result;
        CHECK_RC(velri_session_step(s,n?&token:prompt,n?1:7,&greedy,nullptr,&result),"gpt2 step");
        CHECK(result.kv_len==7U+(unsigned)n && result.last_step_allocs==0,"kv/alloc");
        token=result.sampled_token;
        memcpy(logits[n],result.logits,sizeof(float)*64);
    }
    CHECK_RC(velri_session_destroy(s),"drop");CHECK_RC(velri_program_destroy(prog),"drop");
    CHECK_RC(velri_model_destroy(m),"drop");pool_destroy(&pool);
}
int main(){
    for(int gpu=0;gpu<2;gpu++){
        velri_ctx_options options={.cpu_threads=2,.enable_vulkan=gpu};
        velri_ctx *ctx;CHECK_RC(velri_ctx_create(&options,&ctx),"ctx");
        float fp[6][64], q[6][64]; run_mode(ctx,false,fp);run_mode(ctx,true,q);
        CHECK_RC(velri_ctx_destroy(ctx),"drop");
        float err=max_abs_diff(&q[0][0],&fp[0][0],6*64);
        printf("GPT2 fused QKV with bias, tied embeddings, 7-token chunked prefill and five dependent decodes, Vulkan=%d max_abs=%g\n",gpu,err);
        CHECK(err<1e-5,"f32 parity");
    }
}
