# CPU decode64 verification

These probes ran separately from the measured production binaries. Run each instrumented patch in a separate clean checkout of the released source at its repository root. Set `EVIDENCE` to the absolute path of this directory, and `WEIGHTS` to the fixture made by `tools/prepare_session_weights.py`. The measured W8A8 fixture SHA256 was `4a42c4e05fffc0cbe3cadf1fad19412ee09ecea6595053eedc12cfc970081002`. The shell examples use Linux, Clang and the project's Slang toolchain. CPU IDs 0–15 were distinct physical cores on this machine.

## Arithmetic

The patch independently recomputes signed integer dot products and FP32 scale products from the actual TinyLlama projection bindings. It visits the last active row at each dispatch, every output channel on the prompt's final row and first decode, then regularly spaced channels across every projection on later positions. It also recomputes every active activation code, using scalar absolute maximum and round-half-away-from-zero, and every per-row scale using floating-point division. The probe assumes row-major projections with no bias, as used by this checkpoint. The baseline and optimized kernels agree bitwise per ISA over the complete uninstrumented trajectory.

```sh
git apply "$EVIDENCE/arithmetic/instrument.patch"
cmake -S . -B audit-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang -DVELRI_BUILD_BENCHMARKS=ON
cmake --build audit-build --target bench_session
for isa in avx2 avx512; do
  taskset -c 0-15 audit-build/bench_session cpu 16 --isa "$isa" --weights "$WEIGHTS" --warmups 0 --runs 1 >"$isa.csv" 2>"$isa.log"
done
```

Both recorded logs contain 1,015,713 checked projection outputs and 48,899,584 checked activation codes, with zero mismatches. Of 16,707 row scales, 795 (AVX2) and 750 (AVX-512) differ from scalar division. Maximum relative error is 1.192e-7. Dot comparisons use the actual bound scale after independent inspection and exactly match. The diagnostic wall times include the scalar verification and should be excluded from performance reporting.

## Pool and cold reads

The pool patch issues an empty call to the same 16-worker pool immediately after each real 256×2048 K/V decode projection. Run it in an independent checkout with the same configuration.

```sh
git apply "$EVIDENCE/pool/instrument.patch"
cmake -S . -B probe-build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang -DVELRI_BUILD_BENCHMARKS=ON
cmake --build probe-build --target bench_session
for isa in avx2 avx512; do
  POOL_PROBE="$PWD/$isa.ns" taskset -c 0-15 probe-build/bench_session cpu 16 --isa "$isa" --weights "$WEIGHTS" --warmups 2 --runs 1 --logits "$isa.f32" >"$isa.csv"
done
```

Each `.ns` file contains 3 sequences × 64 tokens × 22 layers × 2 projections in call order. Analyze the final 2,816 values after the two warmups. Means and medians were 0.637 and 0.600 µs on AVX2, 0.680 and 0.630 µs on AVX-512. The independent cold control streams a 512 MiB ring of aligned weight slabs with the same pool. Each tile has the corresponding projection's dimensions and each cache line is loaded exactly once with two unaligned 256-bit loads. The sum includes call and barrier time. Files `cold/cpu-?.csv` hold the third pass for each fresh process. K/V times were 8.090, 8.319 and 8.254 µs.

```sh
clang -std=c23 -O3 -mavx2 -Ivelri-lib/include -Ivelri-lib/src/platform "$EVIDENCE/cold/stream.c" probe-build/velri-lib/libvelri.a -lpthread -lm -ldl -o cold-stream
for i in 1 2 3; do taskset -c 0-15 ./cold-stream > "cold-$i.csv"; done
```

## Experimental grouped dispatch

`grouped-qkv-gate/instrument.patch` is an isolated diagnostic for this single model, machine and input arrangement. It divides groups of independent Q/K/V or gate/up rows between workers. Production dispatch retains its cancellation and aliasing behavior. The interleaved comparison files compare production (`stream128`) and the grouped prototype (`siblingsvirtualall`), using the same full logits checks and two warmups per fresh process. Both ISAs produced identical logits to their respective baseline. The comparison was exploratory. AVX2 production/grouped means were 1,067.281/1,040.810 ms, AVX-512 1,072.178/1,060.465 ms. The official release measurements use the regular production executable. K/V-only variants are reported in their own diagnostic logs.

## Runtime and platform checks

`portability` contains CTest logs from the AArch64 and RV64 QEMU guests and native fallback builds, QEMU x86 Haswell without VNNI, and native Vulkan. The GPT-2 fixture compares a zero-projection FP32 model and its W8A8 equivalent with nonzero biases, tied embeddings, seven prompt tokens and five dependent decodes. The binding/reuse fixture exercises partial prepare failure and recovery, scale alignment and sizes, read-only bindings shared across programs, independent concurrent sessions, split CPU/Vulkan prefill and decode, and tied and untied output heads. Both supplementary fixtures can link against a regular Vulkan-enabled release build.

```sh
for check in gpt2 binding-reuse; do
  clang -std=c23 -O2 -Iinclude -Isrc -Itests "$EVIDENCE/portability/$check.c" build/libvelri_engine.a build/velri-lib/libvelri.a -ldl -lm -lpthread -o "$check"
  "./$check"
done
```
