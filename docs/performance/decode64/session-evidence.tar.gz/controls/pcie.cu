#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
#define OK(f) do { auto e=(f); if(e!=cudaSuccess) {std::fprintf(stderr,"%s: %s\n",#f,cudaGetErrorString(e));std::exit(1);} } while(0)
int main() {
    constexpr unsigned maxBytes=64*1024*1024;
    char *device, *host;
    OK(cudaMalloc(&device,maxBytes)); OK(cudaMallocHost(&host,maxBytes)); OK(cudaMemset(device,1,maxBytes));
    cudaEvent_t begin,end; OK(cudaEventCreate(&begin)); OK(cudaEventCreate(&end));
    for(unsigned bytes : {128000u, maxBytes}) {
        unsigned count = bytes == maxBytes ? 8 : 512;
        for(unsigned phase=0;phase<2;++phase) {
            OK(cudaEventRecord(begin));
            for(unsigned i=0;i<count;++i){
                unsigned off=(i%(maxBytes/bytes))*bytes;
                OK(cudaMemcpyAsync(host+off,device+off,bytes,cudaMemcpyDeviceToHost));
            }
            OK(cudaEventRecord(end)); OK(cudaEventSynchronize(end));
            float ms; OK(cudaEventElapsedTime(&ms,begin,end)); if(phase) printf("%u,%.4f\n",bytes,double(bytes)*count/(ms*1e6));
        }
    }
    OK(cudaFreeHost(host));OK(cudaFree(device));
}
