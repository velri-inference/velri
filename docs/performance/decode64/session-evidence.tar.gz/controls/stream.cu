#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#define OK(f) do { cudaError_t e=(f); if(e!=cudaSuccess){fprintf(stderr,"%s: %s\n",#f,cudaGetErrorString(e));exit(1);} } while(0)
__global__ void read_tile(const uint4 *p, unsigned *dst, unsigned n) {
    unsigned i = blockIdx.x*blockDim.x+threadIdx.x;
    unsigned v=0;
    for (; i<n; i+=gridDim.x*blockDim.x) {
        uint4 w=p[i]; v^=w.x^w.y^w.z^w.w;
    }
    for (unsigned i=16;i;i/=2) v^=__shfl_xor_sync(0xffffffff,v,i);
    if (threadIdx.x%32==0) dst[(blockIdx.x*blockDim.x+threadIdx.x)/32]=v;
}
__global__ void fill(uint4 *p, unsigned n) {
    unsigned i = blockIdx.x*blockDim.x+threadIdx.x;
    if (i<n) { unsigned v=i*2654435761U; p[i]=make_uint4(v, v*50261, v*227017, v*120107); }
}
int main() {
    constexpr unsigned cap=512*1024*1024;
    const unsigned m[]={256,2048,5632,2048,32000};
    const unsigned k[]={2048,2048,2048,5632,2048};
    uint4 *p; unsigned *dst;
    OK(cudaMalloc(&p,cap)); OK(cudaMalloc(&dst,1024*1024));
    fill<<<cap/16/256,256>>>(p,cap/16);
    cudaEvent_t start,stop; OK(cudaEventCreate(&start)); OK(cudaEventCreate(&stop));
    puts("M,K,GB_s,us_per_dispatch,blocks");
    for(unsigned a=0;a<5;++a) {
        unsigned bytes=m[a]*k[a], n=bytes/16, ring=cap/bytes, repeat=ring<64 ? 64 : ring;
        double best=0; unsigned winner=0;
        for(unsigned blocks=70;blocks<=2240;blocks*=2) {
            for(unsigned it=0;it<repeat;++it) read_tile<<<blocks,128>>>(p + (it%ring)*n,dst,n);
            OK(cudaEventRecord(start));
            for(unsigned it=0;it<repeat;++it) read_tile<<<blocks,128>>>(p + (it%ring)*n,dst,n);
            OK(cudaEventRecord(stop)); OK(cudaEventSynchronize(stop));
            float ms; OK(cudaEventElapsedTime(&ms,start,stop)); double rate=(double)bytes*repeat/(ms*1.e6);
            if(rate>best){best=rate;winner=blocks;}
        }
        printf("%u,%u,%.3f,%.3f,%u\n",m[a],k[a],best,bytes/best/1000.,winner);
    }
    OK(cudaEventDestroy(start)); OK(cudaEventDestroy(stop)); OK(cudaFree(p)); OK(cudaFree(dst));
}
