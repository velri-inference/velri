#include <cuda_runtime.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>

static void check(cudaError_t status) {
    if (status != cudaSuccess) {
        std::fprintf(stderr, "%s\n", cudaGetErrorString(status));
        std::exit(1);
    }
}

constexpr unsigned chains = 8, iterations = 512, threads = 256;
__global__ void signed_dot(int *sink, int operand) {
    unsigned id = blockIdx.x * blockDim.x + threadIdx.x;
    int a = int(id * 7919u), acc[chains] = {};
    for (unsigned it = 0; it < iterations; ++it) {
        #pragma unroll
        for (unsigned i = 0; i < chains; ++i) {
            asm volatile("dp4a.s32.s32 %0,%1,%2,%0;" : "+r"(acc[i]) : "r"(a), "r"(operand));
        }
    }
    unsigned result = 0;
    #pragma unroll
    for (unsigned i = 0; i < chains; ++i) result += unsigned(acc[i]);
    sink[id] = int(result);
}

int main() {
    cudaDeviceProp prop;
    check(cudaGetDeviceProperties(&prop, 0));
    unsigned blocks = prop.multiProcessorCount * 32;
    int *out;
    check(cudaMalloc(&out, blocks * threads * sizeof(*out)));
    cudaEvent_t begin, end;
    check(cudaEventCreate(&begin));
    check(cudaEventCreate(&end));
    for (unsigned i = 0; i < 16; ++i) signed_dot<<<blocks, threads>>>(out, 17041411);
    float best = 1e9f;
    for (unsigned i = 0; i < 12; ++i) {
        check(cudaEventRecord(begin));
        for (unsigned j = 0; j < 4; ++j) signed_dot<<<blocks, threads>>>(out, 17041411 + j);
        check(cudaEventRecord(end));
        check(cudaEventSynchronize(end));
        float ms;
        check(cudaEventElapsedTime(&ms, begin, end));
        best = std::min(best, ms);
    }
    double ops = double(blocks) * threads * iterations * chains * 8.0 * 4;
    std::printf("blocks,threads,iterations,chains,best_ms_4_kernels,TOPS\n%u,%u,%u,%u,%.6f,%.6f\n",
                blocks, threads, iterations, chains, best, ops / (best * 1e9));
    check(cudaEventDestroy(begin));
    check(cudaEventDestroy(end));
    check(cudaFree(out));
}
