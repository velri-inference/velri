#include "os.h"
#include "pool.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>

struct scan {
    const unsigned char *src;
    size_t bytes;
    alignas(64) uint32_t sink[64 * 16];
};
static void read_tile(void *arg, size_t id, size_t n) {
    struct scan *s = arg;
    size_t start = s->bytes / 64 * id / n, end = s->bytes / 64 * (id + 1) / n;
    for (size_t j = start; j < end; ++j) {
        __asm__ volatile("vmovdqu (%0), %%ymm0\n\tvmovdqu 32(%0), %%ymm1"
                        : : "r"(s->src + 64 * j) : "ymm0","ymm1","memory");
    }
    s->sink[16 * id] += 1;
}
int main(void) {
    const unsigned m[] = {256, 2048, 5632, 2048, 32000};
    const unsigned k[] = {2048, 2048, 2048, 5632, 2048};
    const size_t cap = 512 * 1024 * 1024;
    unsigned char *p = aligned_alloc(64, cap);
    velri_pool *pool;
    if (!p || velri_pool_create(16, &pool) != VELRI_OK) return 1;
    for (size_t i=0; i<cap; i++) p[i] = (uint8_t)(i * UINT32_C(0x9e3779b9) >> 17);
    puts("M,K,GB_s,total_us_per_read");
    for (unsigned a=0; a<5; ++a) {
        struct scan s = {.bytes = (size_t)m[a] * k[a]};
        size_t ring = cap / s.bytes;
        for (unsigned round=0; round<3; ++round) {
            uint64_t begin = velri_os_monotonic_ns();
            for (size_t b=0; b<ring; ++b) {
                s.src = p + b*s.bytes;
                velri_pool_parallel(pool, 16, read_tile, &s);
            }
            double ns = (double)(velri_os_monotonic_ns() - begin) / ring;
            if (round==2) printf("%u,%u,%.3f,%.3f\n",m[a],k[a],s.bytes/ns,ns*0.001);
        }
    }
    velri_pool_destroy(pool);
    free(p);
}
