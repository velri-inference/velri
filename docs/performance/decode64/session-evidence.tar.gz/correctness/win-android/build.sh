#!/usr/bin/env bash
set -u
root=$(pwd)
q=$(dirname "$0")
ndk=/home/daniil/Android/Sdk/ndk/29.0.14206865
cross=/tmp/velri-c23-w8a8.SiYYqHcm/cross/usr
case "$1" in
  windows) gccrt="$cross/lib/gcc/x86_64-w64-mingw32/13-posix"
     target=(-DCMAKE_TOOLCHAIN_FILE="$root/velri-lib/cmake/toolchains/x86_64-w64-mingw32.cmake" -DCMAKE_C_COMPILER="$(command -v clang)" -DCMAKE_SYSROOT="$cross/x86_64-w64-mingw32" -DCMAKE_C_COMPILER_TARGET=x86_64-w64-windows-gnu "-DCMAKE_EXE_LINKER_FLAGS=-fuse-ld=lld -L$gccrt -static" "-DCMAKE_C_FLAGS=--gcc-install-dir=$gccrt -Wno-unused-command-line-argument");;
  *) target=(-DCMAKE_TOOLCHAIN_FILE="$ndk/build/cmake/android.toolchain.cmake" -DANDROID_ABI="$1" -DANDROID_PLATFORM=android-28 -DVELRI_ENABLE_VULKAN=ON -DCMAKE_C_FLAGS=-Werror);;
esac
cmake -S "$root" -B "$q/$1" -G Ninja -DCMAKE_BUILD_TYPE=Release -DVELRI_SLANGC="$(command -v slangc)" -DBUILD_TESTING=ON -DVELRI_BUILD_BENCHMARKS=ON "${target[@]}" > "$q/$1-config.log" 2>&1 || { tail -18 "$q/$1-config.log"; exit 1; }
cmake --build "$q/$1" -j8 --target bench_session test_engine_runtime test_config_placement test_gpt2_blocks test_velri_lib test_core_contract test_kernels > "$q/$1-build.log" 2>&1 || { rg -C1 'FAILED:|error:|fatal error:' "$q/$1-build.log" | tail -18; exit 1; }
tail -3 "$q/$1-build.log"
