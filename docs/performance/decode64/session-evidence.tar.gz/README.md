# Single-request W8A8 evidence

The main report's 18 independent wall times, model digest, sampled-ID hashes and logits digests are under `wall/`. The logits themselves can be regenerated from the public snapshot. Different ISA or driver versions can differ in their FP32 low bits. The raw three-run independent physical calibrations are under `ceilings/`. `machine.log` identifies the calibration machine and checkout. The two DDR5 channels run at 6000 MT/s each. Files in `controls/` measure the cost of reading real projection shapes from a 512 MiB ring using the normal 16-worker CPU pool or a CUDA read kernel, plus pinned PCIe device-to-host transfers. CUDA is only a calibration tool. Model inference uses Vulkan. The copies, barriers and launch overhead are part of the shape controls. For the CPU scan the interval includes one pool dispatch per matrix.

From a complete Release source/benchmark build with the normal tests enabled, run the following in Bash. Set `ROOT` to the checkout, `B` to its absolute build directory and `E` to the extracted evidence directory. Select your own physical CPU mask and NVIDIA architecture when reproducing on other hardware. The numbers in the published report target exactly the original machine.

```bash
cd "$ROOT"
cc=(clang -O3 -std=c23 -DVELRI_X86_VARIANTS=1 -Ivelri-lib/include -Ivelri-lib/src/platform -Ivelri-lib/tests/cpu/typed)
lib=("$B/velri-lib/libvelri.a" "$B/velri-lib/libvelri_typed_reference.a" -lm -ldl -pthread)
for isa in AVX2 AVX512; do
    "${cc[@]}" "$E/ceilings/$isa-final.c" "$E/ceilings/pin.c" -Wl,--wrap=velri_pool_create "${lib[@]}" -o "$E/$isa"
done
"${cc[@]}" -mavx2 "$E/controls/stream.c" "${lib[@]}" -o "$E/read-cpu"
for f in ceilings/calibrate ceilings/bandwidth controls/stream controls/pcie controls/dp4a; do
    nvcc -O3 -std=c++17 -arch=sm_120 -allow-unsupported-compiler "$E/$f.cu" -o "$E/${f##*/}"
done
for i in 1 2 3; do
    order=(AVX2 AVX512)
    if [[ $i == 2 ]]; then order=(AVX512 AVX2); fi
    for isa in "${order[@]}"; do taskset -c 0-15 "$E/$isa" --workers 16; done
    taskset -c 0-15 "$E/read-cpu"
    "$E/calibrate"
    "$E/bandwidth"
    "$E/stream"
    "$E/pcie"
    "$E/dp4a"
done
```

`experiments/` contains the exploratory end-to-end runs. The 36 ordered subgroup/width/unroll variants in `tunescan.log` are bracketed by the default geometry. `gpu-fusion-ablation.txt` contains separate full-model gated, QKV and combined trials. `correctness/` includes the independent teacher-forced oracle, integer dot and activation-code checks, Release and portability checks. The independent paired Vulkan cold-duplicate probe and all instrumented operator traces are in the separate operator evidence archive.

The final residual-only comparison is under `experiments/final-residual/`. The `cpu/` directory includes the replayable scalar verification, worker-pool probes, tested grouped projection prototype, concurrent model/session checks, and portability results.
